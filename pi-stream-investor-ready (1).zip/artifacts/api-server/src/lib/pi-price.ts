let cachedPrice: { piUsd: number; fetchedAt: number } | null = null;
const CACHE_TTL_MS = 5 * 60 * 1000;
const FALLBACK_PRICE = 0.80;

export async function getLivePiPrice(): Promise<number> {
  const now = Date.now();
  if (cachedPrice && now - cachedPrice.fetchedAt < CACHE_TTL_MS) {
    return cachedPrice.piUsd;
  }
  try {
    const resp = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=pi-network&vs_currencies=usd",
      { signal: AbortSignal.timeout(5000) }
    );
    if (resp.ok) {
      const data = await resp.json() as { "pi-network"?: { usd?: number } };
      const piUsd = data["pi-network"]?.usd;
      if (typeof piUsd === "number" && piUsd > 0) {
        cachedPrice = { piUsd, fetchedAt: now };
        return piUsd;
      }
    }
  } catch {
    // network error or timeout — fall through
  }
  if (cachedPrice) return cachedPrice.piUsd;
  return FALLBACK_PRICE;
}
