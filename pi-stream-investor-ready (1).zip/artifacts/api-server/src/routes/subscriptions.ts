import { Router } from "express";
import { db, subscriptionsTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { CreateSubscriptionBody } from "@workspace/api-zod";
import { getLivePiPrice } from "../lib/pi-price";

const router = Router();

const BASE_PLANS = [
  {
    id: "monthly",
    name: "Pi Stream Monthly",
    usdTarget: 10,
    gcvUsd: 314159,
    durationDays: 30,
    features: [
      "Unlimited HD streaming",
      "Ad-free experience",
      "Access all categories",
      "Download & watch offline",
      "Watch on 5 devices",
      "Early access to Pi originals",
      "Priority support",
    ],
  },
  {
    id: "annual",
    name: "Pi Stream Annual",
    usdTarget: 100,
    gcvUsd: 3141590,
    durationDays: 365,
    features: [
      "Everything in Monthly",
      "Save 17% vs monthly",
      "Pi Stream Verified badge",
      "Channel creation access",
      "Revenue sharing in Pi",
      "Exclusive Pi creator tools",
      "Dedicated account manager",
    ],
  },
  {
    id: "lifetime",
    name: "Pi Stream Lifetime",
    usdTarget: 1000,
    gcvUsd: 31415900,
    durationDays: 36500,
    features: [
      "Everything in Annual",
      "Lifetime access — never pay again",
      "Founding member badge",
      "NFT certificate of ownership",
      "Pi Stream DAO voting rights",
      "Revenue sharing forever",
      "Direct line to founders",
    ],
  },
];

// GET /subscriptions — live dynamic pricing
router.get("/subscriptions", async (req, res) => {
  try {
    const livePrice = await getLivePiPrice();
    const plans = BASE_PLANS.map(plan => ({
      id: plan.id,
      name: plan.name,
      piAmount: Math.round((plan.usdTarget / livePrice) * 100) / 100,
      gcvUsd: plan.gcvUsd,
      durationDays: plan.durationDays,
      features: plan.features,
      usdTarget: plan.usdTarget,
      liveMarketPriceUsd: livePrice,
    }));
    return res.json(plans);
  } catch (err) {
    req.log.error({ err }, "Failed to get subscription plans");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// POST /subscriptions
router.post("/subscriptions", async (req, res) => {
  try {
    const body = CreateSubscriptionBody.safeParse(req.body);
    if (!body.success) return res.status(400).json({ error: "Invalid body" });

    const plan = BASE_PLANS.find((p) => p.id === body.data.planId);
    if (!plan) return res.status(400).json({ error: "Invalid plan" });

    const startDate = new Date();
    const endDate = new Date(startDate.getTime() + plan.durationDays * 24 * 60 * 60 * 1000);

    const [sub] = await db.insert(subscriptionsTable).values({
      planId: body.data.planId,
      status: "active",
      piTxId: body.data.piTxId,
      piAmount: body.data.piAmount,
      gcvUsd: plan.gcvUsd,
      walletAddress: body.data.walletAddress ?? null,
      startDate,
      endDate,
    }).returning();

    return res.status(201).json({
      ...sub,
      startDate: sub.startDate.toISOString(),
      endDate: sub.endDate.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to create subscription");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// GET /subscriptions/status
router.get("/subscriptions/status", async (req, res) => {
  try {
    const subs = await db.select().from(subscriptionsTable).orderBy(desc(subscriptionsTable.createdAt)).limit(1);
    if (!subs.length) {
      return res.json({
        id: 0,
        planId: "none",
        status: "inactive",
        piTxId: "",
        piAmount: 0,
        gcvUsd: 0,
        startDate: new Date().toISOString(),
        endDate: new Date().toISOString(),
      });
    }
    const sub = subs[0];
    return res.json({
      ...sub,
      startDate: sub.startDate.toISOString(),
      endDate: sub.endDate.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get subscription status");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
