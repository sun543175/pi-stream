import { Router } from "express";
import { db, watchHistoryTable, videosTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { AddWatchHistoryBody } from "@workspace/api-zod";

const router = Router();

// GET /watch-history
router.get("/watch-history", async (req, res) => {
  try {
    const history = await db.select().from(watchHistoryTable).orderBy(desc(watchHistoryTable.watchedAt)).limit(50);
    return res.json(history.map((h) => ({ ...h, watchedAt: h.watchedAt.toISOString() })));
  } catch (err) {
    req.log.error({ err }, "Failed to get watch history");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// POST /watch-history
router.post("/watch-history", async (req, res) => {
  try {
    const body = AddWatchHistoryBody.safeParse(req.body);
    if (!body.success) return res.status(400).json({ error: "Invalid body" });

    const videos = await db.select().from(videosTable).where(eq(videosTable.id, body.data.videoId)).limit(1);
    const title = videos.length ? videos[0].title : "Unknown video";
    const emoji = videos.length ? videos[0].thumbnailEmoji : "🎬";

    const [entry] = await db.insert(watchHistoryTable).values({
      videoId: body.data.videoId,
      title,
      thumbnailEmoji: emoji,
      progress: body.data.progress,
    }).returning();

    return res.status(201).json({ ...entry, watchedAt: entry.watchedAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to add watch history");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
