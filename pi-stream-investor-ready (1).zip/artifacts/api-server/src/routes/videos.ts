import { Router } from "express";
import { db, videosTable } from "@workspace/db";
import { eq, ilike, or } from "drizzle-orm";
import {
  ListVideosQueryParams,
  GetVideoParams,
  GetRelatedVideosParams,
  LikeVideoParams,
  ListCommentsParams,
  AddCommentParams,
  AddCommentBody,
  SearchVideosQueryParams,
} from "@workspace/api-zod";
import { commentsTable } from "@workspace/db";

const router = Router();

// GET /videos
router.get("/videos", async (req, res) => {
  try {
    const query = ListVideosQueryParams.safeParse(req.query);
    const category = query.success ? query.data.category : undefined;
    const limit = query.success ? (query.data.limit ?? 50) : 50;
    const offset = query.success ? (query.data.offset ?? 0) : 0;

    let videos;
    if (category) {
      videos = await db.select().from(videosTable).where(eq(videosTable.category, category)).limit(limit).offset(offset);
    } else {
      videos = await db.select().from(videosTable).limit(limit).offset(offset);
    }
    return res.json(videos);
  } catch (err) {
    req.log.error({ err }, "Failed to list videos");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// GET /videos/trending
router.get("/videos/trending", async (req, res) => {
  try {
    const videos = await db.select().from(videosTable).orderBy(videosTable.likes).limit(10);
    return res.json(videos);
  } catch (err) {
    req.log.error({ err }, "Failed to get trending videos");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// GET /videos/featured
router.get("/videos/featured", async (req, res) => {
  try {
    const videos = await db.select().from(videosTable).limit(1);
    if (!videos.length) return res.status(404).json({ error: "No videos" });
    return res.json(videos[0]);
  } catch (err) {
    req.log.error({ err }, "Failed to get featured video");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// GET /videos/live
router.get("/videos/live", async (req, res) => {
  try {
    const videos = await db.select().from(videosTable).where(eq(videosTable.isLive, true));
    return res.json(videos);
  } catch (err) {
    req.log.error({ err }, "Failed to get live streams");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// GET /search
router.get("/search", async (req, res) => {
  try {
    const query = SearchVideosQueryParams.safeParse(req.query);
    if (!query.success) return res.status(400).json({ error: "q is required" });
    const q = `%${query.data.q}%`;
    const videos = await db.select().from(videosTable).where(
      or(ilike(videosTable.title, q), ilike(videosTable.channelName, q), ilike(videosTable.category, q))
    ).limit(20);
    return res.json(videos);
  } catch (err) {
    req.log.error({ err }, "Search failed");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// GET /videos/:id
router.get("/videos/:id", async (req, res) => {
  try {
    const params = GetVideoParams.safeParse({ id: parseInt(req.params.id) });
    if (!params.success) return res.status(400).json({ error: "Invalid id" });
    const videos = await db.select().from(videosTable).where(eq(videosTable.id, params.data.id));
    if (!videos.length) return res.status(404).json({ error: "Not found" });
    return res.json(videos[0]);
  } catch (err) {
    req.log.error({ err }, "Failed to get video");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// GET /videos/:id/related
router.get("/videos/:id/related", async (req, res) => {
  try {
    const params = GetRelatedVideosParams.safeParse({ id: parseInt(req.params.id) });
    if (!params.success) return res.status(400).json({ error: "Invalid id" });
    const video = await db.select().from(videosTable).where(eq(videosTable.id, params.data.id)).limit(1);
    let related;
    if (video.length) {
      related = await db.select().from(videosTable)
        .where(eq(videosTable.category, video[0].category))
        .limit(8);
    } else {
      related = await db.select().from(videosTable).limit(8);
    }
    return res.json(related);
  } catch (err) {
    req.log.error({ err }, "Failed to get related videos");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// POST /videos/:id/like
router.post("/videos/:id/like", async (req, res) => {
  try {
    const params = LikeVideoParams.safeParse({ id: parseInt(req.params.id) });
    if (!params.success) return res.status(400).json({ error: "Invalid id" });
    const videos = await db.select().from(videosTable).where(eq(videosTable.id, params.data.id));
    if (!videos.length) return res.status(404).json({ error: "Not found" });
    const newLikes = (videos[0].likes ?? 0) + 1;
    await db.update(videosTable).set({ likes: newLikes }).where(eq(videosTable.id, params.data.id));
    return res.json({ liked: true, likeCount: newLikes });
  } catch (err) {
    req.log.error({ err }, "Failed to like video");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// GET /videos/:id/comments
router.get("/videos/:id/comments", async (req, res) => {
  try {
    const params = ListCommentsParams.safeParse({ id: parseInt(req.params.id) });
    if (!params.success) return res.status(400).json({ error: "Invalid id" });
    const comments = await db.select().from(commentsTable).where(eq(commentsTable.videoId, params.data.id));
    return res.json(comments);
  } catch (err) {
    req.log.error({ err }, "Failed to list comments");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// POST /videos/:id/comments
router.post("/videos/:id/comments", async (req, res) => {
  try {
    const params = AddCommentParams.safeParse({ id: parseInt(req.params.id) });
    if (!params.success) return res.status(400).json({ error: "Invalid id" });
    const body = AddCommentBody.safeParse(req.body);
    if (!body.success) return res.status(400).json({ error: "Invalid body" });
    const [comment] = await db.insert(commentsTable).values({
      videoId: params.data.id,
      author: body.data.author,
      body: body.data.body,
    }).returning();
    return res.status(201).json(comment);
  } catch (err) {
    req.log.error({ err }, "Failed to add comment");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
