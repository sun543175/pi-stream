import { Router, type IRouter } from "express";
import healthRouter from "./health";
import videosRouter from "./videos";
import categoriesRouter from "./categories";
import subscriptionsRouter from "./subscriptions";
import playlistsRouter from "./playlists";
import statsRouter from "./stats";
import watchHistoryRouter from "./watch_history";

const router: IRouter = Router();

router.use(healthRouter);
router.use(videosRouter);
router.use(categoriesRouter);
router.use(subscriptionsRouter);
router.use(playlistsRouter);
router.use(statsRouter);
router.use(watchHistoryRouter);

export default router;
