import { Router } from "express";
import { db, videosTable, subscriptionsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { getLivePiPrice } from "../lib/pi-price";

const router = Router();

// GET /stats/platform
router.get("/stats/platform", async (req, res) => {
  try {
    const [videoCount] = await db.select({ count: sql<number>`count(*)::int` }).from(videosTable);
    const [subCount] = await db.select({ count: sql<number>`count(*)::int` }).from(subscriptionsTable);
    const [liveCount] = await db.select({ count: sql<number>`count(*)::int` }).from(videosTable).where(eq(videosTable.isLive, true));
    const [piCollected] = await db.select({ total: sql<number>`coalesce(sum(pi_amount), 0)::float` }).from(subscriptionsTable);

    return res.json({
      totalVideos: videoCount.count,
      totalSubscribers: subCount.count,
      liveCount: liveCount.count,
      totalCategories: 8,
      piCollected: piCollected.total ?? 0,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get platform stats");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// GET /stats/pi-exchange — live price from CoinGecko, 5-min cache
router.get("/stats/pi-exchange", async (req, res) => {
  try {
    const piUsdMarket = await getLivePiPrice();
    const gcvMultiple = piUsdMarket > 0 ? 314159 / piUsdMarket : 392698.75;

    return res.json({
      piUsdGcv: 314159,
      piUsdMarket,
      gcvMultiple: Math.round(gcvMultiple * 100) / 100,
      lastUpdated: new Date().toISOString(),
      exchangeOptions: [
        { name: "OKX", url: "https://www.okx.com", type: "CEX", supported: true },
        { name: "HTX (Huobi)", url: "https://www.htx.com", type: "CEX", supported: true },
        { name: "BitMart", url: "https://www.bitmart.com", type: "CEX", supported: true },
        { name: "Uniswap V3", url: "https://app.uniswap.org", type: "DEX", supported: false },
        { name: "PancakeSwap", url: "https://pancakeswap.finance", type: "DEX", supported: false },
        { name: "Pi Network App", url: "https://minepi.com", type: "Wallet", supported: true },
        { name: "Export JSON", url: "#export", type: "File", supported: true },
      ],
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get exchange rate");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
