import { Router } from "express";
import { db, playlistsTable, playlistVideosTable, videosTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { AddToPlaylistParams, AddToPlaylistBody, CreatePlaylistBody } from "@workspace/api-zod";

const router = Router();

// GET /playlists
router.get("/playlists", async (req, res) => {
  try {
    const playlists = await db.select().from(playlistsTable);
    const counts = await db
      .select({ playlistId: playlistVideosTable.playlistId, count: sql<number>`count(*)::int` })
      .from(playlistVideosTable)
      .groupBy(playlistVideosTable.playlistId);
    const countMap: Record<number, number> = {};
    for (const row of counts) {
      countMap[row.playlistId] = row.count;
    }
    const result = playlists.map((p) => ({
      ...p,
      videoCount: countMap[p.id] ?? 0,
      createdAt: p.createdAt.toISOString(),
    }));
    return res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to list playlists");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// POST /playlists
router.post("/playlists", async (req, res) => {
  try {
    const body = CreatePlaylistBody.safeParse(req.body);
    if (!body.success) return res.status(400).json({ error: "Invalid body" });
    const [playlist] = await db.insert(playlistsTable).values({
      name: body.data.name,
      description: body.data.description ?? null,
    }).returning();
    return res.status(201).json({ ...playlist, videoCount: 0, createdAt: playlist.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create playlist");
    return res.status(500).json({ error: "Internal server error" });
  }
});

// POST /playlists/:id/videos
router.post("/playlists/:id/videos", async (req, res) => {
  try {
    const params = AddToPlaylistParams.safeParse({ id: parseInt(req.params.id) });
    if (!params.success) return res.status(400).json({ error: "Invalid id" });
    const body = AddToPlaylistBody.safeParse(req.body);
    if (!body.success) return res.status(400).json({ error: "Invalid body" });

    await db.insert(playlistVideosTable).values({
      playlistId: params.data.id,
      videoId: body.data.videoId,
    });

    const playlists = await db.select().from(playlistsTable).where(eq(playlistsTable.id, params.data.id));
    if (!playlists.length) return res.status(404).json({ error: "Playlist not found" });

    const counts = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(playlistVideosTable)
      .where(eq(playlistVideosTable.playlistId, params.data.id));

    return res.json({
      ...playlists[0],
      videoCount: counts[0]?.count ?? 0,
      createdAt: playlists[0].createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to add to playlist");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
