import { Router } from "express";
import { db, videosTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const router = Router();

const CATEGORIES = [
  { id: 1, name: "Technology", slug: "Technology", emoji: "💻" },
  { id: 2, name: "Gaming", slug: "Gaming", emoji: "🎮" },
  { id: 3, name: "Music", slug: "Music", emoji: "🎵" },
  { id: 4, name: "Science", slug: "Science", emoji: "🔬" },
  { id: 5, name: "Crypto & Web3", slug: "Crypto", emoji: "🪙" },
  { id: 6, name: "Live", slug: "Live", emoji: "📡" },
  { id: 7, name: "Education", slug: "Education", emoji: "📚" },
  { id: 8, name: "Sports", slug: "Sports", emoji: "⚽" },
];

// GET /categories
router.get("/categories", async (req, res) => {
  try {
    const counts = await db
      .select({ category: videosTable.category, count: sql<number>`count(*)::int` })
      .from(videosTable)
      .groupBy(videosTable.category);

    const countMap: Record<string, number> = {};
    for (const row of counts) {
      countMap[row.category] = row.count;
    }

    const result = CATEGORIES.map((c) => ({
      ...c,
      videoCount: countMap[c.slug] ?? 0,
    }));

    return res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to list categories");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
