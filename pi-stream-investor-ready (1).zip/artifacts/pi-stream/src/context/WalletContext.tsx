import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type WalletState = {
  isConnected: boolean;
  piUsername: string | null;
  walletAddress: string | null;
  connect: (username: string) => Promise<void>;
  disconnect: () => void;
  isConnecting: boolean;
};

const WalletContext = createContext<WalletState | null>(null);

const STORAGE_KEY = "pi-tube-wallet";

function deriveAddress(username: string): string {
  let hash = 0;
  for (let i = 0; i < username.length; i++) {
    hash = ((hash << 5) - hash + username.charCodeAt(i)) | 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, "0");
  return `GC${hex.toUpperCase()}PI${username.slice(0, 4).toUpperCase()}NETWORK${hex.slice(0, 6).toUpperCase()}`;
}

export function WalletProvider({ children }: { children: ReactNode }) {
  const [piUsername, setPiUsername] = useState<string | null>(null);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setPiUsername(parsed.piUsername);
        setWalletAddress(parsed.walletAddress);
      }
    } catch {
      // ignore
    }
  }, []);

  const connect = async (username: string) => {
    setIsConnecting(true);
    // Simulate Pi Network SDK authentication delay
    await new Promise(r => setTimeout(r, 1800));
    const address = deriveAddress(username);
    setPiUsername(username);
    setWalletAddress(address);
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ piUsername: username, walletAddress: address }));
    setIsConnecting(false);
  };

  const disconnect = () => {
    setPiUsername(null);
    setWalletAddress(null);
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <WalletContext.Provider value={{
      isConnected: !!walletAddress,
      piUsername,
      walletAddress,
      connect,
      disconnect,
      isConnecting,
    }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet(): WalletState {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within WalletProvider");
  return ctx;
}
