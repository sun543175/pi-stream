import { useGetVideo, useGetRelatedVideos, useLikeVideo, useListComments, useAddComment, useAddWatchHistory, useListPlaylists, useAddToPlaylist, getGetVideoQueryKey, getGetRelatedVideosQueryKey, getListCommentsQueryKey, getListPlaylistsQueryKey } from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { useEffect, useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { ThumbsUp, Share2, Plus, Flag, Play, Pause, Volume2, Maximize, ListVideo, SkipForward, Repeat, PictureInPicture, Monitor, Clock, Code2, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { VideoCard } from "@/components/video/VideoCard";
import { useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];
const REPORT_REASONS = ["Spam or misleading", "Hateful content", "Violent content", "Sexual content", "Copyright violation", "Misinformation", "Other"];

export default function Watch() {
  const { id } = useParams();
  const videoId = parseInt(id || "0", 10);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isPlaying, setIsPlaying] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [playlistDialogOpen, setPlaylistDialogOpen] = useState(false);
  const [theaterMode, setTheaterMode] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [isLooping, setIsLooping] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isSavedLater, setIsSavedLater] = useState(false);
  const [reportDialogOpen, setReportDialogOpen] = useState(false);
  const [selectedReason, setSelectedReason] = useState("");
  const [reportSubmitted, setReportSubmitted] = useState(false);
  const [embedDialogOpen, setEmbedDialogOpen] = useState(false);
  const [volume, setVolume] = useState(70);
  const [copied, setCopied] = useState(false);
  const speedMenuRef = useRef<HTMLDivElement>(null);

  const { data: video, isLoading: videoLoading } = useGetVideo(videoId, {
    query: { enabled: !!videoId, queryKey: getGetVideoQueryKey(videoId) }
  });

  const { data: relatedVideos } = useGetRelatedVideos(videoId, {
    query: { enabled: !!videoId, queryKey: getGetRelatedVideosQueryKey(videoId) }
  });

  const { data: comments } = useListComments(videoId, {
    query: { enabled: !!videoId, queryKey: getListCommentsQueryKey(videoId) }
  });

  const { data: playlists } = useListPlaylists({
    query: { queryKey: getListPlaylistsQueryKey() }
  });

  const likeMutation = useLikeVideo();
  const commentMutation = useAddComment();
  const historyMutation = useAddWatchHistory();
  const addToPlaylistMutation = useAddToPlaylist();
  const historyRecordedRef = useRef<number | null>(null);

  useEffect(() => {
    if (videoId && historyRecordedRef.current !== videoId) {
      historyRecordedRef.current = videoId;
      historyMutation.mutate({ data: { videoId, progress: 0 } });
    }
  }, [videoId, historyMutation]);

  // Check localStorage for liked/saved
  useEffect(() => {
    const liked = JSON.parse(localStorage.getItem("pi-tube-liked") || "[]") as number[];
    const later = JSON.parse(localStorage.getItem("pi-tube-watch-later") || "[]") as number[];
    setIsLiked(liked.includes(videoId));
    setIsSavedLater(later.includes(videoId));
  }, [videoId]);

  // Keyboard shortcuts
  const handleKey = useCallback((e: KeyboardEvent) => {
    const tag = (e.target as HTMLElement).tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    switch (e.key.toLowerCase()) {
      case " ": e.preventDefault(); setIsPlaying(p => !p); break;
      case "l": setIsLooping(l => !l); break;
      case "t": setTheaterMode(t => !t); break;
      case "m": setVolume(v => v > 0 ? 0 : 70); break;
      case ">": setSpeed(s => { const i = SPEEDS.indexOf(s); return SPEEDS[Math.min(i + 1, SPEEDS.length - 1)]; }); break;
      case "<": setSpeed(s => { const i = SPEEDS.indexOf(s); return SPEEDS[Math.max(i - 1, 0)]; }); break;
    }
  }, []);

  useEffect(() => {
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [handleKey]);

  // Close speed menu on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (speedMenuRef.current && !speedMenuRef.current.contains(e.target as Node)) setShowSpeedMenu(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleLike = () => {
    if (!videoId) return;
    const liked = JSON.parse(localStorage.getItem("pi-tube-liked") || "[]") as number[];
    let updated: number[];
    if (isLiked) { updated = liked.filter(id => id !== videoId); }
    else {
      updated = [...liked, videoId];
      likeMutation.mutate({ id: videoId }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetVideoQueryKey(videoId) })
      });
    }
    localStorage.setItem("pi-tube-liked", JSON.stringify(updated));
    setIsLiked(!isLiked);
    toast({ title: isLiked ? "Unliked" : "Liked!", description: isLiked ? "Removed from liked videos." : "Added to your liked videos." });
  };

  const handleShare = async () => {
    const url = window.location.href;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({ title: "Link copied!", description: "Video link copied to clipboard." });
    } catch {
      toast({ title: "Link ready", description: url });
    }
  };

  const handleWatchLater = () => {
    const later = JSON.parse(localStorage.getItem("pi-tube-watch-later") || "[]") as number[];
    let updated: number[];
    if (isSavedLater) { updated = later.filter(id => id !== videoId); }
    else { updated = [...later, videoId]; }
    localStorage.setItem("pi-tube-watch-later", JSON.stringify(updated));
    setIsSavedLater(!isSavedLater);
    toast({ title: isSavedLater ? "Removed" : "Saved!", description: isSavedLater ? "Removed from Watch Later." : "Added to Watch Later." });
  };

  const handleAddToPlaylist = (playlistId: number) => {
    if (!videoId) return;
    addToPlaylistMutation.mutate({ id: playlistId, data: { videoId } }, {
      onSuccess: () => {
        setPlaylistDialogOpen(false);
        toast({ title: "Added to playlist", description: "Video saved to playlist successfully." });
      }
    });
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !videoId) return;
    commentMutation.mutate({ id: videoId, data: { author: "You", body: commentText } }, {
      onSuccess: () => {
        setCommentText("");
        toast({ title: "Comment posted" });
        queryClient.invalidateQueries({ queryKey: getListCommentsQueryKey(videoId) });
      }
    });
  };

  const handleReport = () => {
    if (!selectedReason) return;
    setReportSubmitted(true);
    toast({ title: "Report submitted", description: "Thank you. Our team will review this video." });
    setTimeout(() => { setReportDialogOpen(false); setReportSubmitted(false); setSelectedReason(""); }, 1500);
  };

  const embedCode = `<iframe src="${window.location.origin}/watch/${videoId}" width="560" height="315" frameborder="0" allowfullscreen></iframe>`;

  if (videoLoading) {
    return (
      <div className="flex flex-col gap-4 pb-12">
        <div className="w-full aspect-video rounded-xl bg-white/5 animate-pulse" />
        <div className="h-8 bg-white/5 rounded w-3/4 animate-pulse" />
        <div className="h-5 bg-white/5 rounded w-1/2 animate-pulse" />
      </div>
    );
  }

  if (!video) {
    return <div className="flex items-center justify-center h-64 text-muted-foreground">Video not found.</div>;
  }

  return (
    <div className={`flex flex-col pb-12 ${theaterMode ? "" : "lg:flex-row gap-6"}`}>
      <div className={`flex-1 min-w-0 ${theaterMode ? "w-full" : ""}`}>
        {/* Video Player */}
        <div className={`relative w-full aspect-video rounded-xl overflow-hidden bg-black border border-white/10 shadow-2xl flex flex-col group ${theaterMode ? "aspect-[21/9]" : ""}`}>
          <div
            className="absolute inset-0 opacity-40 mix-blend-overlay"
            style={{ backgroundImage: `linear-gradient(to bottom right, ${video.thumbnailColor}, ${video.thumbnailColor2 || '#1a1a1a'})` }}
          />
          <div className="absolute inset-0 flex items-center justify-center text-8xl md:text-[10rem] drop-shadow-2xl select-none">
            {video.thumbnailEmoji}
          </div>

          {video.isLive && (
            <Badge variant="destructive" className="absolute top-4 left-4 animate-pulse px-2 py-1 font-bold text-sm z-10 shadow-lg border-none bg-red-600">
              LIVE
            </Badge>
          )}

          {isLooping && (
            <Badge className="absolute top-4 right-4 z-10 bg-primary/80 text-primary-foreground border-none text-xs px-2 py-0.5">
              Loop ON
            </Badge>
          )}

          {/* Controls Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
            {/* Progress Bar */}
            <div className="w-full h-1.5 bg-white/20 rounded-full mb-4 cursor-pointer hover:h-2.5 transition-all relative group/bar">
              <div className="absolute left-0 top-0 h-full bg-primary rounded-full w-1/3" />
              <div className="absolute left-1/3 top-1/2 -translate-y-1/2 w-3 h-3 bg-primary rounded-full opacity-0 group-hover/bar:opacity-100 transition-opacity -ml-1.5" />
            </div>

            <div className="flex items-center justify-between text-white">
              <div className="flex items-center gap-3">
                <button onClick={() => setIsPlaying(!isPlaying)} className="hover:text-primary transition-colors">
                  {isPlaying ? <Pause className="w-6 h-6" fill="currentColor" /> : <Play className="w-6 h-6" fill="currentColor" />}
                </button>
                <button className="hover:text-primary transition-colors hidden sm:block">
                  <SkipForward className="w-5 h-5" />
                </button>

                {/* Volume */}
                <div className="flex items-center gap-2 group/vol">
                  <button onClick={() => setVolume(v => v > 0 ? 0 : 70)} className="hover:text-primary transition-colors">
                    <Volume2 className="w-5 h-5" />
                  </button>
                  <div className="w-16 h-1 bg-white/30 rounded-full relative hidden sm:block cursor-pointer">
                    <div className="h-full bg-white rounded-full" style={{ width: `${volume}%` }} />
                  </div>
                </div>

                <span className="text-sm font-medium hidden sm:block">1:23 / {video.duration}</span>
              </div>

              <div className="flex items-center gap-2">
                {/* Loop */}
                <button onClick={() => setIsLooping(l => !l)} className={`transition-colors ${isLooping ? "text-primary" : "hover:text-primary"}`}>
                  <Repeat className="w-4 h-4" />
                </button>

                {/* Speed */}
                <div className="relative" ref={speedMenuRef}>
                  <button
                    onClick={() => setShowSpeedMenu(s => !s)}
                    className="text-xs font-bold w-8 text-center hover:text-primary transition-colors bg-white/10 hover:bg-white/20 rounded px-1 py-0.5"
                  >
                    {speed}x
                  </button>
                  {showSpeedMenu && (
                    <div className="absolute bottom-full right-0 mb-2 bg-card border border-white/10 rounded-lg overflow-hidden z-10 shadow-xl">
                      {SPEEDS.map(s => (
                        <button
                          key={s}
                          onClick={() => { setSpeed(s); setShowSpeedMenu(false); }}
                          className={`block w-full text-center px-4 py-1.5 text-sm hover:bg-white/10 transition-colors ${s === speed ? "text-primary font-bold" : "text-white"}`}
                        >
                          {s}x
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* PiP */}
                <button
                  onClick={() => toast({ title: "Picture-in-Picture", description: "PiP requires an actual video file." })}
                  className="hover:text-primary transition-colors hidden sm:block"
                >
                  <PictureInPicture className="w-4 h-4" />
                </button>

                {/* Theater mode */}
                <button onClick={() => setTheaterMode(t => !t)} className={`transition-colors ${theaterMode ? "text-primary" : "hover:text-primary"}`}>
                  <Monitor className="w-4 h-4" />
                </button>

                {/* Fullscreen */}
                <button className="hover:text-primary transition-colors">
                  <Maximize className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Keyboard shortcuts hint */}
        <p className="text-xs text-muted-foreground/50 mt-1 text-right hidden md:block">
          Space=play · T=theater · L=loop · M=mute · &lt;&gt;=speed
        </p>

        {/* Video Info */}
        <div className="mt-4">
          <h1 className="text-xl sm:text-2xl font-bold text-foreground mb-3 leading-tight font-display tracking-tight">
            {video.title}
          </h1>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Link href={`/channel/${encodeURIComponent(video.channelName)}`}>
                <Avatar className="w-10 h-10 border border-white/10 hover:border-primary/50 transition-colors cursor-pointer">
                  <AvatarFallback className="bg-primary/20 text-primary font-bold">
                    {video.channelName.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </Link>
              <div>
                <Link href={`/channel/${encodeURIComponent(video.channelName)}`}>
                  <h3 className="font-semibold text-foreground flex items-center gap-1 hover:text-primary transition-colors cursor-pointer">
                    {video.channelName}
                    {video.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />}
                  </h3>
                </Link>
                <p className="text-sm text-muted-foreground">1.2M subscribers</p>
              </div>
              <Button className="ml-2 rounded-full font-semibold px-6 bg-primary text-primary-foreground hover:bg-primary/90">Subscribe</Button>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-hide flex-wrap">
              <Button
                variant="secondary"
                className={`rounded-full border transition-colors ${isLiked ? "bg-primary/20 text-primary border-primary/30" : "bg-white/5 hover:bg-white/10 text-foreground border-white/5"}`}
                onClick={handleLike}
              >
                <ThumbsUp className={`w-4 h-4 mr-2 ${isLiked ? "fill-current" : ""}`} />
                {(video.likes || 0) + (isLiked ? 1 : 0)}
              </Button>

              <Button
                variant="secondary"
                className={`rounded-full border transition-colors ${copied ? "bg-primary/20 text-primary border-primary/30" : "bg-white/5 hover:bg-white/10 text-foreground border-white/5"}`}
                onClick={handleShare}
              >
                <Share2 className="w-4 h-4 mr-2" />
                {copied ? "Copied!" : "Share"}
              </Button>

              <Button
                variant="secondary"
                className={`rounded-full border transition-colors ${isSavedLater ? "bg-primary/20 text-primary border-primary/30" : "bg-white/5 hover:bg-white/10 text-foreground border-white/5"}`}
                onClick={handleWatchLater}
              >
                <Clock className={`w-4 h-4 mr-2 ${isSavedLater ? "fill-current" : ""}`} />
                {isSavedLater ? "Saved" : "Watch Later"}
              </Button>

              {/* Playlist */}
              <Dialog open={playlistDialogOpen} onOpenChange={setPlaylistDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="secondary" className="rounded-full bg-white/5 hover:bg-white/10 text-foreground border border-white/5">
                    <Plus className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md bg-card border-white/10 text-foreground">
                  <DialogHeader>
                    <DialogTitle>Save to playlist</DialogTitle>
                    <DialogDescription>Add this video to one of your playlists.</DialogDescription>
                  </DialogHeader>
                  <ScrollArea className="max-h-[300px] mt-4">
                    <div className="flex flex-col gap-2">
                      {playlists?.length ? playlists.map((playlist) => (
                        <button
                          key={playlist.id}
                          onClick={() => handleAddToPlaylist(playlist.id)}
                          className="flex items-center justify-between p-3 rounded-lg hover:bg-white/5 transition-colors text-left border border-transparent hover:border-white/10"
                        >
                          <div className="flex items-center gap-3">
                            <ListVideo className="w-5 h-5 text-primary" />
                            <span className="font-medium">{playlist.name}</span>
                          </div>
                          <Plus className="w-4 h-4 text-muted-foreground" />
                        </button>
                      )) : (
                        <div className="text-center py-8 text-muted-foreground text-sm">
                          No playlists yet. Create one on the Playlists page.
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </DialogContent>
              </Dialog>

              {/* Embed */}
              <Dialog open={embedDialogOpen} onOpenChange={setEmbedDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="secondary" size="icon" className="rounded-full bg-white/5 hover:bg-white/10 text-foreground border border-white/5">
                    <Code2 className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg bg-card border-white/10 text-foreground">
                  <DialogHeader>
                    <DialogTitle>Embed video</DialogTitle>
                    <DialogDescription>Copy this code to embed the video on your website.</DialogDescription>
                  </DialogHeader>
                  <div className="mt-4 p-3 rounded-lg bg-black/60 border border-white/10 font-mono text-xs text-muted-foreground break-all">
                    {embedCode}
                  </div>
                  <Button onClick={() => { navigator.clipboard.writeText(embedCode); toast({ title: "Embed code copied!" }); }} className="mt-2 rounded-full bg-primary text-primary-foreground hover:bg-primary/90">
                    Copy embed code
                  </Button>
                </DialogContent>
              </Dialog>

              {/* Report */}
              <Dialog open={reportDialogOpen} onOpenChange={setReportDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="secondary" size="icon" className="rounded-full bg-white/5 hover:bg-white/10 text-foreground border border-white/5">
                    <Flag className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md bg-card border-white/10 text-foreground">
                  <DialogHeader>
                    <DialogTitle>Report video</DialogTitle>
                    <DialogDescription>Select a reason for reporting this video.</DialogDescription>
                  </DialogHeader>
                  {reportSubmitted ? (
                    <div className="flex flex-col items-center py-8 gap-3 text-green-400">
                      <CheckCircle2 className="w-12 h-12" />
                      <p className="font-semibold">Report submitted</p>
                    </div>
                  ) : (
                    <>
                      <div className="flex flex-col gap-2 mt-4">
                        {REPORT_REASONS.map(r => (
                          <button
                            key={r}
                            onClick={() => setSelectedReason(r)}
                            className={`flex items-center gap-3 p-3 rounded-lg text-left text-sm transition-colors border ${selectedReason === r ? "border-primary bg-primary/10 text-primary" : "border-transparent hover:bg-white/5 text-foreground"}`}
                          >
                            <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 ${selectedReason === r ? "border-primary" : "border-white/30"}`}>
                              {selectedReason === r && <div className="w-2 h-2 rounded-full bg-primary" />}
                            </div>
                            {r}
                          </button>
                        ))}
                      </div>
                      <Button onClick={handleReport} disabled={!selectedReason} className="mt-4 w-full rounded-full bg-destructive hover:bg-destructive/90 text-white">
                        Submit report
                      </Button>
                    </>
                  )}
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Description */}
          <div className="mt-4 bg-white/5 rounded-xl p-4 border border-white/5 hover:bg-white/[0.07] transition-colors cursor-pointer">
            <div className="flex gap-4 text-sm font-semibold mb-2 text-foreground">
              <span>{video.views} views</span>
              <span className="text-muted-foreground">{video.createdAt}</span>
            </div>
            <p className="text-sm text-muted-foreground whitespace-pre-wrap">{video.description || "No description provided."}</p>
          </div>
        </div>

        {/* Comments */}
        <div className="mt-8">
          <div className="flex items-center gap-2 mb-6">
            <h2 className="text-xl font-bold text-foreground">Comments</h2>
            <span className="text-muted-foreground text-sm font-medium">{comments?.length || 0}</span>
          </div>

          <form onSubmit={handleAddComment} className="flex gap-4 mb-8">
            <Avatar className="w-10 h-10 shrink-0">
              <AvatarFallback className="bg-primary/20 text-primary">Y</AvatarFallback>
            </Avatar>
            <div className="flex-1 flex flex-col gap-2">
              <Textarea
                placeholder="Add a comment..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                className="bg-transparent border-t-0 border-x-0 border-b border-white/20 rounded-none focus-visible:ring-0 focus-visible:border-primary px-0 pb-1 resize-none"
                rows={1}
              />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="ghost" className="rounded-full hover:bg-white/5" onClick={() => setCommentText("")}>Cancel</Button>
                <Button type="submit" className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90" disabled={!commentText.trim()}>Comment</Button>
              </div>
            </div>
          </form>

          <div className="space-y-6">
            {comments?.map((comment) => (
              <div key={comment.id} className="flex gap-4">
                <Avatar className="w-10 h-10 shrink-0">
                  <AvatarFallback className="bg-white/10 text-white/70">{comment.author.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="font-semibold text-sm text-foreground">{comment.author}</span>
                    <span className="text-xs text-muted-foreground">{comment.createdAt}</span>
                  </div>
                  <p className="text-sm text-white/90">{comment.body}</p>
                  <div className="flex items-center gap-4 mt-2">
                    <button className="text-muted-foreground hover:text-primary transition-colors"><ThumbsUp className="w-3 h-3" /></button>
                    <button className="text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors">Reply</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Related Videos */}
      {!theaterMode && (
        <div className="w-full lg:w-[350px] xl:w-[400px] shrink-0">
          <h3 className="font-semibold text-foreground mb-4">Related Videos</h3>
          <div className="flex flex-col gap-3">
            {relatedVideos?.map((related) => (
              <VideoCard key={related.id} video={related} layout="list" />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
