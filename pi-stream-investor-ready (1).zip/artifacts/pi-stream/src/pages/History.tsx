import { useGetWatchHistory, getGetWatchHistoryQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Trash2, History as HistoryIcon, Play } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function History() {
  const { data: history, isLoading } = useGetWatchHistory({ query: { queryKey: getGetWatchHistoryQueryKey() } });

  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto py-6">
      <div className="flex items-center justify-between border-b border-white/5 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <HistoryIcon className="w-5 h-5" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Watch History</h1>
        </div>
        <Button variant="outline" className="rounded-full gap-2 text-destructive border-white/10 hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30">
          <Trash2 className="w-4 h-4" />
          Clear all watch history
        </Button>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading history...</div>
      ) : history && history.length > 0 ? (
        <div className="flex flex-col gap-4">
          {history.map((item) => (
            <Link key={item.id} href={`/watch/${item.videoId}`} className="block group">
              <div className="flex gap-4 p-3 rounded-xl hover:bg-white/5 transition-colors items-center border border-transparent hover:border-white/5">
                <div className="w-32 sm:w-48 aspect-video rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-3xl sm:text-4xl shrink-0 relative overflow-hidden">
                  {item.thumbnailEmoji}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Play className="w-8 h-8 text-white" fill="currentColor" />
                  </div>
                  <Progress value={item.progress} className="absolute bottom-0 inset-x-0 h-1 rounded-none bg-black/50 [&>div]:bg-primary" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-lg text-foreground line-clamp-2 group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Watched on {new Date(item.watchedAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-24 border border-white/5 rounded-2xl bg-white/5 border-dashed">
          <HistoryIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
          <h2 className="text-xl font-semibold mb-2">Keep track of what you watch</h2>
          <p className="text-muted-foreground">Videos you watch will show up here.</p>
        </div>
      )}
    </div>
  );
}
