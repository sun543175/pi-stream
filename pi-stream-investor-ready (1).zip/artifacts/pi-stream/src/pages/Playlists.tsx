import { useListPlaylists, useCreatePlaylist, getListPlaylistsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Plus, PlaySquare, ListVideo } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Textarea } from "@/components/ui/textarea";

export default function Playlists() {
  const { data: playlists, isLoading } = useListPlaylists({ query: { queryKey: getListPlaylistsQueryKey() } });
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createMutation = useCreatePlaylist();

  const handleCreate = () => {
    if (!name.trim()) return;
    createMutation.mutate({ data: { name, description } }, {
      onSuccess: () => {
        setOpen(false);
        setName("");
        setDescription("");
        toast({ title: "Playlist created", description: `"${name}" has been created.` });
        queryClient.invalidateQueries({ queryKey: getListPlaylistsQueryKey() });
      }
    });
  };

  return (
    <div className="flex flex-col gap-6 py-6">
      <div className="flex items-center justify-between border-b border-white/5 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center text-secondary">
            <ListVideo className="w-5 h-5" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Your Playlists</h1>
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-full gap-2 font-semibold">
              <Plus className="w-4 h-4" />
              New Playlist
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px] bg-card border-white/10 text-foreground">
            <DialogHeader>
              <DialogTitle>Create a new playlist</DialogTitle>
              <DialogDescription>Group your favorite videos together.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} className="bg-background border-white/10" placeholder="e.g. Web3 Tutorials" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description (optional)</Label>
                <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} className="bg-background border-white/10 resize-none" placeholder="Add a description..." />
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)} className="rounded-full">Cancel</Button>
              <Button onClick={handleCreate} disabled={!name.trim() || createMutation.isPending} className="rounded-full">Create</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading playlists...</div>
      ) : playlists && playlists.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {playlists.map((playlist) => (
            <div key={playlist.id} className="group cursor-pointer">
              <div className="relative aspect-video rounded-xl bg-white/5 border border-white/10 overflow-hidden mb-3 group-hover:border-secondary/50 transition-colors flex items-center justify-center">
                <div className="absolute inset-0 bg-gradient-to-br from-secondary/5 to-transparent"></div>
                <PlaySquare className="w-12 h-12 text-secondary/30 group-hover:text-secondary/70 transition-colors" />
                <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 rounded text-xs font-medium border border-white/10">
                  {playlist.videoCount} videos
                </div>
              </div>
              <h3 className="font-semibold text-lg text-foreground group-hover:text-secondary transition-colors">{playlist.name}</h3>
              {playlist.description && (
                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{playlist.description}</p>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-24 border border-white/5 rounded-2xl bg-white/5 border-dashed">
          <ListVideo className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
          <h2 className="text-xl font-semibold mb-2">No playlists yet</h2>
          <p className="text-muted-foreground mb-6">Create a playlist to save and organize videos.</p>
          <Button onClick={() => setOpen(true)} className="rounded-full gap-2">
            <Plus className="w-4 h-4" /> Create Playlist
          </Button>
        </div>
      )}
    </div>
  );
}
