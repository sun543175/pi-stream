import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { VideoCard } from "@/components/video/VideoCard";
import { ThumbsUp } from "lucide-react";
import { useEffect, useState } from "react";

export default function Liked() {
  const [likedIds, setLikedIds] = useState<number[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem("pi-tube-liked");
    if (stored) {
      try { setLikedIds(JSON.parse(stored)); } catch { setLikedIds([]); }
    }
  }, []);

  const { data: allVideos, isLoading } = useListVideos(undefined, {
    query: { queryKey: getListVideosQueryKey() }
  });

  const likedVideos = allVideos?.filter(v => likedIds.includes(v.id)) || [];

  return (
    <div className="pb-12">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
          <ThumbsUp className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground">Liked Videos</h1>
          <p className="text-sm text-muted-foreground">{likedVideos.length} liked video{likedVideos.length !== 1 ? "s" : ""}</p>
        </div>
      </div>

      {isLoading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="w-full aspect-video rounded-xl bg-white/5 mb-3" />
              <div className="h-4 bg-white/5 rounded w-3/4 mb-2" />
              <div className="h-3 bg-white/5 rounded w-1/2" />
            </div>
          ))}
        </div>
      )}

      {!isLoading && likedVideos.length === 0 && (
        <div className="flex flex-col items-center justify-center h-64 text-center">
          <ThumbsUp className="w-16 h-16 text-white/10 mb-4" />
          <p className="text-xl font-semibold text-muted-foreground mb-2">No liked videos yet</p>
          <p className="text-muted-foreground text-sm">Like a video while watching and it will appear here</p>
        </div>
      )}

      {!isLoading && likedVideos.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {likedVideos.map(video => (
            <VideoCard key={video.id} video={video} />
          ))}
        </div>
      )}
    </div>
  );
}
