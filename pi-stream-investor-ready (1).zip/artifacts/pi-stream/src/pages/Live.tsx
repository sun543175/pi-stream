import { useListLiveStreams, getListLiveStreamsQueryKey } from "@workspace/api-client-react";
import { VideoGrid } from "@/components/video/VideoGrid";
import { Radio } from "lucide-react";

export default function Live() {
  const { data: liveStreams, isLoading } = useListLiveStreams({ query: { queryKey: getListLiveStreamsQueryKey() } });

  return (
    <div className="flex flex-col gap-6 py-6">
      <div className="flex items-center gap-3 border-b border-white/5 pb-4">
        <div className="w-10 h-10 rounded-full bg-destructive/20 flex items-center justify-center text-destructive animate-pulse">
          <Radio className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Live Now</h1>
          <p className="text-muted-foreground text-sm mt-1">Join the conversation in real-time</p>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Finding live streams...</div>
      ) : liveStreams && liveStreams.length > 0 ? (
        <VideoGrid videos={liveStreams} />
      ) : (
        <div className="text-center py-24 border border-white/5 rounded-2xl bg-white/5 border-dashed">
          <Radio className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
          <h2 className="text-xl font-semibold mb-2">No one is broadcasting right now</h2>
          <p className="text-muted-foreground">Check back later for live events.</p>
        </div>
      )}
    </div>
  );
}
