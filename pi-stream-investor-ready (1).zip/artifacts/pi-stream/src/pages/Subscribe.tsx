import { useGetSubscriptionPlans, useCreateSubscription, useGetPiExchangeRate, getGetSubscriptionPlansQueryKey, getGetPiExchangeRateQueryKey } from "@workspace/api-client-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Check, Sparkles, Shield, Zap, Wallet, TrendingUp, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PiLogo } from "@/components/PiLogo";
import { useWallet } from "@/context/WalletContext";
import { ConnectWalletModal } from "@/components/wallet/ConnectWalletModal";
import { Badge } from "@/components/ui/badge";

const USD_TARGETS: Record<string, number> = { monthly: 10, annual: 100, lifetime: 1000 };

const PLAN_PERKS: Record<string, string[]> = {
  monthly: ["Unlimited HD streaming", "No ads", "Download for offline", "Priority support"],
  annual: ["Everything in Monthly", "2 months free", "Early access to features", "Creator analytics"],
  lifetime: ["Everything in Annual", "Lifetime access", "Creator verification badge", "Direct Pi wallet rewards"],
};

const PLAN_ICONS: Record<string, React.ReactNode> = {
  monthly: <Zap className="w-5 h-5" />,
  annual: <Sparkles className="w-5 h-5" />,
  lifetime: <Shield className="w-5 h-5" />,
};

export default function Subscribe() {
  const { toast } = useToast();
  const { isConnected, walletAddress, piUsername } = useWallet();
  const [connectModalOpen, setConnectModalOpen] = useState(false);
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const [walletInput, setWalletInput] = useState("");
  const [txId, setTxId] = useState("");

  const { data: plans, isLoading: plansLoading, refetch: refetchPlans } = useGetSubscriptionPlans({ query: { queryKey: getGetSubscriptionPlansQueryKey() } });
  const { data: exchangeRate } = useGetPiExchangeRate({ query: { queryKey: getGetPiExchangeRateQueryKey(), refetchInterval: 5 * 60 * 1000 } });
  const createSubMutation = useCreateSubscription();

  const effectiveWallet = isConnected ? (walletAddress ?? "") : walletInput;
  const livePrice = exchangeRate?.piUsdMarket ?? 0;

  const handleSubscribe = () => {
    if (!selectedPlanId || !txId || !effectiveWallet) return;
    const plan = plans?.find(p => p.id === selectedPlanId);
    if (!plan) return;

    createSubMutation.mutate({
      data: { planId: selectedPlanId, piTxId: txId, piAmount: plan.piAmount, walletAddress: effectiveWallet }
    }, {
      onSuccess: () => {
        setSelectedPlanId(null);
        setTxId("");
        setWalletInput("");
        toast({ title: "Subscription Activated! 🎉", description: `Welcome to Pi Stream Premium, ${piUsername ? "@" + piUsername : "Pioneer"}!` });
      },
      onError: () => {
        toast({ title: "Payment Verification Failed", description: "Could not verify the transaction ID. Please check and try again.", variant: "destructive" });
      }
    });
  };

  const selectedPlan = plans?.find(p => p.id === selectedPlanId);
  const usdTarget = selectedPlanId ? (USD_TARGETS[selectedPlanId] ?? 0) : 0;

  return (
    <div className="flex flex-col max-w-5xl mx-auto gap-8 py-8">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="flex items-center justify-center gap-2 mb-2">
          <PiLogo className="w-10 h-10 text-primary" />
        </div>
        <h1 className="text-4xl font-display font-bold text-foreground">Pi Stream Premium</h1>
        <p className="text-muted-foreground text-lg">Unlock the full Pi Network streaming experience</p>

        {isConnected ? (
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mx-auto">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            Pi Wallet connected · @{piUsername}
          </div>
        ) : (
          <button
            onClick={() => setConnectModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-muted-foreground hover:border-primary/40 hover:text-primary transition-colors text-sm font-medium mx-auto"
          >
            <Wallet className="w-4 h-4" />
            Connect Pi Wallet for instant verification
          </button>
        )}
      </div>

      {/* Live Pi Price Banner */}
      <div className="flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20">
        <div className="flex items-center gap-3">
          <PiLogo className="w-6 h-6 text-primary" />
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Pi Live Market Price</p>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-primary">
                {livePrice > 0 ? `$${livePrice.toFixed(4)}` : "Loading..."}
              </span>
              <span className="text-muted-foreground text-sm">per π</span>
              {livePrice > 0 && (
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-green-400" />
                  Live
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="text-right hidden md:block">
          <p className="text-xs text-muted-foreground">GCV (Consensus Value)</p>
          <p className="text-sm font-semibold text-foreground">$314,159 per π</p>
          <button onClick={() => refetchPlans()} className="text-xs text-primary hover:underline flex items-center gap-1 ml-auto mt-1">
            <RefreshCw className="w-3 h-3" />Refresh prices
          </button>
        </div>
      </div>

      {/* Plans */}
      {plansLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => <div key={i} className="h-80 rounded-2xl bg-white/5 animate-pulse" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans?.map((plan) => {
            const perks = PLAN_PERKS[plan.id] ?? [];
            const icon = PLAN_ICONS[plan.id];
            const isPopular = plan.id === "annual";
            const isSelected = selectedPlanId === plan.id;
            const usd = USD_TARGETS[plan.id] ?? 0;

            return (
              <Card
                key={plan.id}
                className={`relative cursor-pointer transition-all duration-200 bg-card border flex flex-col ${
                  isSelected
                    ? "border-primary shadow-lg shadow-primary/20 ring-1 ring-primary"
                    : isPopular
                      ? "border-primary/40 hover:border-primary/70"
                      : "border-white/10 hover:border-white/20"
                }`}
                onClick={() => setSelectedPlanId(plan.id)}
              >
                {isPopular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground px-3 py-0.5 font-semibold text-xs shadow-lg">
                      Most Popular
                    </Badge>
                  </div>
                )}

                <CardHeader className="pb-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${isSelected ? "bg-primary text-primary-foreground" : "bg-primary/20 text-primary"}`}>
                    {icon}
                  </div>
                  <CardTitle className="text-xl font-display">{plan.name}</CardTitle>
                  <CardDescription className="text-muted-foreground text-sm">{plan.features?.[0] ?? ""}</CardDescription>
                </CardHeader>

                <CardContent className="flex-1">
                  <div className="mb-6">
                    {/* USD price — primary */}
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-display font-bold text-primary">${usd}</span>
                      <span className="text-muted-foreground text-sm">{plan.id === "monthly" ? "/mo" : plan.id === "annual" ? "/yr" : " once"}</span>
                    </div>
                    {/* Pi equivalent — dynamic */}
                    <div className="flex items-center gap-1.5 mt-1">
                      <PiLogo className="w-3 h-3 text-muted-foreground" />
                      <span className="text-sm font-semibold text-foreground">{plan.piAmount} π</span>
                      <span className="text-xs text-muted-foreground">at live price</span>
                    </div>
                    {livePrice > 0 && (
                      <p className="text-xs text-muted-foreground mt-0.5">
                        1 π = ${livePrice.toFixed(4)} · updates every 5 min
                      </p>
                    )}
                  </div>

                  <ul className="space-y-2.5">
                    {perks.map(perk => (
                      <li key={perk} className="flex items-start gap-2.5 text-sm">
                        <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                        <span className="text-foreground/90">{perk}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>

                <CardFooter>
                  <div className={`w-full h-10 rounded-full border-2 flex items-center justify-center font-semibold text-sm transition-all ${
                    isSelected
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-white/20 text-muted-foreground"
                  }`}>
                    {isSelected ? "Selected ✓" : "Select Plan"}
                  </div>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}

      {/* Payment Dialog */}
      <Dialog open={!!selectedPlanId} onOpenChange={(open) => !open && setSelectedPlanId(null)}>
        <DialogContent className="sm:max-w-md bg-card border-white/10 text-foreground">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-display">
              <PiLogo className="w-5 h-5 text-primary" />
              Complete Pi Payment
            </DialogTitle>
            <DialogDescription>
              Activate <span className="font-semibold text-foreground">{selectedPlan?.name}</span> —{" "}
              <span className="text-primary font-bold">${usdTarget} USD</span>{" "}
              = <span className="text-primary font-bold">{selectedPlan?.piAmount} π</span> at live price
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {isConnected ? (
              <div className="p-3 rounded-xl bg-primary/10 border border-primary/20">
                <p className="text-xs text-muted-foreground mb-1">Pi Wallet (auto-filled)</p>
                <p className="text-sm font-mono text-primary font-medium break-all">{walletAddress}</p>
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="wallet">Your Pi Wallet Address</Label>
                <Input
                  id="wallet"
                  value={walletInput}
                  onChange={e => setWalletInput(e.target.value)}
                  placeholder="GC... your Pi wallet address"
                  className="bg-white/5 border-white/10 focus-visible:ring-primary font-mono text-sm"
                />
                <button
                  onClick={() => { setSelectedPlanId(null); setConnectModalOpen(true); }}
                  className="text-xs text-primary hover:underline"
                >
                  Or connect your Pi wallet for auto-fill →
                </button>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="txid">Pi Transaction ID</Label>
              <Input
                id="txid"
                value={txId}
                onChange={e => setTxId(e.target.value)}
                placeholder="Enter the Pi Network transaction ID"
                className="bg-white/5 border-white/10 focus-visible:ring-primary font-mono text-sm"
              />
              <p className="text-xs text-muted-foreground">
                Send <span className="font-bold text-primary">{selectedPlan?.piAmount} π</span> to{" "}
                <span className="font-mono text-primary">GCPiTubeOfficial314159</span> then paste the TX ID here.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Plan</span>
                <span className="font-semibold">{selectedPlan?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">USD Value</span>
                <span className="font-bold text-foreground">${usdTarget}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Pi Amount (live)</span>
                <span className="font-bold text-primary">{selectedPlan?.piAmount} π</span>
              </div>
              {livePrice > 0 && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rate</span>
                  <span className="text-muted-foreground">1 π = ${livePrice.toFixed(4)}</span>
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setSelectedPlanId(null)} className="rounded-full">Cancel</Button>
            <Button
              onClick={handleSubscribe}
              disabled={!txId.trim() || !effectiveWallet.trim() || createSubMutation.isPending}
              className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
            >
              {createSubMutation.isPending ? "Verifying..." : "Activate Premium"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConnectWalletModal open={connectModalOpen} onClose={() => setConnectModalOpen(false)} />
    </div>
  );
}
