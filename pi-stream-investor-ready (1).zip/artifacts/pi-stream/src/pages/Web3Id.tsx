import { useWallet } from "@/context/WalletContext";
import { Link } from "wouter";
import { Star, Award, Globe, TrendingUp, Shield, Wallet, Copy, Check, BarChart3, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const BADGES = [
  { id: "original", name: "Original Creator", desc: "Non-transferable soulbound badge for verified original creators", earned: true, rarity: "Legendary", icon: "🏆" },
  { id: "pioneer", name: "Pi Pioneer", desc: "Early adopter of Pi Stream — joined in the first 1,000 users", earned: true, rarity: "Rare", icon: "🚀" },
  { id: "verified", name: "Verified Handle", desc: "Identity verified across all Web3 apps via Pi Network", earned: true, rarity: "Common", icon: "✅" },
  { id: "curator", name: "DAO Curator", desc: "Curated 50+ videos approved by community DAOs", earned: false, rarity: "Epic", icon: "🔮" },
  { id: "whale", name: "Token Whale", desc: "Staked 1,000+ π in DAO governance", earned: false, rarity: "Legendary", icon: "🐋" },
  { id: "streamer", name: "Live Legend", desc: "Hosted 10+ live streams with 1,000+ concurrent viewers", earned: false, rarity: "Epic", icon: "📡" },
];

const REPUTATION_FACTORS = [
  { label: "Watch Time Score", value: 8420, max: 10000, color: "bg-blue-500" },
  { label: "Content Quality", value: 7200, max: 10000, color: "bg-green-500" },
  { label: "Community Trust", value: 6800, max: 10000, color: "bg-primary" },
  { label: "DAO Participation", value: 4100, max: 10000, color: "bg-yellow-500" },
  { label: "Creator Consistency", value: 9100, max: 10000, color: "bg-pink-500" },
];

const WEB3_APPS = [
  { name: "Lens Protocol", handle: "@pitube", connected: true },
  { name: "Farcaster", handle: "!pitube.eth", connected: true },
  { name: "Pi Network", handle: "@pioneer", connected: true },
  { name: "ENS Domain", handle: "pitube.eth", connected: false },
  { name: "Solana Name", handle: "pitube.sol", connected: false },
];

const RARITY_COLOR: Record<string, string> = {
  Legendary: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10",
  Epic: "text-purple-400 border-purple-400/30 bg-purple-400/10",
  Rare: "text-blue-400 border-blue-400/30 bg-blue-400/10",
  Common: "text-green-400 border-green-400/30 bg-green-400/10",
};

export default function Web3Id() {
  const { isConnected, piUsername, walletAddress } = useWallet();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const reputationScore = Math.round(REPUTATION_FACTORS.reduce((a, f) => a + f.value, 0) / REPUTATION_FACTORS.length);

  const copyHandle = () => {
    navigator.clipboard.writeText("@" + (piUsername || "pioneer") + ".pi");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Handle copied!" });
  };

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] gap-4 text-muted-foreground">
        <Shield className="w-12 h-12 opacity-20" />
        <h2 className="text-xl font-display font-bold text-foreground">Web3 Identity</h2>
        <p className="text-sm text-center max-w-sm">Connect your Pi Wallet to view your Web3 identity, reputation score, and soulbound badges.</p>
        <Link href="/"><Button className="rounded-full bg-primary text-primary-foreground">Connect Wallet on Home</Button></Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 py-4">
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
          <Globe className="w-6 h-6 text-primary" /> Web3 Identity
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Soulbound badges, reputation score, and portable handle across all Web3 apps</p>
      </div>

      {/* Identity card */}
      <div className="rounded-2xl bg-gradient-to-br from-primary/15 via-card to-secondary/10 border border-primary/25 p-6">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center text-primary-foreground text-2xl font-bold shrink-0">
            {piUsername?.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-bold text-foreground">@{piUsername}</h2>
              <Badge className="bg-primary/20 text-primary border-primary/30">Verified ✓</Badge>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-sm font-mono text-muted-foreground truncate">{walletAddress?.slice(0, 20)}...</p>
              <button onClick={copyHandle} className="text-primary hover:text-primary/80">
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/8 border border-white/10 text-xs">
                <span className="font-mono text-primary font-semibold">@{piUsername}.pi</span>
                <span className="text-muted-foreground">· Portable Handle</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-primary">{reputationScore.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">Rep Score</p>
          </div>
        </div>
      </div>

      {/* Reputation breakdown */}
      <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><BarChart3 className="w-4 h-4 text-primary" />Reputation Breakdown</h3>
        <p className="text-xs text-muted-foreground">Score based on watch time, not just subscriber count — Sybil-resistant.</p>
        {REPUTATION_FACTORS.map(f => (
          <div key={f.label} className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">{f.label}</span>
              <span className="font-medium text-foreground">{f.value.toLocaleString()} / {f.max.toLocaleString()}</span>
            </div>
            <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div className={`h-full rounded-full ${f.color}`} style={{ width: `${(f.value / f.max) * 100}%` }} />
            </div>
          </div>
        ))}
      </div>

      {/* Soulbound Badges */}
      <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-foreground flex items-center gap-2"><Award className="w-4 h-4 text-primary" />Soulbound Badges</h3>
          <Badge variant="outline" className="text-xs border-white/15 text-muted-foreground">Non-transferable</Badge>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {BADGES.map(badge => (
            <div key={badge.id} className={`rounded-xl border p-3 space-y-1.5 transition-all ${badge.earned ? "border-primary/20 bg-primary/5" : "border-white/8 bg-white/3 opacity-50"}`}>
              <div className="flex items-center justify-between">
                <span className="text-2xl">{badge.icon}</span>
                <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${RARITY_COLOR[badge.rarity]}`}>{badge.rarity}</Badge>
              </div>
              <p className="text-xs font-semibold text-foreground">{badge.name}</p>
              <p className="text-[11px] text-muted-foreground leading-snug">{badge.desc}</p>
              {!badge.earned && <p className="text-[10px] text-muted-foreground italic">Locked</p>}
            </div>
          ))}
        </div>
      </div>

      {/* Cross-app handles */}
      <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><Globe className="w-4 h-4 text-primary" />Portable Handle — Web3 Apps</h3>
        <div className="space-y-2">
          {WEB3_APPS.map(app => (
            <div key={app.name} className="flex items-center justify-between py-2.5 border-b border-white/5 last:border-0">
              <div>
                <p className="text-sm font-medium text-foreground">{app.name}</p>
                <p className="text-xs font-mono text-muted-foreground">{app.handle}</p>
              </div>
              {app.connected ? (
                <Badge className="bg-green-500/10 text-green-400 border-green-500/20"><Check className="w-3 h-3 mr-1" />Connected</Badge>
              ) : (
                <Button size="sm" variant="outline" className="text-xs rounded-full border-white/15 hover:border-primary/40" onClick={() => toast({ title: `Connect ${app.name}`, description: "Opens Pi Network SDK wallet integration." })}>
                  Connect
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
