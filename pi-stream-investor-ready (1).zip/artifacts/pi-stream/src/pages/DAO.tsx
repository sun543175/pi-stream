import { useState } from "react";
import { Vote, Shield, Users, TrendingUp, Clock, CheckCircle2, XCircle, BarChart3, Gavel, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/context/WalletContext";
import { PiLogo } from "@/components/PiLogo";

type ProposalStatus = "active" | "passed" | "rejected" | "pending";

interface Proposal {
  id: number;
  title: string;
  description: string;
  category: string;
  votesFor: number;
  votesAgainst: number;
  totalStaked: number;
  status: ProposalStatus;
  endsIn: string;
  proposer: string;
}

const PROPOSALS: Proposal[] = [
  { id: 1, title: "Reduce algorithm weight for clickbait thumbnails by 40%", description: "DAO vote to penalize misleading thumbnails that don't match video content. Creators with 3+ violations lose recommendation boost.", category: "Algorithm", votesFor: 8420, votesAgainst: 1230, totalStaked: 9650, status: "active", endsIn: "2d 14h", proposer: "PiCrypto Labs" },
  { id: 2, title: "Add Science DAO as official feed curator", description: "Grant Science DAO curation rights over the Science & Education category. They will earn 0.001π per approved video.", category: "Governance", votesFor: 6100, votesAgainst: 890, totalStaked: 6990, status: "active", endsIn: "4d 2h", proposer: "DecentralFuture" },
  { id: 3, title: "Demonetization appeal window extended to 30 days", description: "Creators currently have 7 days to appeal demonetization. Proposal to extend to 30 days with community jury review.", category: "Monetization", votesFor: 12400, votesAgainst: 4100, totalStaked: 16500, status: "active", endsIn: "1d 8h", proposer: "Pi Academy" },
  { id: 4, title: "Mandatory 3-second unskippable Pi Stream intro removed", description: "Remove forced platform intro on all videos. Creators can keep branded intros voluntarily.", category: "UX", votesFor: 9800, votesAgainst: 200, totalStaked: 10000, status: "passed", endsIn: "Ended", proposer: "PiPioneer" },
  { id: 5, title: "Token-weighted moderation juries for DMCA disputes", description: "Replace staff reviewers with rotating 12-person token-weighted juries for copyright disputes. Jurors earn π per case.", category: "Moderation", votesFor: 4200, votesAgainst: 5800, totalStaked: 10000, status: "rejected", endsIn: "Ended", proposer: "Web3Builder" },
];

const STATUS_CONFIG: Record<ProposalStatus, { color: string; bg: string; label: string }> = {
  active: { color: "text-green-400", bg: "bg-green-500/10 border-green-500/20", label: "Active" },
  passed: { color: "text-primary", bg: "bg-primary/10 border-primary/20", label: "Passed ✓" },
  rejected: { color: "text-red-400", bg: "bg-red-500/10 border-red-500/20", label: "Rejected" },
  pending: { color: "text-yellow-400", bg: "bg-yellow-500/10 border-yellow-500/20", label: "Pending" },
};

export default function DAO() {
  const { isConnected, piUsername } = useWallet();
  const { toast } = useToast();
  const [voted, setVoted] = useState<Record<number, "for" | "against">>({});
  const [stakeAmount, setStakeAmount] = useState("1");
  const [filter, setFilter] = useState<"all" | ProposalStatus>("all");

  const handleVote = (id: number, side: "for" | "against") => {
    if (!isConnected) { toast({ title: "Connect Pi Wallet to vote", variant: "destructive" }); return; }
    if (voted[id]) { toast({ title: "Already voted on this proposal" }); return; }
    setVoted(v => ({ ...v, [id]: side }));
    toast({ title: `Voted ${side === "for" ? "✓ For" : "✗ Against"}`, description: `Your ${stakeAmount}π vote has been staked on proposal #${id}.` });
  };

  const filtered = filter === "all" ? PROPOSALS : PROPOSALS.filter(p => p.status === filter);
  const totalStaked = PROPOSALS.reduce((a, p) => a + p.totalStaked, 0);
  const activeCount = PROPOSALS.filter(p => p.status === "active").length;

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-4">
      <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 px-4 py-3 flex items-start gap-3">
        <Clock className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
        <div>
          <p className="text-sm font-semibold text-amber-400">Coming Soon — Testnet Demo Only</p>
          <p className="text-xs text-muted-foreground mt-0.5">DAO governance contracts are in development. Votes shown are simulated and have no on-chain effect.</p>
        </div>
      </div>
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
            <Gavel className="w-6 h-6 text-primary" /> Pi Stream DAO
          </h1>
          <p className="text-muted-foreground text-sm mt-1">Decentralized governance — token-weighted votes shape the platform</p>
        </div>
        {isConnected && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-sm">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-primary font-medium">@{piUsername}</span>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { icon: Vote, label: "Active Proposals", value: activeCount, color: "text-green-400" },
          { icon: Coins, label: "Total π Staked", value: `${totalStaked.toLocaleString()} π`, color: "text-primary" },
          { icon: Users, label: "DAO Members", value: "—", color: "text-blue-400" },
          { icon: CheckCircle2, label: "Proposals Passed", value: "47", color: "text-yellow-400" },
        ].map(s => (
          <div key={s.label} className="bg-card border border-white/8 rounded-2xl p-4">
            <s.icon className={`w-4 h-4 ${s.color} mb-2`} />
            <p className="text-lg font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Vote stake */}
      <div className="rounded-2xl bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20 p-4 flex flex-col md:flex-row items-center gap-4">
        <div className="flex-1">
          <p className="font-semibold text-foreground text-sm">Your Voting Power</p>
          <p className="text-xs text-muted-foreground mt-0.5">Stake more π to increase your vote weight. 1π = 1 vote.</p>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="number"
            min="0.1"
            step="0.1"
            value={stakeAmount}
            onChange={e => setStakeAmount(e.target.value)}
            className="w-20 bg-white/10 border border-white/20 rounded-xl px-3 py-1.5 text-sm text-foreground text-center focus:outline-none focus:border-primary"
          />
          <span className="text-sm text-muted-foreground">π per vote</span>
        </div>
        <Button size="sm" className="rounded-full bg-primary text-primary-foreground">
          <PiLogo className="w-3.5 h-3.5 mr-1.5" /> Stake π
        </Button>
      </div>

      {/* Filter */}
      <div className="flex gap-2 flex-wrap">
        {(["all", "active", "passed", "rejected"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium capitalize transition-all ${filter === f ? "bg-primary text-primary-foreground" : "bg-white/5 text-muted-foreground hover:bg-white/10"}`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Proposals */}
      <div className="space-y-4">
        {filtered.map(proposal => {
          const cfg = STATUS_CONFIG[proposal.status];
          const pct = Math.round((proposal.votesFor / (proposal.votesFor + proposal.votesAgainst)) * 100);
          const myVote = voted[proposal.id];
          const isActive = proposal.status === "active";

          return (
            <div key={proposal.id} className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1.5">
                    <Badge variant="outline" className="text-xs border-white/15 text-muted-foreground">{proposal.category}</Badge>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                    {isActive && (
                      <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" />{proposal.endsIn} left</span>
                    )}
                  </div>
                  <h3 className="font-semibold text-foreground text-sm leading-snug">{proposal.title}</h3>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{proposal.description}</p>
                  <p className="text-xs text-muted-foreground mt-1">Proposed by <span className="text-primary">@{proposal.proposer}</span></p>
                </div>
              </div>

              {/* Vote bar */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span className="text-green-400 font-medium">For: {proposal.votesFor.toLocaleString()} π ({pct}%)</span>
                  <span className="text-red-400 font-medium">Against: {proposal.votesAgainst.toLocaleString()} π ({100 - pct}%)</span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-green-500 to-green-400 rounded-full transition-all" style={{ width: `${pct}%` }} />
                </div>
                <p className="text-xs text-muted-foreground text-right">{proposal.totalStaked.toLocaleString()} π total staked</p>
              </div>

              {/* Vote buttons */}
              {isActive && (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => handleVote(proposal.id, "for")}
                    disabled={!!myVote}
                    className={`flex-1 rounded-full gap-1.5 ${myVote === "for" ? "bg-green-500 text-white" : "bg-green-500/10 text-green-400 hover:bg-green-500/20 border border-green-500/20"}`}
                    variant="ghost"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {myVote === "for" ? "Voted For ✓" : `Vote For (${stakeAmount}π)`}
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleVote(proposal.id, "against")}
                    disabled={!!myVote}
                    className={`flex-1 rounded-full gap-1.5 ${myVote === "against" ? "bg-red-500 text-white" : "bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20"}`}
                    variant="ghost"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    {myVote === "against" ? "Voted Against ✓" : "Vote Against"}
                  </Button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Submit proposal CTA */}
      <div className="rounded-2xl border border-dashed border-primary/30 p-6 text-center space-y-3">
        <Shield className="w-8 h-8 text-primary mx-auto opacity-60" />
        <h3 className="font-semibold text-foreground">Submit a Governance Proposal</h3>
        <p className="text-sm text-muted-foreground">Requires 100π staked. Proposals are voted on for 7 days by token holders.</p>
        <Button className="rounded-full bg-primary text-primary-foreground gap-2" onClick={() => toast({ title: "Coming soon", description: "Proposal submission requires 100π minimum stake." })}>
          <Gavel className="w-4 h-4" /> New Proposal
        </Button>
      </div>
    </div>
  );
}
