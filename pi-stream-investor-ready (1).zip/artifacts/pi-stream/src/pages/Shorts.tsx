import { useListVideos, getListVideosQueryKey, useLikeVideo } from "@workspace/api-client-react";
import { useState, useRef } from "react";
import { Heart, MessageCircle, Share2, Bookmark, Music2, ChevronUp, ChevronDown, Volume2, VolumeX } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function Shorts() {
  const { data: videos } = useListVideos(undefined, { query: { queryKey: getListVideosQueryKey() } });
  const [currentIdx, setCurrentIdx] = useState(0);
  const [liked, setLiked] = useState<Set<number>>(new Set());
  const [saved, setSaved] = useState<Set<number>>(new Set());
  const [muted, setMuted] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const likeMutation = useLikeVideo();

  const shorts = (videos || []).slice(0, 20);
  const video = shorts[currentIdx];

  const go = (dir: 1 | -1) => {
    setCurrentIdx(i => Math.max(0, Math.min(shorts.length - 1, i + dir)));
  };

  const toggleLike = (id: number) => {
    setLiked(prev => {
      const next = new Set(prev);
      if (next.has(id)) { next.delete(id); }
      else {
        next.add(id);
        likeMutation.mutate({ id });
      }
      return next;
    });
  };

  const toggleSave = (id: number) => {
    setSaved(prev => {
      const next = new Set(prev);
      if (next.has(id)) { next.delete(id); toast({ title: "Removed from Watch Later" }); }
      else { next.add(id); toast({ title: "Saved to Watch Later" }); }
      return next;
    });
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.origin + "/watch/" + video?.id);
    toast({ title: "Link copied!" });
  };

  const onWheel = (e: React.WheelEvent) => {
    if (e.deltaY > 0) go(1);
    else go(-1);
  };

  if (!video) {
    return (
      <div className="flex items-center justify-center h-[70vh] text-muted-foreground">
        <div className="text-center space-y-2">
          <Music2 className="w-12 h-12 mx-auto opacity-30" />
          <p>No shorts available yet</p>
        </div>
      </div>
    );
  }

  const isLiked = liked.has(video.id);
  const isSaved = saved.has(video.id);

  return (
    <div className="flex justify-center">
      <div className="relative w-full max-w-sm" style={{ height: "calc(100vh - 100px)" }}>
        {/* Main short card */}
        <div
          ref={containerRef}
          className="relative w-full h-full rounded-2xl overflow-hidden bg-black cursor-grab active:cursor-grabbing select-none"
          onWheel={onWheel}
          style={{
            background: `linear-gradient(160deg, ${video.thumbnailColor ?? "#1a1a2e"} 0%, ${video.thumbnailColor2 ?? "#2d1b69"} 100%)`,
          }}
        >
          {/* Video placeholder with animation */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-8xl opacity-20 font-bold text-white select-none">π</div>
          </div>

          {/* Bottom overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 via-black/30 to-transparent">
            <Link href={`/channel/${encodeURIComponent(video.channelName)}`}>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xs">
                  {video.channelName?.charAt(0)}
                </div>
                <span className="text-white font-semibold text-sm">@{video.channelName?.toLowerCase().replace(/\s/g, "")}</span>
                {video.isVerified && <span className="text-primary text-xs">✓</span>}
              </div>
            </Link>
            <p className="text-white text-sm font-medium line-clamp-2 mb-1">{video.title}</p>
            <div className="flex items-center gap-2 text-white/60 text-xs">
              <span>{video.views} views</span>
              <span>·</span>
              <span>{video.duration}</span>
            </div>
          </div>

          {/* Top bar */}
          <div className="absolute top-4 left-4 right-4 flex justify-between items-center">
            <span className="text-white/70 text-xs font-medium bg-black/30 px-2 py-1 rounded-full">{currentIdx + 1} / {shorts.length}</span>
            <button onClick={() => setMuted(m => !m)} className="p-2 rounded-full bg-black/30 text-white">
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Side action buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-14 flex flex-col gap-5 items-center">
          <button
            onClick={() => toggleLike(video.id)}
            className="flex flex-col items-center gap-1 group"
          >
            <div className={`p-3 rounded-full transition-all ${isLiked ? "bg-red-500 text-white scale-110" : "bg-black/60 text-white hover:bg-black/80"}`}>
              <Heart className={`w-5 h-5 ${isLiked ? "fill-current" : ""}`} />
            </div>
            <span className="text-xs text-foreground font-medium">{(video.likes || 0) + (isLiked ? 1 : 0)}</span>
          </button>

          <button className="flex flex-col items-center gap-1">
            <div className="p-3 rounded-full bg-black/60 text-white hover:bg-black/80 transition-all">
              <MessageCircle className="w-5 h-5" />
            </div>
            <span className="text-xs text-foreground font-medium">Chat</span>
          </button>

          <button onClick={handleShare} className="flex flex-col items-center gap-1">
            <div className="p-3 rounded-full bg-black/60 text-white hover:bg-black/80 transition-all">
              <Share2 className="w-5 h-5" />
            </div>
            <span className="text-xs text-foreground font-medium">Share</span>
          </button>

          <button onClick={() => toggleSave(video.id)} className="flex flex-col items-center gap-1">
            <div className={`p-3 rounded-full transition-all ${isSaved ? "bg-primary text-white" : "bg-black/60 text-white hover:bg-black/80"}`}>
              <Bookmark className={`w-5 h-5 ${isSaved ? "fill-current" : ""}`} />
            </div>
            <span className="text-xs text-foreground font-medium">{isSaved ? "Saved" : "Save"}</span>
          </button>
        </div>

        {/* Up/Down navigation */}
        <div className="absolute -left-12 top-1/2 -translate-y-1/2 flex flex-col gap-2">
          <button
            onClick={() => go(-1)}
            disabled={currentIdx === 0}
            className="p-2 rounded-full bg-card border border-white/10 text-foreground disabled:opacity-30 hover:bg-white/10 transition-all"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <button
            onClick={() => go(1)}
            disabled={currentIdx === shorts.length - 1}
            className="p-2 rounded-full bg-card border border-white/10 text-foreground disabled:opacity-30 hover:bg-white/10 transition-all"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>

        {/* Progress dots */}
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 flex gap-1">
          {shorts.slice(Math.max(0, currentIdx - 3), currentIdx + 4).map((_, i) => {
            const realIdx = Math.max(0, currentIdx - 3) + i;
            return (
              <div
                key={realIdx}
                onClick={() => setCurrentIdx(realIdx)}
                className={`rounded-full cursor-pointer transition-all ${realIdx === currentIdx ? "w-4 h-1.5 bg-primary" : "w-1.5 h-1.5 bg-white/30"}`}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
