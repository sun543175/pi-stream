import { useGetPiExchangeRate, getGetPiExchangeRateQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeftRight, Download, ExternalLink, Info, LineChart } from "lucide-react";
import { PiLogo } from "@/components/PiLogo";

export default function Exchange() {
  const { data: rate, isLoading } = useGetPiExchangeRate({ query: { queryKey: getGetPiExchangeRateQueryKey() } });

  const handleDownload = () => {
    if (!rate) return;
    const blob = new Blob([JSON.stringify(rate, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pi-exchange-rates-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return <div className="text-center py-12 text-muted-foreground">Loading exchange data...</div>;
  }

  if (!rate) return null;

  return (
    <div className="flex flex-col max-w-5xl mx-auto gap-8 py-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
            <PiLogo className="w-8 h-8 text-primary" />
            Pi Coin Exchange
          </h1>
          <p className="text-muted-foreground mt-2">Track Pi Network testnet exchange rates and market data.</p>
        </div>
        <Button onClick={handleDownload} variant="outline" className="rounded-full gap-2 border-white/10 hover:bg-white/5 w-fit">
          <Download className="w-4 h-4" />
          Download Exchange Data (JSON)
        </Button>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-card border-primary/30 shadow-[0_0_30px_-15px_rgba(245,158,11,0.2)]">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center"><PiLogo className="w-4 h-4 text-primary" glow={false}/></span>
              Global Consensus Value
            </CardTitle>
            <CardDescription>The community-agreed target value for Pi.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-5xl font-display font-bold text-primary tracking-tight">
              ${rate.piUsdGcv.toLocaleString()}
            </div>
            <p className="text-sm text-muted-foreground mt-4 flex items-center gap-2">
              <Info className="w-4 h-4" />
              Community-agreed target value. Not a guaranteed or official price. Testnet demo only.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-white/10">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center"><LineChart className="w-4 h-4 text-white" /></span>
              Estimated Market Rate
            </CardTitle>
            <CardDescription>Current unverified trading value on unofficial markets.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-display font-bold text-foreground">
              ${rate.piUsdMarket.toFixed(2)}
            </div>
            <p className="text-sm text-muted-foreground mt-4 flex items-center gap-2">
              <Info className="w-4 h-4" />
              Unofficial estimate only. Not financial advice.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground mt-4">Exchange Options</h2>
        <p className="text-muted-foreground">External platforms where you can trade or utilize Pi coin.</p>
        
        <div className="grid gap-4">
          {rate.exchangeOptions.map((option, i) => (
            <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 transition-colors gap-4">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${option.supported ? 'bg-primary/20 text-primary' : 'bg-white/10 text-muted-foreground'}`}>
                  <ArrowLeftRight className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground text-lg">{option.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-muted-foreground uppercase tracking-wider font-medium">{option.type}</span>
                    <span className="w-1 h-1 rounded-full bg-white/20"></span>
                    <span className={`text-xs font-medium ${option.supported ? 'text-green-500' : 'text-amber-500'}`}>
                      {option.supported ? 'Fully Supported' : 'Experimental / Unofficial'}
                    </span>
                  </div>
                </div>
              </div>
              <Button asChild variant="secondary" className="rounded-full bg-white/10 hover:bg-white/20 border border-white/10">
                <a href={option.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                  Visit <ExternalLink className="w-4 h-4" />
                </a>
              </Button>
            </div>
          ))}
        </div>
      </div>
      
      <div className="text-center text-xs text-muted-foreground mt-8">
        Last updated: {new Date(rate.lastUpdated).toLocaleString()}
      </div>
    </div>
  );
}
