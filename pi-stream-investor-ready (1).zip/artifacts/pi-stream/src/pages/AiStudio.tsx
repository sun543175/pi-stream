import { useState } from "react";
import { Sparkles, Mic, DollarSign, Wand2, Bot, Volume2, TrendingUp, CheckCircle2, Play, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/context/WalletContext";
import { PiLogo } from "@/components/PiLogo";

const AD_RATES = [
  { platform: "Pi Network", rate: "2.4 π CPM", trend: "+12%", active: true },
  { platform: "Web3 DAOs", rate: "1.8 π CPM", trend: "+5%", active: true },
  { platform: "DeFi Sponsors", rate: "4.2 π CPM", trend: "+28%", active: false },
  { platform: "NFT Projects", rate: "3.1 π CPM", trend: "+15%", active: false },
];

const DUBS = [
  { lang: "Spanish (ES)", voice: "Elena Voice-NFT", licensed: true, plays: 1240 },
  { lang: "Hindi (HI)", voice: "Aryan Voice-NFT", licensed: true, plays: 890 },
  { lang: "Chinese (ZH)", voice: "Wei Voice-NFT", licensed: false, plays: 0 },
  { lang: "Arabic (AR)", voice: "Fatima Voice-NFT", licensed: false, plays: 0 },
  { lang: "French (FR)", voice: "Camille Voice-NFT", licensed: false, plays: 0 },
];

export default function AiStudio() {
  const { isConnected } = useWallet();
  const { toast } = useToast();
  const [tab, setTab] = useState<"editor" | "dubbing" | "ads">("editor");
  const [editing, setEditing] = useState(false);
  const [editProgress, setEditProgress] = useState(0);
  const [negotiating, setNegotiating] = useState(false);
  const [negotiated, setNegotiated] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [licensingId, setLicensingId] = useState<string | null>(null);

  const runEdit = async () => {
    if (!prompt.trim()) { toast({ title: "Enter an edit prompt first" }); return; }
    if (!isConnected) { toast({ title: "Connect Pi Wallet — AI co-editor charges 0.01π/edit", variant: "destructive" }); return; }
    setEditing(true);
    for (let i = 0; i <= 100; i += 10) {
      await new Promise(r => setTimeout(r, 120));
      setEditProgress(i);
    }
    setEditing(false);
    setEditProgress(0);
    setPrompt("");
    toast({ title: "✅ AI Edit Applied!", description: "0.01π deducted via smart contract. Edit committed to NFT history." });
  };

  const runNegotiate = async () => {
    setNegotiating(true);
    await new Promise(r => setTimeout(r, 2200));
    setNegotiating(false);
    setNegotiated(true);
    toast({ title: "🤝 AI Negotiated +18% higher ad rate!", description: "DeFi Sponsors deal: 4.2π → 4.96π CPM. Contract auto-signed." });
  };

  const licenseDub = async (lang: string) => {
    setLicensingId(lang);
    await new Promise(r => setTimeout(r, 1500));
    setLicensingId(null);
    toast({ title: `🎙️ ${lang} Voice-NFT Licensed!`, description: "Royalties auto-split to voice artist via smart contract." });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-4">
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-primary" /> AI + Web3 Studio
        </h1>
        <p className="text-muted-foreground text-sm mt-1">AI co-editor, real-time dubbing with Voice-NFTs, and AI ad rate negotiation</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-white/5 p-1 rounded-xl w-fit">
        {([
          { id: "editor", label: "AI Co-Editor", icon: Wand2 },
          { id: "dubbing", label: "Voice Dubbing", icon: Mic },
          { id: "ads", label: "Ad Negotiation", icon: DollarSign },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${tab === t.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            <t.icon className="w-3.5 h-3.5" />{t.label}
          </button>
        ))}
      </div>

      {tab === "editor" && (
        <div className="space-y-4">
          <div className="bg-card border border-white/8 rounded-2xl p-6 space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">AI Co-Editor</h3>
                <p className="text-xs text-muted-foreground mt-0.5">AI edits are automatically paid via smart contract (0.01π per edit). All changes stored on-chain in NFT edit history.</p>
              </div>
            </div>

            <div className="rounded-xl bg-black/30 border border-white/10 p-4 min-h-32 font-mono text-sm text-muted-foreground relative">
              <div className="absolute top-2 right-3 flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse" />
                <span className="text-xs text-green-400">AI Ready</span>
              </div>
              <p className="text-foreground/80">📹 <span className="text-primary">Pi_Network_Deep_Dive.mp4</span> — 28:15 · 4K HDR</p>
              <p className="mt-2">→ Timeline loaded. 847 frames analyzed.</p>
              <p className="mt-1">→ Detected: 3 potential jump cuts, 1 audio dip at 12:34</p>
              {editing && <p className="mt-2 text-primary animate-pulse">→ Applying: "{prompt}"...</p>}
            </div>

            <div className="flex gap-2">
              <input
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                placeholder='e.g. "Remove all silences over 2 seconds" or "Add chapter markers"'
                className="flex-1 bg-white/5 border border-white/15 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
                onKeyDown={e => e.key === "Enter" && runEdit()}
              />
              <Button onClick={runEdit} disabled={editing} className="rounded-xl bg-primary text-primary-foreground gap-1.5 shrink-0">
                {editing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                {editing ? `${editProgress}%` : "Apply (0.01π)"}
              </Button>
            </div>

            {editing && (
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div className="h-full bg-primary transition-all duration-100" style={{ width: `${editProgress}%` }} />
              </div>
            )}

            <div className="grid grid-cols-3 gap-2">
              {["Remove silences", "Add captions", "Color grade"].map(s => (
                <button key={s} onClick={() => setPrompt(s)} className="text-xs py-2 px-3 rounded-xl bg-white/5 border border-white/10 text-muted-foreground hover:border-primary/40 hover:text-primary transition-all text-left">{s}</button>
              ))}
            </div>

            <div className="flex items-center gap-2 text-xs text-muted-foreground p-3 rounded-xl bg-white/3 border border-white/8">
              <PiLogo className="w-3.5 h-3.5 text-primary" />
              AI co-editor wallet: <span className="font-mono text-primary">GCAIPiTubeBot9182</span> · Paid automatically per edit via contract
            </div>
          </div>
        </div>
      )}

      {tab === "dubbing" && (
        <div className="space-y-4">
          <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
                <Volume2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Real-Time Dubbing with Voice-NFTs</h3>
                <p className="text-xs text-muted-foreground">Each voice is a licensed NFT. Royalties split automatically to voice artists.</p>
              </div>
            </div>
            <div className="space-y-2">
              {DUBS.map(dub => (
                <div key={dub.lang} className="flex items-center gap-4 py-3 border-b border-white/5 last:border-0">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{dub.lang}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1.5 mt-0.5">
                      <Mic className="w-3 h-3" />{dub.voice}
                      {dub.licensed && <><span>·</span><span>{dub.plays.toLocaleString()} plays</span></>}
                    </p>
                  </div>
                  {dub.licensed ? (
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="ghost" className="rounded-full gap-1 text-xs bg-white/5 hover:bg-white/10">
                        <Play className="w-3 h-3" />Preview
                      </Button>
                      <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs"><CheckCircle2 className="w-3 h-3 mr-1" />Licensed</Badge>
                    </div>
                  ) : (
                    <Button size="sm" onClick={() => licenseDub(dub.lang)} disabled={licensingId === dub.lang} className="rounded-full bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 text-xs gap-1.5">
                      {licensingId === dub.lang ? <><Loader2 className="w-3 h-3 animate-spin" />Licensing...</> : <><Mic className="w-3 h-3" />License (0.5π)</>}
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === "ads" && (
        <div className="space-y-4">
          <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Personal AI Ad Rate Negotiator</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Your AI agent negotiates ad rates on your behalf, signs smart contracts automatically, and splits revenue via Pi wallet.</p>
              </div>
            </div>

            <div className="space-y-2">
              {AD_RATES.map(ad => (
                <div key={ad.platform} className={`flex items-center justify-between py-3 px-4 rounded-xl border transition-all ${ad.active ? "border-primary/20 bg-primary/5" : "border-white/8 bg-white/3"}`}>
                  <div>
                    <p className="text-sm font-medium text-foreground">{ad.platform}</p>
                    <p className="text-xs text-muted-foreground">Current rate: <span className="text-primary font-semibold">{ad.rate}</span></p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-green-400">{ad.trend}</span>
                    {ad.active ? (
                      <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">Active</Badge>
                    ) : (
                      <Badge variant="outline" className="text-xs border-white/15 text-muted-foreground">Available</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className={`p-4 rounded-xl border transition-all ${negotiated ? "border-green-500/30 bg-green-500/5" : "border-primary/20 bg-primary/5"}`}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-sm font-semibold text-foreground">{negotiated ? "✅ Deal Secured!" : "Run AI Negotiation"}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{negotiated ? "DeFi Sponsors: 4.2π → 4.96π CPM (+18%). Contract auto-signed." : "AI will contact DeFi Sponsors & NFT Projects to negotiate better rates."}</p>
                </div>
                {!negotiated && (
                  <Button onClick={runNegotiate} disabled={negotiating} size="sm" className="rounded-full bg-primary text-primary-foreground gap-1.5 shrink-0">
                    {negotiating ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Negotiating...</> : <><TrendingUp className="w-3.5 h-3.5" />Negotiate</>}
                  </Button>
                )}
              </div>
              {negotiating && (
                <div className="text-xs text-muted-foreground space-y-0.5 font-mono">
                  <p className="text-green-400">→ Analyzing your channel metrics...</p>
                  <p className="animate-pulse">→ Contacting DeFi Sponsors API...</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
