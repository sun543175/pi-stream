import { useState } from "react";
import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { Glasses, Mic, Headphones, Users, Lock, Ticket, MessageCircle, Zap, Globe, Play, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { PiLogo } from "@/components/PiLogo";
import { useWallet } from "@/context/WalletContext";

const PARTIES = [
  { id: 1, title: "Pi Summit 2026 — VR Keynote", host: "@DecentralFuture", viewers: 1240, maxViewers: 2000, price: "5 π", status: "live", spatial: true, gated: true },
  { id: 2, title: "Crypto Gaming Night — VR Arena", host: "@PiGamer", viewers: 340, maxViewers: 500, price: "1 π", status: "live", spatial: true, gated: false },
  { id: 3, title: "Metaverse Art Gallery Walk", host: "@PiArt", viewers: 89, maxViewers: 200, price: "2 π", status: "scheduled", spatial: true, gated: true },
  { id: 4, title: "Pi Network Q&A — Live Panel", host: "@PiNetwork", viewers: 4200, maxViewers: 10000, price: "Free", status: "live", spatial: false, gated: false },
];

const COMMENTS = [
  { user: "@pioneer42", text: "The spatial audio in this VR party is 🔥", time: "2s ago", ts: "12:34" },
  { user: "@pibuilder", text: "My avatar is standing right next to @pioneer42 lol", time: "5s ago", ts: "12:34" },
  { user: "@cryptofan", text: "This beat drop at 12:30 was insane", time: "15s ago", ts: "12:30" },
  { user: "@nftcollector", text: "Just placed my NFT poster in the metaverse venue", time: "30s ago", ts: "12:28" },
];

export default function VrParty() {
  const { data: videos } = useListVideos(undefined, { query: { queryKey: getListVideosQueryKey() } });
  const { isConnected } = useWallet();
  const { toast } = useToast();
  const [joining, setJoining] = useState<number | null>(null);
  const [joined, setJoined] = useState<Set<number>>(new Set());
  const [comment, setComment] = useState("");

  const joinParty = async (id: number, price: string, gated: boolean) => {
    if (!isConnected && gated) { toast({ title: "Connect Pi Wallet to join token-gated party", variant: "destructive" }); return; }
    setJoining(id);
    await new Promise(r => setTimeout(r, 1500));
    setJoining(null);
    setJoined(s => new Set([...s, id]));
    toast({ title: "🥽 Joined VR Watch Party!", description: price !== "Free" ? `${price} deducted from Pi Wallet. Enjoy the spatial audio!` : "Welcome to the VR party!" });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-4">
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
          <Glasses className="w-6 h-6 text-primary" /> VR Watch Parties
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Token-gated VR watch parties with spatial audio. Hologram comments anchored to timestamps.</p>
      </div>

      {/* Feature highlights */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { icon: Headphones, label: "Spatial Audio", desc: "3D surround sound" },
          { icon: Lock, label: "Token-Gated", desc: "NFT / π access" },
          { icon: Globe, label: "Metaverse NFTs", desc: "Place in virtual venue" },
          { icon: MessageCircle, label: "Hologram Chat", desc: "Anchored to timestamp" },
        ].map(f => (
          <div key={f.label} className="bg-card border border-white/8 rounded-2xl p-4 text-center space-y-1">
            <f.icon className="w-5 h-5 text-primary mx-auto" />
            <p className="text-xs font-semibold text-foreground">{f.label}</p>
            <p className="text-[10px] text-muted-foreground">{f.desc}</p>
          </div>
        ))}
      </div>

      {/* Active parties */}
      <div className="space-y-3">
        <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider text-muted-foreground">Active & Upcoming Parties</h3>
        {PARTIES.map(party => {
          const pct = Math.round((party.viewers / party.maxViewers) * 100);
          const isJoined = joined.has(party.id);
          return (
            <div key={party.id} className="bg-card border border-white/8 rounded-2xl p-5 space-y-3 hover:border-primary/20 transition-all">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {party.status === "live" && (
                      <div className="flex items-center gap-1 bg-red-500/10 border border-red-500/20 text-red-400 text-[10px] font-bold px-2 py-0.5 rounded-full">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />LIVE
                      </div>
                    )}
                    {party.gated && <Badge variant="outline" className="text-[10px] border-primary/30 text-primary px-1.5 py-0"><Lock className="w-2.5 h-2.5 mr-1" />Token-Gated</Badge>}
                    {party.spatial && <Badge variant="outline" className="text-[10px] border-white/15 text-muted-foreground px-1.5 py-0"><Headphones className="w-2.5 h-2.5 mr-1" />Spatial Audio</Badge>}
                  </div>
                  <h3 className="font-semibold text-foreground text-sm">{party.title}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">Hosted by <span className="text-primary">{party.host}</span></p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-bold text-primary">{party.price}</p>
                  <p className="text-[10px] text-muted-foreground">entry</p>
                </div>
              </div>

              {/* Viewer bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Users className="w-3 h-3" />{party.viewers.toLocaleString()} watching</span>
                  <span>{pct}% capacity</span>
                </div>
                <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className={`h-full rounded-full transition-all ${pct > 80 ? "bg-red-500" : "bg-primary"}`} style={{ width: `${pct}%` }} />
                </div>
              </div>

              <div className="flex items-center gap-2">
                {isJoined ? (
                  <Button size="sm" className="rounded-full bg-primary text-primary-foreground gap-1.5 flex-1">
                    <Glasses className="w-3.5 h-3.5" />You're In — VR View
                  </Button>
                ) : (
                  <Button size="sm" onClick={() => joinParty(party.id, party.price, party.gated)} disabled={joining === party.id} className="rounded-full bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 gap-1.5 flex-1">
                    {joining === party.id ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Joining...</> : <><Play className="w-3.5 h-3.5" />Join Party</>}
                  </Button>
                )}
                <Button size="sm" variant="outline" className="rounded-full border-white/10 gap-1.5" onClick={() => toast({ title: "Ticket NFT", description: "Livestream tickets are soulbound NFT passes — non-transferable." })}>
                  <Ticket className="w-3.5 h-3.5" />NFT Pass
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Hologram comments */}
      <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><MessageCircle className="w-4 h-4 text-primary" />Hologram Comments — Anchored to Timestamps</h3>
        <p className="text-xs text-muted-foreground">Comments appear as 3D holograms at the exact timestamp you were watching. Other viewers see them floating in the VR space.</p>
        <div className="space-y-2">
          {COMMENTS.map((c, i) => (
            <div key={i} className="flex items-start gap-3 py-2 border-b border-white/5 last:border-0">
              <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">{c.user.charAt(1).toUpperCase()}</div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-foreground">{c.user}</span>
                  <Badge variant="outline" className="text-[10px] border-primary/20 text-primary px-1 py-0">⏱ {c.ts}</Badge>
                  <span className="text-[10px] text-muted-foreground">{c.time}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{c.text}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            value={comment}
            onChange={e => setComment(e.target.value)}
            placeholder="Add hologram comment at current timestamp..."
            className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
          />
          <Button size="sm" className="rounded-xl bg-primary text-primary-foreground" onClick={() => { if (comment) { toast({ title: "💬 Hologram placed!" }); setComment(""); } }}>
            <Zap className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
