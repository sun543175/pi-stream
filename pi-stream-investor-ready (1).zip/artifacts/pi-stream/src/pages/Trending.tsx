import { useListTrendingVideos, getListTrendingVideosQueryKey } from "@workspace/api-client-react";
import { VideoCard } from "@/components/video/VideoCard";
import { useState } from "react";
import { Flame, TrendingUp, Clock } from "lucide-react";

const TIME_FILTERS = [
  { label: "24 Hours", value: "24h", icon: Clock },
  { label: "7 Days", value: "7d", icon: TrendingUp },
  { label: "30 Days", value: "30d", icon: Flame },
] as const;

type TimeFilter = typeof TIME_FILTERS[number]["value"];

export default function Trending() {
  const [timeFilter, setTimeFilter] = useState<TimeFilter>("24h");

  const { data: videos, isLoading } = useListTrendingVideos({
    query: { queryKey: getListTrendingVideosQueryKey() }
  });

  const sortedVideos = (() => {
    if (!videos) return [];
    const sorted = [...videos];
    if (timeFilter === "24h") return sorted.sort((a, b) => (b.likes || 0) - (a.likes || 0));
    if (timeFilter === "7d") return sorted.sort((a, b) => parseFloat(String(b.views)) - parseFloat(String(a.views)));
    return sorted;
  })();

  return (
    <div className="pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
            <Flame className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold text-foreground">Trending</h1>
            <p className="text-sm text-muted-foreground">What's hot on Pi Network right now</p>
          </div>
        </div>

        {/* Time Filter */}
        <div className="flex gap-2 p-1 rounded-xl bg-white/5 border border-white/10">
          {TIME_FILTERS.map(({ label, value, icon: Icon }) => (
            <button
              key={value}
              onClick={() => setTimeFilter(value)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                timeFilter === value
                  ? "bg-primary text-primary-foreground shadow-lg"
                  : "text-muted-foreground hover:text-foreground hover:bg-white/5"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="w-full aspect-video rounded-xl bg-white/5 mb-3" />
              <div className="h-4 bg-white/5 rounded w-3/4 mb-2" />
              <div className="h-3 bg-white/5 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : (
        <>
          {/* Top 3 Spotlight */}
          {sortedVideos.length > 0 && (
            <div className="mb-8">
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-4">Top trending</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {sortedVideos.slice(0, 3).map((video, i) => (
                  <div key={video.id} className="relative">
                    <div className="absolute -top-2 -left-2 z-10 w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-display font-bold text-sm shadow-lg">
                      #{i + 1}
                    </div>
                    <VideoCard video={video} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Rest */}
          {sortedVideos.length > 3 && (
            <>
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-4">More trending</p>
              <div className="flex flex-col gap-4">
                {sortedVideos.slice(3).map((video, i) => (
                  <div key={video.id} className="flex items-center gap-4">
                    <span className="text-2xl font-display font-bold text-white/20 w-8 text-right shrink-0">{i + 4}</span>
                    <div className="flex-1">
                      <VideoCard video={video} layout="list" />
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {sortedVideos.length === 0 && (
            <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
              <Flame className="w-12 h-12 mb-3 opacity-30" />
              <p className="font-semibold">No trending videos found</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
