import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { VideoCard } from "@/components/video/VideoCard";
import { useParams } from "wouter";
import { CheckCircle2, Users, PlaySquare, ThumbsUp, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Channel() {
  const { name } = useParams<{ name: string }>();
  const channelName = decodeURIComponent(name || "");
  const { toast } = useToast();
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isNotified, setIsNotified] = useState(false);
  const [subCount, setSubCount] = useState(Math.floor(Math.random() * 900000) + 100000);

  const { data: allVideos, isLoading } = useListVideos(undefined, {
    query: { queryKey: getListVideosQueryKey() }
  });

  const channelVideos = allVideos?.filter(v => v.channelName === channelName) || [];

  const totalViews = channelVideos.reduce((acc, v) => {
    const num = parseFloat(String(v.views).replace(/[^0-9.]/g, "")) || 0;
    const unit = String(v.views).toLowerCase();
    const mult = unit.includes("m") ? 1_000_000 : unit.includes("k") ? 1_000 : 1;
    return acc + num * mult;
  }, 0);

  const totalLikes = channelVideos.reduce((acc, v) => acc + (v.likes || 0), 0);

  const handleSubscribe = () => {
    setIsSubscribed(!isSubscribed);
    if (!isSubscribed) {
      setSubCount(s => s + 1);
      toast({ title: "Subscribed!", description: `You're now following ${channelName}.` });
    } else {
      setSubCount(s => s - 1);
    }
  };

  const handleNotify = () => {
    if (!isSubscribed) {
      toast({ title: "Subscribe first", description: "You need to subscribe to enable notifications.", variant: "destructive" });
      return;
    }
    setIsNotified(!isNotified);
    toast({ title: isNotified ? "Notifications off" : "Notifications on", description: isNotified ? "You won't get alerts for new uploads." : `You'll be notified when ${channelName} uploads.` });
  };

  const isVerified = channelVideos.some(v => v.isVerified);

  const bannerColors = channelVideos[0]
    ? `linear-gradient(135deg, ${channelVideos[0].thumbnailColor}, ${channelVideos[0].thumbnailColor2 || "#1a1a2e"})`
    : "linear-gradient(135deg, #1a1a2e, #2d1b69)";

  return (
    <div className="pb-12">
      {/* Banner */}
      <div
        className="w-full h-36 md:h-52 rounded-2xl mb-0 border border-white/10"
        style={{ backgroundImage: bannerColors }}
      />

      {/* Channel Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4 -mt-12 mb-8 px-2">
        <div className="w-24 h-24 rounded-full border-4 border-background bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-3xl font-display font-bold text-white shadow-xl">
          {channelName.charAt(0).toUpperCase()}
        </div>
        <div className="flex-1 sm:mb-2">
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-display font-bold text-foreground">{channelName}</h1>
            {isVerified && <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />}
          </div>
          <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5"><Users className="w-4 h-4" />{subCount.toLocaleString()} subscribers</div>
            <div className="flex items-center gap-1.5"><PlaySquare className="w-4 h-4" />{channelVideos.length} videos</div>
            <div className="flex items-center gap-1.5"><ThumbsUp className="w-4 h-4" />{totalLikes.toLocaleString()} total likes</div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={handleSubscribe}
            className={`rounded-full font-semibold px-6 ${isSubscribed ? "bg-white/10 text-foreground hover:bg-white/15" : "bg-primary text-primary-foreground hover:bg-primary/90"}`}
          >
            {isSubscribed ? "Subscribed" : "Subscribe"}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleNotify}
            className={`rounded-full ${isNotified ? "bg-primary/20 text-primary" : "bg-white/5 text-muted-foreground"}`}
          >
            <Bell className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
          <p className="text-2xl font-bold text-primary">{channelVideos.length}</p>
          <p className="text-xs text-muted-foreground mt-1">Videos</p>
        </div>
        <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
          <p className="text-2xl font-bold text-primary">{(totalViews / 1_000_000).toFixed(1)}M</p>
          <p className="text-xs text-muted-foreground mt-1">Total Views</p>
        </div>
        <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
          <p className="text-2xl font-bold text-primary">{(totalLikes / 1000).toFixed(0)}K</p>
          <p className="text-xs text-muted-foreground mt-1">Total Likes</p>
        </div>
      </div>

      {/* Videos */}
      <h2 className="text-xl font-bold text-foreground mb-5">Videos</h2>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="w-full aspect-video rounded-xl bg-white/5 mb-3" />
              <div className="h-4 bg-white/5 rounded w-3/4 mb-2" />
            </div>
          ))}
        </div>
      ) : channelVideos.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
          <PlaySquare className="w-12 h-12 mb-3 opacity-30" />
          <p>No videos found for this channel</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {channelVideos.map(video => (
            <VideoCard key={video.id} video={video} />
          ))}
        </div>
      )}
    </div>
  );
}
