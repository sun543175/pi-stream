import { useState, useEffect } from "react";
import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { Coins, TrendingUp, Zap, ArrowUpRight, Play, Pause, BarChart3, Wallet, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/context/WalletContext";
import { PiLogo } from "@/components/PiLogo";

const STAKING_POOLS = [
  { id: "stream", name: "Stream-Per-Second Pool", desc: "Earn 0.0001π per second of content you watch — funded by advertisers", apy: "Simulated", staked: "— π", myStake: 0, color: "text-blue-400" },
  { id: "boost", name: "Video Boost Pool", desc: "Stake π on videos to boost them in feeds. Earn a cut of ad revenue if video goes viral.", apy: "Simulated", staked: "— π", myStake: 0, color: "text-green-400" },
  { id: "revenue", name: "Creator Revenue Split", desc: "Investors co-fund creators and auto-receive 20% of their Pi revenue via smart contract", apy: "Simulated", staked: "— π", myStake: 0, color: "text-primary" },
];

interface StakedVideo { id: number; title: string; staked: number; earned: number; }

export default function Staking() {
  const { data: videos } = useListVideos(undefined, { query: { queryKey: getListVideosQueryKey() } });
  const { isConnected, piUsername } = useWallet();
  const { toast } = useToast();
  const [streaming, setStreaming] = useState(false);
  const [streamEarned, setStreamEarned] = useState(0);
  const [streamTime, setStreamTime] = useState(0);
  const [stakedVideos, setStakedVideos] = useState<StakedVideo[]>([]);
  const [stakeInput, setStakeInput] = useState<Record<string, string>>({});
  const [poolStakes, setPoolStakes] = useState<Record<string, number>>({});

  // Stream-per-second counter
  useEffect(() => {
    if (!streaming) return;
    const interval = setInterval(() => {
      setStreamEarned(e => Math.round((e + 0.0001) * 10000) / 10000);
      setStreamTime(t => t + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [streaming]);

  const handleStakeVideo = (videoId: number, title: string) => {
    const amount = parseFloat(stakeInput[videoId] || "1");
    if (!isConnected) { toast({ title: "Connect Pi Wallet to stake", variant: "destructive" }); return; }
    setStakedVideos(prev => {
      const existing = prev.find(v => v.id === videoId);
      if (existing) return prev.map(v => v.id === videoId ? { ...v, staked: v.staked + amount } : v);
      return [...prev, { id: videoId, title, staked: amount, earned: 0 }];
    });
    toast({ title: `Staked ${amount}π on "${title.slice(0, 30)}..."`, description: "You earn a cut if this video goes viral!" });
  };

  const handlePoolStake = (poolId: string, name: string) => {
    const amount = parseFloat(stakeInput[poolId] || "5");
    if (!isConnected) { toast({ title: "Connect Pi Wallet to stake", variant: "destructive" }); return; }
    setPoolStakes(p => ({ ...p, [poolId]: (p[poolId] || 0) + amount }));
    toast({ title: `Staked ${amount}π in ${name}!`, description: "Rewards accrue automatically in your Pi wallet." });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-4">
      <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 px-4 py-3 flex items-start gap-3">
        <Clock className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
        <div>
          <p className="text-sm font-semibold text-amber-400">Coming Soon — Testnet Demo Only</p>
          <p className="text-xs text-muted-foreground mt-0.5">Staking smart contracts are under development. Rewards shown are simulated and no real Pi is staked or transferred.</p>
        </div>
      </div>
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
          <Coins className="w-6 h-6 text-primary" /> Tokenized Monetization
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Stream-per-second payments, stake π on videos, and automatic revenue splits via smart contracts.</p>
      </div>

      {/* Stream-per-second */}
      <div className="rounded-2xl bg-gradient-to-br from-primary/15 via-card to-secondary/10 border border-primary/25 p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Zap className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Stream-Per-Second Payments</h3>
            <p className="text-xs text-muted-foreground">Earn 0.0001π for every second of video you watch. Funded by advertiser pool.</p>
          </div>
        </div>

        <div className="flex items-center gap-8 py-4 border-y border-white/8">
          <div>
            <p className="text-3xl font-bold text-primary font-mono">{streamEarned.toFixed(4)} π</p>
            <p className="text-xs text-muted-foreground">Earned this session</p>
          </div>
          <div>
            <p className="text-xl font-semibold text-foreground font-mono">{Math.floor(streamTime / 60)}:{(streamTime % 60).toString().padStart(2, "0")}</p>
            <p className="text-xs text-muted-foreground">Watch time</p>
          </div>
          <div>
            <p className="text-lg font-semibold text-foreground">0.0001 π/s</p>
            <p className="text-xs text-muted-foreground">Rate</p>
          </div>
        </div>

        <Button
          onClick={() => { if (!isConnected) { toast({ title: "Connect Pi Wallet", variant: "destructive" }); return; } setStreaming(s => !s); }}
          className={`rounded-full gap-2 ${streaming ? "bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30" : "bg-primary text-primary-foreground"}`}
        >
          {streaming ? <><Pause className="w-4 h-4" />Pause Earning</> : <><Play className="w-4 h-4" />Start Earning</>}
        </Button>
        {streaming && <p className="text-xs text-muted-foreground animate-pulse">● Earning π per second while you watch...</p>}
      </div>

      {/* Staking pools */}
      <div className="space-y-3">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><BarChart3 className="w-4 h-4 text-primary" />Staking Pools</h3>
        {STAKING_POOLS.map(pool => (
          <div key={pool.id} className="bg-card border border-white/8 rounded-2xl p-5 space-y-3 hover:border-white/15 transition-all">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <h4 className="font-semibold text-foreground text-sm">{pool.name}</h4>
                <p className="text-xs text-muted-foreground mt-0.5">{pool.desc}</p>
                <div className="flex items-center gap-4 mt-2 text-xs">
                  <span className={`font-bold ${pool.color}`}>Rewards: {pool.apy}</span>
                  <span className="text-muted-foreground">TVL: {pool.staked}</span>
                  {poolStakes[pool.id] ? <span className="text-primary">My stake: {poolStakes[pool.id]}π</span> : null}
                </div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <input
                type="number"
                min="1"
                value={stakeInput[pool.id] || "5"}
                onChange={e => setStakeInput(s => ({ ...s, [pool.id]: e.target.value }))}
                className="w-20 bg-white/5 border border-white/15 rounded-xl px-3 py-1.5 text-sm text-foreground text-center focus:outline-none focus:border-primary"
              />
              <span className="text-sm text-muted-foreground">π</span>
              <Button size="sm" onClick={() => handlePoolStake(pool.id, pool.name)} className="rounded-full bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 gap-1.5">
                <PiLogo className="w-3.5 h-3.5" />Stake
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Video boost staking */}
      <div className="space-y-3">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><TrendingUp className="w-4 h-4 text-primary" />Stake π on Videos — Earn if They Go Viral</h3>
        <p className="text-xs text-muted-foreground">Stake π on videos you believe in. If the video goes viral, you earn a cut of ad revenue proportional to your stake.</p>
        <div className="space-y-2">
          {(videos || []).slice(0, 5).map(video => {
            const staked = stakedVideos.find(s => s.id === video.id);
            return (
              <div key={video.id} className="flex items-center gap-3 py-2.5 border-b border-white/5 last:border-0">
                <div className="w-10 h-6 rounded shrink-0" style={{ background: `linear-gradient(135deg, ${video.thumbnailColor ?? "#1a1a2e"}, ${video.thumbnailColor2 ?? "#2d1b69"})` }} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground line-clamp-1">{video.title}</p>
                  {staked && <p className="text-[10px] text-primary">{staked.staked}π staked · earning...</p>}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <input
                    type="number"
                    min="0.1"
                    step="0.1"
                    value={stakeInput[video.id] || "1"}
                    onChange={e => setStakeInput(s => ({ ...s, [video.id]: e.target.value }))}
                    className="w-14 bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-xs text-foreground text-center focus:outline-none focus:border-primary"
                  />
                  <Button size="sm" onClick={() => handleStakeVideo(video.id, video.title || "")} className="rounded-full text-xs bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 h-7 px-2.5">
                    Stake
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Revenue splits info */}
      <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-3">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><ArrowUpRight className="w-4 h-4 text-primary" />Automatic Revenue Splits</h3>
        <p className="text-xs text-muted-foreground">Smart contracts automatically split Pi revenue with editors, musicians, and clip sources. No manual payments needed.</p>
        <div className="space-y-2">
          {[
            { role: "Creator", pct: "70%", color: "bg-primary", example: "Main video creator" },
            { role: "Editor", pct: "15%", color: "bg-blue-500", example: "Video editor wallet" },
            { role: "Musician", pct: "10%", color: "bg-green-500", example: "Background music license" },
            { role: "Platform", pct: "5%", color: "bg-yellow-500", example: "Pi Stream fee" },
          ].map(split => (
            <div key={split.role} className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${split.color} shrink-0`} />
              <span className="text-sm font-medium text-foreground w-20">{split.role}</span>
              <span className="text-sm font-bold text-primary">{split.pct}</span>
              <span className="text-xs text-muted-foreground">{split.example}</span>
            </div>
          ))}
        </div>
        <div className="h-3 rounded-full overflow-hidden flex">
          <div className="bg-primary" style={{ width: "70%" }} />
          <div className="bg-blue-500" style={{ width: "15%" }} />
          <div className="bg-green-500" style={{ width: "10%" }} />
          <div className="bg-yellow-500" style={{ width: "5%" }} />
        </div>
      </div>
    </div>
  );
}
