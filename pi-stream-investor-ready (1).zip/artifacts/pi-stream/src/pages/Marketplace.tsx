import { useState } from "react";
import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { ShoppingBag, Ticket, MapPin, Tag, Package, ExternalLink, Loader2, CheckCircle2, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/context/WalletContext";
import { PiLogo } from "@/components/PiLogo";

const SHOPPABLE = [
  { id: 1, videoTitle: "Pi Summit 2026 Keynote", product: "Pi Summit Hoodie", category: "Apparel", price: "45 π", nftRedeemable: true, stock: 12, img: "👕" },
  { id: 2, videoTitle: "Pi Network Deep Dive", product: "Pi Miner Cap", category: "Accessories", price: "15 π", nftRedeemable: true, stock: 50, img: "🧢" },
  { id: 3, videoTitle: "Blockchain Gaming with Pi", product: "Gamer Pi Mousepad", category: "Gaming", price: "8 π", nftRedeemable: false, stock: 200, img: "🖱️" },
  { id: 4, videoTitle: "Web3 Creator Masterclass", product: "Creator Toolkit Box", category: "Tools", price: "99 π", nftRedeemable: true, stock: 5, img: "📦" },
];

const TICKETS = [
  { event: "Pi Hackathon 2026", date: "Jun 15, 2026", venue: "Virtual + IRL", price: "10 π", soulbound: true, available: 240 },
  { event: "Pi Summit Singapore", date: "Jul 20, 2026", venue: "Marina Bay Sands", price: "50 π", soulbound: true, available: 80 },
  { event: "DeFi Meet Pi — NYC", date: "Aug 5, 2026", venue: "Manhattan, NY", price: "25 π", soulbound: true, available: 150 },
];

const LOCATION_DROPS = [
  { location: "Singapore Expo Centre", reward: "Founding Member NFT", hint: "Watch the Pi Summit live stream from the venue", claimed: false },
  { location: "Tokyo Web3 Conf", reward: "Samurai Pioneer Badge", hint: "Be within 500m of the conference hall", claimed: false },
  { location: "Lagos Pi Hub", reward: "African Pioneer NFT", hint: "Watch any video from Lagos, Nigeria", claimed: true },
];

export default function Marketplace() {
  const { isConnected } = useWallet();
  const { toast } = useToast();
  const [tab, setTab] = useState<"shop" | "tickets" | "drops">("shop");
  const [buying, setBuying] = useState<number | null>(null);
  const [bought, setBought] = useState<Set<number>>(new Set());

  const handleBuy = async (id: number, product: string, price: string) => {
    if (!isConnected) { toast({ title: "Connect Pi Wallet to buy", variant: "destructive" }); return; }
    setBuying(id);
    await new Promise(r => setTimeout(r, 1600));
    setBuying(null);
    setBought(s => new Set([...s, id]));
    toast({ title: "🎉 Purchase Complete!", description: `${product} (${price}) — NFT receipt sent to your Pi wallet.` });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-4">
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
          <ShoppingBag className="w-6 h-6 text-primary" /> Commerce & Real-World
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Click items in videos, get NFTs redeemable for physical goods. Soulbound event tickets. Location drops.</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-white/5 p-1 rounded-xl w-fit">
        {([
          { id: "shop", label: "Shoppable Videos", icon: Tag },
          { id: "tickets", label: "Event Tickets", icon: Ticket },
          { id: "drops", label: "Location Drops", icon: MapPin },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${tab === t.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            <t.icon className="w-3.5 h-3.5" />{t.label}
          </button>
        ))}
      </div>

      {tab === "shop" && (
        <div className="space-y-4">
          <p className="text-xs text-muted-foreground">Click items you see in videos to redeem as NFTs — each NFT is redeemable for the physical item via Pi Network verified merchants.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SHOPPABLE.map(item => {
              const isBought = bought.has(item.id);
              return (
                <div key={item.id} className={`bg-card border rounded-2xl p-5 space-y-3 transition-all ${isBought ? "border-primary/30" : "border-white/8 hover:border-white/15"}`}>
                  <div className="flex items-start gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-3xl shrink-0">{item.img}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-1.5 mb-1">
                        <Badge variant="outline" className="text-[10px] border-white/15 text-muted-foreground">{item.category}</Badge>
                        {item.nftRedeemable && <Badge className="text-[10px] bg-primary/10 text-primary border-primary/20">NFT Redeemable</Badge>}
                      </div>
                      <h3 className="font-semibold text-foreground text-sm">{item.product}</h3>
                      <p className="text-xs text-muted-foreground">From: {item.videoTitle}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-lg font-bold text-primary">{item.price}</p>
                      <p className="text-xs text-muted-foreground">{item.stock} left in stock</p>
                    </div>
                    {isBought ? (
                      <Badge className="bg-green-500/10 text-green-400 border-green-500/20"><CheckCircle2 className="w-3 h-3 mr-1" />Owned</Badge>
                    ) : (
                      <Button size="sm" onClick={() => handleBuy(item.id, item.product, item.price)} disabled={buying === item.id} className="rounded-full bg-primary text-primary-foreground gap-1.5">
                        {buying === item.id ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Buying...</> : <><PiLogo className="w-3.5 h-3.5" />Buy</>}
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === "tickets" && (
        <div className="space-y-4">
          <p className="text-xs text-muted-foreground">Livestream tickets are soulbound NFT passes — non-transferable, provably yours, verifiable at the venue door via QR code.</p>
          <div className="space-y-3">
            {TICKETS.map((t, i) => (
              <div key={i} className="bg-card border border-white/8 rounded-2xl p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-primary/15 flex items-center justify-center shrink-0">
                  <Ticket className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground text-sm">{t.event}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">{t.date} · {t.venue}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-[10px] border-primary/20 text-primary">Soulbound NFT</Badge>
                    <span className="text-xs text-muted-foreground">{t.available} available</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-lg font-bold text-primary">{t.price}</p>
                  <Button size="sm" className="rounded-full bg-primary text-primary-foreground mt-1 text-xs" onClick={() => toast({ title: `🎟 Ticket NFT Minted!`, description: `${t.event} soulbound pass sent to your Pi wallet.` })}>
                    Get Ticket
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "drops" && (
        <div className="space-y-4">
          <p className="text-xs text-muted-foreground">Watch Pi Stream at specific physical locations to unlock exclusive NFTs. Uses GPS + Pi Network verification.</p>
          <div className="space-y-3">
            {LOCATION_DROPS.map((drop, i) => (
              <div key={i} className={`bg-card border rounded-2xl p-5 space-y-3 ${drop.claimed ? "border-primary/30 bg-primary/5" : "border-white/8"}`}>
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${drop.claimed ? "bg-primary/20" : "bg-white/5"}`}>
                    <MapPin className={`w-5 h-5 ${drop.claimed ? "text-primary" : "text-muted-foreground"}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground text-sm">{drop.location}</h3>
                      {drop.claimed && <Badge className="bg-primary/10 text-primary border-primary/20 text-xs"><CheckCircle2 className="w-3 h-3 mr-1" />Claimed</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">Reward: <span className="text-primary font-medium">{drop.reward}</span></p>
                    <p className="text-xs text-muted-foreground mt-0.5 italic">{drop.hint}</p>
                  </div>
                </div>
                {!drop.claimed && (
                  <Button size="sm" variant="outline" className="rounded-full border-primary/20 text-primary hover:bg-primary/10 gap-1.5" onClick={() => toast({ title: "📍 Checking location...", description: "Enable GPS to verify your location." })}>
                    <Zap className="w-3.5 h-3.5" />Check In & Claim NFT
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
