import { useState } from "react";
import { Bell, Heart, MessageSquare, Radio, UserPlus, TrendingUp, Crown, Trash2, CheckCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

type NotifType = "like" | "comment" | "subscribe" | "live" | "milestone" | "upload" | "premium";

interface Notification {
  id: number;
  type: NotifType;
  title: string;
  body: string;
  time: string;
  read: boolean;
  link?: string;
  avatar?: string;
  avatarColor?: string;
}

const MOCK_NOTIFS: Notification[] = [
  { id: 1, type: "upload", title: "PiCrypto Labs uploaded", body: "Pi Network Deep Dive: How the Blockchain Actually Works", time: "2m ago", read: false, link: "/watch/1", avatarColor: "#7c3aed" },
  { id: 2, type: "live", title: "Decentralized Future is LIVE", body: "Pi Hackathon 2026 — Live Stream Now", time: "15m ago", read: false, link: "/live", avatarColor: "#dc2626" },
  { id: 3, type: "like", title: "Your video got 100 new likes", body: '"Introduction to Pi Mining" reached 1,000 likes!', time: "1h ago", read: false, link: "/analytics", avatarColor: "#f59e0b" },
  { id: 4, type: "milestone", title: "🎉 Milestone: 10K views!", body: "Your channel just hit 10,000 total views. Keep it up!", time: "3h ago", read: false, link: "/analytics", avatarColor: "#9b5cf6" },
  { id: 5, type: "comment", title: "New comment on your video", body: 'PioneerDev replied: "Amazing explanation of the consensus algorithm!"', time: "5h ago", read: true, link: "/watch/1", avatarColor: "#06b6d4" },
  { id: 6, type: "subscribe", title: "Pi_Enthusiast subscribed", body: "You have a new subscriber. Say hello!", time: "8h ago", read: true, avatarColor: "#10b981" },
  { id: 7, type: "upload", title: "Pi Network Academy uploaded", body: "Complete Guide to Pi Wallet Security", time: "12h ago", read: true, link: "/watch/3", avatarColor: "#f97316" },
  { id: 8, type: "premium", title: "Welcome to Pi Stream Premium!", body: "Your subscription is now active. Enjoy ad-free streaming.", time: "1d ago", read: true, link: "/subscribe", avatarColor: "#9b5cf6" },
  { id: 9, type: "milestone", title: "🎉 Milestone: 1K subscribers!", body: "Your channel just reached 1,000 subscribers!", time: "2d ago", read: true, link: "/analytics", avatarColor: "#9b5cf6" },
  { id: 10, type: "comment", title: "2 new comments", body: "On: \"Pi Network vs Bitcoin — The Real Comparison\"", time: "3d ago", read: true, link: "/watch/2", avatarColor: "#8b5cf6" },
];

const TYPE_CONFIG: Record<NotifType, { icon: React.ElementType; color: string; bg: string }> = {
  like: { icon: Heart, color: "text-red-400", bg: "bg-red-500/10" },
  comment: { icon: MessageSquare, color: "text-blue-400", bg: "bg-blue-500/10" },
  subscribe: { icon: UserPlus, color: "text-green-400", bg: "bg-green-500/10" },
  live: { icon: Radio, color: "text-red-400", bg: "bg-red-500/10" },
  milestone: { icon: TrendingUp, color: "text-yellow-400", bg: "bg-yellow-500/10" },
  upload: { icon: Bell, color: "text-primary", bg: "bg-primary/10" },
  premium: { icon: Crown, color: "text-primary", bg: "bg-primary/10" },
};

export default function Notifications() {
  const [notifs, setNotifs] = useState<Notification[]>(MOCK_NOTIFS);
  const [filter, setFilter] = useState<"all" | "unread">("all");

  const unreadCount = notifs.filter(n => !n.read).length;

  const markAllRead = () => setNotifs(n => n.map(x => ({ ...x, read: true })));
  const dismiss = (id: number) => setNotifs(n => n.filter(x => x.id !== id));
  const markRead = (id: number) => setNotifs(n => n.map(x => x.id === id ? { ...x, read: true } : x));

  const filtered = filter === "unread" ? notifs.filter(n => !n.read) : notifs;

  return (
    <div className="max-w-2xl mx-auto py-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-display font-bold text-foreground">Notifications</h1>
          {unreadCount > 0 && (
            <Badge className="bg-primary text-primary-foreground font-bold">{unreadCount}</Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllRead} className="text-xs text-primary hover:text-primary gap-1 rounded-full">
              <CheckCheck className="w-3.5 h-3.5" />
              Mark all read
            </Button>
          )}
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {(["all", "unread"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium capitalize transition-all ${filter === f ? "bg-primary text-primary-foreground" : "bg-white/5 text-muted-foreground hover:bg-white/10"}`}
          >
            {f} {f === "unread" && unreadCount > 0 && `(${unreadCount})`}
          </button>
        ))}
      </div>

      {/* Notification list */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground gap-3">
          <Bell className="w-12 h-12 opacity-20" />
          <p className="text-sm">{filter === "unread" ? "All caught up!" : "No notifications yet"}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(notif => {
            const cfg = TYPE_CONFIG[notif.type];
            const Icon = cfg.icon;
            return (
              <div
                key={notif.id}
                className={`relative group flex items-start gap-4 p-4 rounded-2xl border transition-all cursor-pointer ${!notif.read ? "bg-primary/5 border-primary/15 hover:bg-primary/8" : "bg-card border-white/8 hover:bg-white/5"}`}
                onClick={() => markRead(notif.id)}
              >
                {/* Icon */}
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${cfg.bg}`}>
                  <Icon className={`w-5 h-5 ${cfg.color}`} />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <p className={`text-sm font-semibold leading-snug ${!notif.read ? "text-foreground" : "text-foreground/80"}`}>{notif.title}</p>
                    <span className="text-xs text-muted-foreground whitespace-nowrap shrink-0">{notif.time}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{notif.body}</p>
                  {notif.link && (
                    <Link href={notif.link} onClick={e => e.stopPropagation()}>
                      <span className="text-xs text-primary hover:underline mt-1 inline-block">View →</span>
                    </Link>
                  )}
                </div>

                {/* Unread dot */}
                {!notif.read && (
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-primary" />
                )}

                {/* Dismiss button */}
                <button
                  onClick={e => { e.stopPropagation(); dismiss(notif.id); }}
                  className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded-full hover:bg-white/10"
                >
                  <Trash2 className="w-3 h-3 text-muted-foreground" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
