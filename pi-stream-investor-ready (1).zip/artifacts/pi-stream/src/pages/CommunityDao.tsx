import { useState } from "react";
import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { Users, Star, Shield, TrendingUp, Award, Plus, ChevronRight, ThumbsUp, ThumbsDown, Coins, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/context/WalletContext";
import { PiLogo } from "@/components/PiLogo";
import { VideoCard } from "@/components/video/VideoCard";

const DAOS = [
  { id: "science", name: "Science DAO", emoji: "🔬", members: 4240, treasury: "1,240 π", role: "Curates science & education videos", approved: 182, spam: 12, joined: true },
  { id: "gaming", name: "Gaming DAO", emoji: "🎮", members: 8900, treasury: "3,100 π", role: "Curates gaming and esports content", approved: 340, spam: 28, joined: false },
  { id: "crypto", name: "Crypto DAO", emoji: "₿", members: 6200, treasury: "2,800 π", role: "Curates Web3 and DeFi educational content", approved: 215, spam: 5, joined: true },
  { id: "music", name: "Music DAO", emoji: "🎵", members: 3100, treasury: "890 π", role: "Curates music videos and artist content", approved: 127, spam: 18, joined: false },
  { id: "news", name: "News DAO", emoji: "📰", members: 2800, treasury: "620 π", role: "Curates verified news and journalism", approved: 94, spam: 41, joined: false },
];

const FAN_CLUBS = [
  { creator: "PiCrypto Labs", fans: 1240, treasury: "420 π", season: "Season 2 Funded", progress: 84 },
  { creator: "Pi Academy", fans: 890, treasury: "180 π", season: "Season 1 Active", progress: 100 },
  { creator: "DecentralFuture", fans: 560, treasury: "95 π", season: "Raising for Season 3", progress: 47 },
];

export default function CommunityDao() {
  const { data: videos } = useListVideos(undefined, { query: { queryKey: getListVideosQueryKey() } });
  const { isConnected, piUsername } = useWallet();
  const { toast } = useToast();
  const [joined, setJoined] = useState<Set<string>>(new Set(["science", "crypto"]));
  const [tab, setTab] = useState<"daos" | "feed" | "fanclubs">("daos");
  const [voting, setVoting] = useState<number | null>(null);
  const [curatorVotes, setCuratorVotes] = useState<Record<number, "up" | "down">>({});

  const toggleJoin = async (id: string, name: string) => {
    if (!isConnected) { toast({ title: "Connect Pi Wallet to join DAOs", variant: "destructive" }); return; }
    const isJoined = joined.has(id);
    setJoined(prev => {
      const next = new Set(prev);
      if (isJoined) next.delete(id); else next.add(id);
      return next;
    });
    toast({ title: isJoined ? `Left ${name}` : `Joined ${name}! 🎉`, description: isJoined ? "" : "You can now curate content for this DAO and earn π." });
  };

  const handleVote = async (videoId: number, side: "up" | "down") => {
    if (!isConnected) { toast({ title: "Connect Pi Wallet to curate", variant: "destructive" }); return; }
    setVoting(videoId);
    await new Promise(r => setTimeout(r, 800));
    setVoting(null);
    setCuratorVotes(v => ({ ...v, [videoId]: side }));
    toast({
      title: side === "up" ? "✅ Approved — +0.001π earned!" : "❌ Marked as spam",
      description: side === "up" ? "Video added to DAO-curated feed." : "3 spam flags = removed from feed.",
    });
  };

  const curatedVideos = (videos || []).slice(0, 6);

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-4">
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
          <Users className="w-6 h-6 text-primary" /> Community DAOs
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Topic DAOs curate feeds — not algorithms. Earn π for early discovery. Fan clubs fund creator seasons.</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-white/5 p-1 rounded-xl w-fit">
        {([
          { id: "daos", label: "DAOs" },
          { id: "feed", label: "Curate Feed" },
          { id: "fanclubs", label: "Fan Clubs" },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${tab === t.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>{t.label}</button>
        ))}
      </div>

      {tab === "daos" && (
        <div className="space-y-3">
          {DAOS.map(dao => {
            const isJoined = joined.has(dao.id);
            return (
              <div key={dao.id} className={`bg-card border rounded-2xl p-5 flex items-start gap-4 transition-all ${isJoined ? "border-primary/25" : "border-white/8 hover:border-white/15"}`}>
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-2xl shrink-0">{dao.emoji}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-foreground">{dao.name}</h3>
                    {isJoined && <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">Member ✓</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">{dao.role}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Users className="w-3 h-3" />{dao.members.toLocaleString()} members</span>
                    <span className="flex items-center gap-1"><PiLogo className="w-3 h-3 text-primary" />{dao.treasury} treasury</span>
                    <span className="flex items-center gap-1 text-green-400"><ThumbsUp className="w-3 h-3" />{dao.approved}</span>
                    <span className="flex items-center gap-1 text-red-400"><Shield className="w-3 h-3" />{dao.spam} spam flagged</span>
                  </div>
                </div>
                <Button size="sm" onClick={() => toggleJoin(dao.id, dao.name)} className={`rounded-full shrink-0 ${isJoined ? "bg-white/5 text-muted-foreground hover:bg-white/10 border border-white/15" : "bg-primary text-primary-foreground"}`}>
                  {isJoined ? "Leave" : "Join"}
                </Button>
              </div>
            );
          })}
          <button className="w-full py-3 rounded-2xl border border-dashed border-white/15 text-sm text-muted-foreground hover:border-primary/30 hover:text-primary transition-all flex items-center justify-center gap-2" onClick={() => toast({ title: "Create a DAO", description: "Requires 500π stake to create a topic DAO." })}>
            <Plus className="w-4 h-4" />Create New Topic DAO (500π stake)
          </button>
        </div>
      )}

      {tab === "feed" && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-primary/5 border border-primary/15 text-xs text-muted-foreground space-y-1">
            <p className="text-primary font-semibold">How Curation Rewards Work</p>
            <p>Approve good videos → <span className="text-green-400 font-medium">earn 0.001π per approval</span></p>
            <p>Flag spam → verified spam removed, <span className="text-yellow-400 font-medium">earn 0.0005π per verified flag</span></p>
            <p>3 wrong approvals = penalty → <span className="text-red-400 font-medium">lose 0.01π</span></p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {curatedVideos.map(video => {
              const myVote = curatorVotes[video.id];
              return (
                <div key={video.id} className={`bg-card border rounded-2xl overflow-hidden transition-all ${myVote ? "border-primary/20" : "border-white/8"}`}>
                  <div className="h-28 flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${video.thumbnailColor ?? "#1a1a2e"}, ${video.thumbnailColor2 ?? "#2d1b69"})` }}>
                    <span className="text-4xl font-bold text-white/20">π</span>
                  </div>
                  <div className="p-3 space-y-2">
                    <p className="text-sm font-medium text-foreground line-clamp-1">{video.title}</p>
                    <p className="text-xs text-muted-foreground">{video.channelName}</p>
                    {myVote ? (
                      <Badge className={`${myVote === "up" ? "bg-green-500/10 text-green-400 border-green-500/20" : "bg-red-500/10 text-red-400 border-red-500/20"} text-xs`}>
                        {myVote === "up" ? "✅ Approved +0.001π" : "❌ Flagged as Spam"}
                      </Badge>
                    ) : (
                      <div className="flex gap-2">
                        <Button size="sm" onClick={() => handleVote(video.id, "up")} disabled={voting === video.id} className="flex-1 rounded-full bg-green-500/10 text-green-400 hover:bg-green-500/20 border border-green-500/20 text-xs gap-1">
                          {voting === video.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <ThumbsUp className="w-3 h-3" />}Approve
                        </Button>
                        <Button size="sm" onClick={() => handleVote(video.id, "down")} disabled={voting === video.id} className="flex-1 rounded-full bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 text-xs gap-1">
                          {voting === video.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <ThumbsDown className="w-3 h-3" />}Spam
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === "fanclubs" && (
        <div className="space-y-4">
          <p className="text-xs text-muted-foreground">Fan clubs pool π to fund creator seasons. Members vote on what gets made next.</p>
          {FAN_CLUBS.map((club, i) => (
            <div key={i} className="bg-card border border-white/8 rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">{club.creator} Fan Club</h3>
                  <p className="text-xs text-muted-foreground">{club.fans.toLocaleString()} members · {club.treasury} treasury</p>
                </div>
                <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">{club.season}</Badge>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Season funding progress</span>
                  <span className="font-medium">{club.progress}%</span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div className={`h-full rounded-full ${club.progress >= 100 ? "bg-green-500" : "bg-primary"}`} style={{ width: `${Math.min(100, club.progress)}%` }} />
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" className="flex-1 rounded-full bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 gap-1.5" onClick={() => toast({ title: `Contributed to ${club.creator} Fan Club!`, description: "1π added to treasury." })}>
                  <Coins className="w-3.5 h-3.5" />Fund (1π)
                </Button>
                <Button size="sm" variant="outline" className="rounded-full border-white/10 gap-1.5 text-xs" onClick={() => toast({ title: "Fan Club Voting", description: "Vote on what the creator makes next." })}>
                  <Star className="w-3.5 h-3.5" />Vote on Content
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
