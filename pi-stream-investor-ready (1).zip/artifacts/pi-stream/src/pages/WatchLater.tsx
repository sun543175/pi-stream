import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { VideoCard } from "@/components/video/VideoCard";
import { Clock, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function WatchLater() {
  const { toast } = useToast();
  const [savedIds, setSavedIds] = useState<number[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem("pi-tube-watch-later");
    if (stored) {
      try { setSavedIds(JSON.parse(stored)); } catch { setSavedIds([]); }
    }
  }, []);

  const { data: allVideos, isLoading } = useListVideos(undefined, {
    query: { queryKey: getListVideosQueryKey() }
  });

  const savedVideos = allVideos?.filter(v => savedIds.includes(v.id)) || [];

  const removeVideo = (id: number) => {
    const updated = savedIds.filter(sid => sid !== id);
    setSavedIds(updated);
    localStorage.setItem("pi-tube-watch-later", JSON.stringify(updated));
    toast({ title: "Removed", description: "Video removed from Watch Later." });
  };

  const clearAll = () => {
    setSavedIds([]);
    localStorage.removeItem("pi-tube-watch-later");
    toast({ title: "Cleared", description: "Watch Later list cleared." });
  };

  return (
    <div className="pb-12">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
            <Clock className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold text-foreground">Watch Later</h1>
            <p className="text-sm text-muted-foreground">{savedVideos.length} video{savedVideos.length !== 1 ? "s" : ""} saved</p>
          </div>
        </div>
        {savedVideos.length > 0 && (
          <Button variant="ghost" size="sm" onClick={clearAll} className="text-muted-foreground hover:text-destructive">
            <Trash2 className="w-4 h-4 mr-2" />
            Clear all
          </Button>
        )}
      </div>

      {isLoading && (
        <div className="flex flex-col gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="animate-pulse flex gap-4">
              <div className="w-64 aspect-video rounded-lg bg-white/5 shrink-0" />
              <div className="flex-1 pt-2">
                <div className="h-5 bg-white/5 rounded w-3/4 mb-2" />
                <div className="h-4 bg-white/5 rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      )}

      {!isLoading && savedVideos.length === 0 && (
        <div className="flex flex-col items-center justify-center h-64 text-center">
          <Clock className="w-16 h-16 text-white/10 mb-4" />
          <p className="text-xl font-semibold text-muted-foreground mb-2">Nothing saved yet</p>
          <p className="text-muted-foreground text-sm">Click "Watch Later" on any video to save it here</p>
        </div>
      )}

      {!isLoading && savedVideos.length > 0 && (
        <div className="flex flex-col gap-4">
          {savedVideos.map(video => (
            <div key={video.id} className="group relative">
              <VideoCard video={video} layout="list" />
              <button
                onClick={() => removeVideo(video.id)}
                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-full bg-black/60 text-white/60 hover:text-white hover:bg-black/80"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function X({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
  );
}
