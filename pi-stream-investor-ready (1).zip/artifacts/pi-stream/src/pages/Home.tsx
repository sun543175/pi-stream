import { useListVideos, useListTrendingVideos, useGetFeaturedVideo, useListLiveStreams, useGetPlatformStats, useListCategories, getListCategoriesQueryKey, getGetPlatformStatsQueryKey, getGetFeaturedVideoQueryKey, getListTrendingVideosQueryKey, getListLiveStreamsQueryKey, getListVideosQueryKey } from "@workspace/api-client-react";
import { VideoGrid } from "@/components/video/VideoGrid";
import { VideoCard } from "@/components/video/VideoCard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { useState } from "react";
import { Link } from "wouter";
import { PlaySquare, Users, Radio, Coins, Flame } from "lucide-react";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: stats } = useGetPlatformStats({ query: { queryKey: getGetPlatformStatsQueryKey() } });
  const { data: categories } = useListCategories({ query: { queryKey: getListCategoriesQueryKey() } });
  const { data: featured } = useGetFeaturedVideo({ query: { queryKey: getGetFeaturedVideoQueryKey() } });
  const { data: trending } = useListTrendingVideos({ query: { queryKey: getListTrendingVideosQueryKey() } });
  const { data: live } = useListLiveStreams({ query: { queryKey: getListLiveStreamsQueryKey() } });
  
  const { data: videos, isLoading: videosLoading } = useListVideos(
    selectedCategory ? { category: selectedCategory } : undefined,
    { query: { queryKey: getListVideosQueryKey(selectedCategory ? { category: selectedCategory } : undefined) } }
  );

  return (
    <div className="flex flex-col gap-8 pb-12">
      {/* Category Chips */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur py-2 -mx-4 px-4 sm:mx-0 sm:px-0">
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex w-max space-x-2">
            <Button
              variant={selectedCategory === null ? "default" : "secondary"}
              className={`rounded-full ${selectedCategory === null ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-white/5 hover:bg-white/10 text-foreground'}`}
              onClick={() => setSelectedCategory(null)}
              size="sm"
            >
              All
            </Button>
            {categories?.map(cat => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.slug ? "default" : "secondary"}
                className={`rounded-full ${selectedCategory === cat.slug ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-white/5 hover:bg-white/10 text-foreground'}`}
                onClick={() => setSelectedCategory(cat.slug)}
                size="sm"
              >
                {cat.emoji} {cat.name}
              </Button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" className="invisible" />
        </ScrollArea>
      </div>

      {/* Hero Featured */}
      {!selectedCategory && featured && (
        <Link href={`/watch/${featured.id}`} className="block group">
          <div className="relative w-full aspect-[21/9] md:aspect-[3/1] rounded-2xl overflow-hidden border border-white/10 group-hover:border-primary/50 transition-colors cursor-pointer bg-gradient-to-br from-indigo-950 to-slate-900">
            <div 
              className="absolute inset-0 opacity-40 mix-blend-overlay transition-transform duration-700 group-hover:scale-105"
              style={{ backgroundImage: `linear-gradient(135deg, ${featured.thumbnailColor}, ${featured.thumbnailColor2 || 'transparent'})` }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
            <div className="absolute inset-0 flex items-center justify-center opacity-20 text-9xl group-hover:scale-110 transition-transform duration-700">
              {featured.thumbnailEmoji}
            </div>
            
            <div className="absolute bottom-0 left-0 p-6 md:p-10 max-w-3xl">
              <Badge variant="secondary" className="bg-primary text-primary-foreground mb-4">Featured Premiere</Badge>
              <h1 className="text-3xl md:text-5xl font-display font-bold text-white mb-4 leading-tight group-hover:text-primary transition-colors">
                {featured.title}
              </h1>
              <p className="text-white/70 text-lg line-clamp-2 mb-6 hidden md:block">
                {featured.description}
              </p>
              <div className="flex items-center gap-4 text-white/80">
                <span className="font-medium text-white">{featured.channelName}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-white/30" />
                <span>{featured.views} views</span>
                <span className="w-1.5 h-1.5 rounded-full bg-white/30" />
                <span>{featured.duration}</span>
              </div>
            </div>
          </div>
        </Link>
      )}

      {/* Stats Row */}
      {!selectedCategory && stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/20 text-primary flex items-center justify-center"><PlaySquare className="w-5 h-5" /></div>
            <div>
              <p className="text-xs text-muted-foreground">Total Videos</p>
              <p className="text-xl font-bold">{stats.totalVideos.toLocaleString()}</p>
            </div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-secondary/20 text-secondary flex items-center justify-center"><Users className="w-5 h-5" /></div>
            <div>
              <p className="text-xs text-muted-foreground">Subscribers</p>
              <p className="text-xl font-bold">{stats.totalSubscribers.toLocaleString()}</p>
            </div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-destructive/20 text-destructive flex items-center justify-center"><Radio className="w-5 h-5" /></div>
            <div>
              <p className="text-xs text-muted-foreground">Live Now</p>
              <p className="text-xl font-bold">{stats.liveCount.toLocaleString()}</p>
            </div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/20 text-primary flex items-center justify-center"><Coins className="w-5 h-5" /></div>
            <div>
              <p className="text-xs text-muted-foreground">Pi Transacted</p>
              <p className="text-xl font-bold">{stats.piCollected.toLocaleString()} π</p>
            </div>
          </div>
        </div>
      )}

      {/* Content Sections */}
      {!selectedCategory && trending && trending.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                <Flame className="w-5 h-5" />
              </div>
              <h2 className="text-2xl font-bold text-foreground">Trending on Pi Network</h2>
            </div>
            <Link href="/trending">
              <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80 hover:bg-primary/10 rounded-full">
                See all →
              </Button>
            </Link>
          </div>
          <VideoGrid videos={trending.slice(0, 4)} />
        </section>
      )}

      {!selectedCategory && live && live.length > 0 && (
        <section>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 rounded-full bg-destructive/20 flex items-center justify-center text-destructive animate-pulse">
              <Radio className="w-5 h-5" />
            </div>
            <h2 className="text-2xl font-bold text-foreground">Live Broadcasts</h2>
          </div>
          <VideoGrid videos={live.slice(0, 4)} />
        </section>
      )}

      <section>
        <h2 className="text-2xl font-bold text-foreground mb-6">
          {selectedCategory ? 'Filtered Results' : 'Recommended For You'}
        </h2>
        {videosLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="w-full aspect-video rounded-xl bg-white/5 mb-3" />
                <div className="h-4 bg-white/5 rounded w-3/4 mb-2" />
                <div className="h-3 bg-white/5 rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : (
          <VideoGrid videos={videos || []} />
        )}
      </section>
    </div>
  );
}
