import { useState } from "react";
import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { Link2, ArrowRightLeft, MessageSquare, Coins, Globe, CheckCircle2, Copy, ExternalLink, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { PiLogo } from "@/components/PiLogo";

const CHAINS = [
  { name: "Pi Network (Testnet)", icon: "π", color: "#9b5cf6", connected: false, tvl: "—" },
  { name: "Lens Protocol", icon: "🌿", color: "#00D26A", connected: false, tvl: "—" },
  { name: "Farcaster", icon: "🟣", color: "#8B5CF6", connected: false, tvl: "—" },
  { name: "Solana", icon: "◎", color: "#14F195", connected: false, tvl: "—" },
  { name: "Ethereum", icon: "⟠", color: "#627EEA", connected: false, tvl: "—" },
  { name: "BNB Chain", icon: "⬡", color: "#F3BA2F", connected: false, tvl: "—" },
];

const TIP_TOKENS = [
  { symbol: "π", name: "Pi", rate: 1, icon: "π" },
  { symbol: "SOL", name: "Solana", rate: 0.003, icon: "◎" },
  { symbol: "ETH", name: "Ethereum", rate: 0.000003, icon: "⟠" },
  { symbol: "BNB", name: "BNB", rate: 0.03, icon: "⬡" },
];

export default function CrossChain() {
  const { data: videos } = useListVideos(undefined, { query: { queryKey: getListVideosQueryKey() } });
  const { toast } = useToast();
  const [connecting, setConnecting] = useState<string | null>(null);
  const [tipToken, setTipToken] = useState("π");
  const [tipAmount, setTipAmount] = useState("1");
  const [sharing, setSharing] = useState<number | null>(null);
  const [sharedIds, setSharedIds] = useState<Set<number>>(new Set());

  const connectChain = async (name: string) => {
    setConnecting(name);
    await new Promise(r => setTimeout(r, 1800));
    setConnecting(null);
    toast({ title: `✅ Connected to ${name}!`, description: "Your Pi Stream videos are now discoverable on this chain." });
  };

  const shareVideo = async (id: number, title: string) => {
    setSharing(id);
    await new Promise(r => setTimeout(r, 1200));
    setSharing(null);
    setSharedIds(s => new Set([...s, id]));
    toast({ title: "📡 Published to Lens, Farcaster & Pi!", description: `"${title.slice(0, 40)}..." is now playable across all connected chains.` });
  };

  const selectedToken = TIP_TOKENS.find(t => t.symbol === tipToken)!;
  const piEquivalent = parseFloat(tipAmount) / selectedToken.rate;

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-4">
      <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 px-4 py-3 flex items-start gap-3">
        <Loader2 className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
        <div>
          <p className="text-sm font-semibold text-amber-400">Coming Soon — Testnet Demo Only</p>
          <p className="text-xs text-muted-foreground mt-0.5">Cross-chain bridges and multi-token tipping are under development. No real transactions are processed.</p>
        </div>
      </div>
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
          <ArrowRightLeft className="w-6 h-6 text-primary" /> Cross-Chain & Interoperability
        </h1>
        <p className="text-muted-foreground text-sm mt-1">One video, playable on Lens, Farcaster, Pi & Solana. Tips in any token, auto-converted.</p>
      </div>

      {/* Connected chains */}
      <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><Globe className="w-4 h-4 text-primary" />Connected Chains</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {CHAINS.map(chain => (
            <div key={chain.name} className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${chain.connected ? "border-primary/20 bg-primary/5" : "border-white/8 bg-white/3"}`}>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg shrink-0" style={{ background: chain.color + "20", border: `1px solid ${chain.color}40` }}>
                {chain.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{chain.name}</p>
                {chain.connected ? (
                  <p className="text-xs text-green-400">Connected ✓</p>
                ) : (
                  <Button size="sm" variant="ghost" onClick={() => connectChain(chain.name)} disabled={connecting === chain.name} className="text-xs p-0 h-auto text-primary hover:text-primary/80">
                    {connecting === chain.name ? <><Loader2 className="w-3 h-3 animate-spin mr-1" />Connecting</> : "Connect →"}
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Cross-chain video publish */}
      <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><Link2 className="w-4 h-4 text-primary" />Publish Across All Chains</h3>
        <p className="text-xs text-muted-foreground">One video, playable on Lens, Farcaster, Pi, and Solana simultaneously. Comments become cross-platform threads.</p>
        <div className="space-y-2">
          {(videos || []).slice(0, 5).map(video => {
            const isShared = sharedIds.has(video.id);
            return (
              <div key={video.id} className="flex items-center gap-3 py-2.5 border-b border-white/5 last:border-0">
                <div className="w-10 h-6 rounded shrink-0" style={{ background: `linear-gradient(135deg, ${video.thumbnailColor ?? "#1a1a2e"}, ${video.thumbnailColor2 ?? "#2d1b69"})` }} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground line-clamp-1">{video.title}</p>
                  {isShared && <p className="text-[10px] text-primary">Published on Lens · Farcaster · Pi</p>}
                </div>
                {isShared ? (
                  <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs shrink-0"><CheckCircle2 className="w-2.5 h-2.5 mr-1" />Live</Badge>
                ) : (
                  <Button size="sm" onClick={() => shareVideo(video.id, video.title || "")} disabled={sharing === video.id} className="rounded-full bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 text-xs shrink-0">
                    {sharing === video.id ? <Loader2 className="w-3 h-3 animate-spin" /> : "Publish"}
                  </Button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Cross-chain tips */}
      <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-4">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><Coins className="w-4 h-4 text-primary" />Tip in Any Token — Auto-Converted to π</h3>
        <p className="text-xs text-muted-foreground">Send tips in SOL, ETH, BNB, or any token. Our bridge auto-converts to π and sends to creator's Pi wallet instantly.</p>
        <div className="flex gap-3 flex-wrap items-end">
          <div className="space-y-1.5">
            <label className="text-xs text-muted-foreground font-medium">Token</label>
            <div className="flex gap-2">
              {TIP_TOKENS.map(t => (
                <button key={t.symbol} onClick={() => setTipToken(t.symbol)} className={`px-3 py-1.5 rounded-xl border text-sm font-medium transition-all ${tipToken === t.symbol ? "border-primary bg-primary/15 text-primary" : "border-white/10 text-muted-foreground hover:border-white/25"}`}>
                  {t.icon} {t.symbol}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs text-muted-foreground font-medium">Amount</label>
            <input type="number" min="0.001" step="0.001" value={tipAmount} onChange={e => setTipAmount(e.target.value)} className="w-24 bg-white/5 border border-white/15 rounded-xl px-3 py-1.5 text-sm text-foreground text-center focus:outline-none focus:border-primary" />
          </div>
          <Button className="rounded-xl bg-primary text-primary-foreground" onClick={() => toast({ title: `Tip sent! 🎉`, description: `${tipAmount} ${tipToken} → ${piEquivalent.toFixed(2)} π sent to creator.` })}>
            Send Tip
          </Button>
        </div>
        {tipAmount && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>{tipAmount} {tipToken}</span>
            <ArrowRightLeft className="w-4 h-4 text-primary" />
            <span className="text-primary font-semibold">{piEquivalent.toFixed(4)} π</span>
            <span className="text-xs">via Pi Stream Bridge</span>
          </div>
        )}
      </div>

      {/* Cross-platform comments */}
      <div className="bg-card border border-white/8 rounded-2xl p-5 space-y-3">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><MessageSquare className="w-4 h-4 text-primary" />Cross-Platform Comment Threads</h3>
        <p className="text-xs text-muted-foreground">Comments posted here are mirrored as threads on Lens and Farcaster simultaneously.</p>
        {[
          { platform: "Lens", user: "vitalik.lens", comment: "Great deep dive on Pi consensus!", time: "2m ago" },
          { platform: "Farcaster", user: "@pioneer.eth", comment: "The blockchain architecture explained perfectly", time: "5m ago" },
          { platform: "Pi Stream", user: "@PiMiner2026", comment: "Finally a clear explanation!", time: "8m ago" },
        ].map((c, i) => (
          <div key={i} className="flex items-start gap-3 py-2 border-b border-white/5 last:border-0">
            <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">{c.user.charAt(0).toUpperCase()}</div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-foreground">{c.user}</span>
                <Badge variant="outline" className="text-[10px] border-white/15 text-muted-foreground px-1.5 py-0">{c.platform}</Badge>
                <span className="text-[10px] text-muted-foreground">{c.time}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">{c.comment}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
