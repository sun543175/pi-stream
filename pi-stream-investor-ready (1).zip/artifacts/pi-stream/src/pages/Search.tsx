import { useSearchVideos, getSearchVideosQueryKey } from "@workspace/api-client-react";
import { useSearch } from "wouter";
import { VideoGrid } from "@/components/video/VideoGrid";
import { Filter, X, Clock, Tv, Zap, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import type { Video } from "@workspace/api-client-react";

type DurationFilter = "any" | "short" | "medium" | "long";
type DateFilter = "any" | "today" | "week" | "month" | "year";
type TypeFilter = "any" | "hd" | "live";

export default function Search() {
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const q = searchParams.get("q") || "";

  const [showFilters, setShowFilters] = useState(false);
  const [duration, setDuration] = useState<DurationFilter>("any");
  const [date, setDate] = useState<DateFilter>("any");
  const [type, setType] = useState<TypeFilter>("any");

  const { data: videos, isLoading } = useSearchVideos(
    { q },
    { query: { enabled: !!q, queryKey: getSearchVideosQueryKey({ q }) } }
  );

  const parseDurationSecs = (d: string) => {
    const parts = d?.split(":").map(Number) || [];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    return 0;
  };

  const filtered = (videos || []).filter((v: Video) => {
    if (duration !== "any") {
      const secs = parseDurationSecs(v.duration || "");
      if (duration === "short" && secs > 240) return false;
      if (duration === "medium" && (secs <= 240 || secs > 1200)) return false;
      if (duration === "long" && secs <= 1200) return false;
    }
    if (type === "hd" && !v.isHD) return false;
    if (type === "live" && !v.isLive) return false;
    return true;
  });

  const activeFilters = [
    duration !== "any" && duration,
    date !== "any" && date,
    type !== "any" && type,
  ].filter(Boolean);

  const clearFilters = () => { setDuration("any"); setDate("any"); setType("any"); };

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between border-b border-white/5 pb-4">
        <div>
          <h1 className="text-xl font-bold text-foreground">"{q}"</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{filtered.length} result{filtered.length !== 1 ? "s" : ""}</p>
        </div>
        <div className="flex items-center gap-2">
          {activeFilters.length > 0 && (
            <button onClick={clearFilters} className="text-xs text-primary hover:underline flex items-center gap-1">
              <X className="w-3 h-3" />Clear
            </button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(f => !f)}
            className={`rounded-full gap-2 border-white/10 hover:bg-white/5 text-sm ${showFilters ? "bg-primary/10 border-primary/30 text-primary" : "bg-transparent"}`}
          >
            <Filter className="w-3.5 h-3.5" />
            Filters
            {activeFilters.length > 0 && (
              <Badge className="bg-primary text-primary-foreground text-xs px-1.5 py-0 h-4">{activeFilters.length}</Badge>
            )}
          </Button>
        </div>
      </div>

      {/* Filter panel */}
      {showFilters && (
        <div className="rounded-2xl border border-white/8 bg-card p-5 space-y-4">
          {/* Duration */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Duration</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {([
                { v: "any", label: "Any" },
                { v: "short", label: "Under 4 min" },
                { v: "medium", label: "4–20 min" },
                { v: "long", label: "Over 20 min" },
              ] as const).map(opt => (
                <button
                  key={opt.v}
                  onClick={() => setDuration(opt.v)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${duration === opt.v ? "bg-primary text-primary-foreground border-primary" : "border-white/10 text-muted-foreground hover:border-white/25"}`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Upload date */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Upload Date</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {([
                { v: "any", label: "Any time" },
                { v: "today", label: "Today" },
                { v: "week", label: "This week" },
                { v: "month", label: "This month" },
                { v: "year", label: "This year" },
              ] as const).map(opt => (
                <button
                  key={opt.v}
                  onClick={() => setDate(opt.v)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${date === opt.v ? "bg-primary text-primary-foreground border-primary" : "border-white/10 text-muted-foreground hover:border-white/25"}`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Type */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Tv className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Type</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {([
                { v: "any", label: "All" },
                { v: "hd", label: "HD", icon: Zap },
                { v: "live", label: "Live" },
              ] as const).map(opt => (
                <button
                  key={opt.v}
                  onClick={() => setType(opt.v)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all flex items-center gap-1.5 ${type === opt.v ? "bg-primary text-primary-foreground border-primary" : "border-white/10 text-muted-foreground hover:border-white/25"}`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="h-64 flex items-center justify-center text-muted-foreground">Searching...</div>
      ) : filtered.length === 0 && q ? (
        <div className="flex flex-col items-center justify-center h-64 gap-3 text-muted-foreground">
          <p className="text-lg font-medium">No results found</p>
          <p className="text-sm">{activeFilters.length > 0 ? "Try removing some filters" : `No videos match "${q}"`}</p>
          {activeFilters.length > 0 && <Button variant="outline" size="sm" onClick={clearFilters} className="rounded-full border-white/10">Clear filters</Button>}
        </div>
      ) : (
        <VideoGrid videos={filtered} />
      )}
    </div>
  );
}
