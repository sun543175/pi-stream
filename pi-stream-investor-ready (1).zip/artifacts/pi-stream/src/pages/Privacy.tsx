import { useState } from "react";
import { Shield, Lock, Eye, EyeOff, FileKey, Download, ArrowRightLeft, CheckCircle2, Loader2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/context/WalletContext";

export default function Privacy() {
  const { isConnected, walletAddress } = useWallet();
  const { toast } = useToast();
  const [encryptHistory, setEncryptHistory] = useState(true);
  const [zkAge, setZkAge] = useState(false);
  const [portalLoading, setPortalLoading] = useState(false);
  const [exportLoading, setExportLoading] = useState(false);
  const [ageVerified, setAgeVerified] = useState(false);
  const [verifyingAge, setVerifyingAge] = useState(false);

  const exportAsNFT = async () => {
    setExportLoading(true);
    await new Promise(r => setTimeout(r, 2000));
    setExportLoading(false);
    const data = {
      walletAddress,
      exportedAt: new Date().toISOString(),
      subscriptions: ["Pi Stream Monthly"],
      watchHistory: "encrypted",
      watchLater: JSON.parse(localStorage.getItem("pi-tube-watch-later") || "[]"),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "pi-tube-portable-identity.json";
    a.click();
    toast({ title: "📦 Portable Identity Exported!", description: "Import this NFT file into any compatible Web3 video platform in 1 click." });
  };

  const verifyAge = async () => {
    if (!isConnected) { toast({ title: "Connect Pi Wallet for ZK age check", variant: "destructive" }); return; }
    setVerifyingAge(true);
    await new Promise(r => setTimeout(r, 2500));
    setVerifyingAge(false);
    setAgeVerified(true);
    toast({ title: "✅ Age Verified (ZK Proof)", description: "Verified 18+ without revealing your birthday. Proof stored in Pi wallet." });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 py-4">
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
          <Shield className="w-6 h-6 text-primary" /> Privacy & Data Control
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Your data lives in your wallet. Zero-knowledge proofs. Export and take it anywhere.</p>
      </div>

      {/* Wallet-encrypted history */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <Lock className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">Watch History — Wallet-Encrypted</h2>
        </div>
        <div className="p-5 space-y-4">
          <p className="text-xs text-muted-foreground leading-relaxed">Your watch history is encrypted with your Pi wallet's private key. Pi Stream servers never see what you watch — only you can decrypt it.</p>
          <div className="flex items-center justify-between py-3 border-b border-white/5">
            <div>
              <Label className="text-sm font-medium text-foreground">Encrypt watch history</Label>
              <p className="text-xs text-muted-foreground mt-0.5">Store history in your wallet, not our servers</p>
            </div>
            <Switch checked={encryptHistory} onCheckedChange={v => { setEncryptHistory(v); toast({ title: v ? "History encryption ON" : "History encryption OFF" }); }} />
          </div>
          {encryptHistory && isConnected && (
            <div className="p-3 rounded-xl bg-green-500/5 border border-green-500/20 flex items-center gap-2.5 text-xs">
              <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
              <span className="text-green-400">Watch history is encrypted in your Pi wallet. No server can read it.</span>
            </div>
          )}
          {encryptHistory && !isConnected && (
            <div className="p-3 rounded-xl bg-yellow-500/5 border border-yellow-500/20 flex items-center gap-2.5 text-xs">
              <AlertTriangle className="w-4 h-4 text-yellow-400 shrink-0" />
              <span className="text-yellow-400">Connect Pi Wallet to encrypt your watch history.</span>
            </div>
          )}
        </div>
      </section>

      {/* ZK Age Check */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <FileKey className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">Zero-Knowledge Age Verification</h2>
          <Badge className="ml-auto bg-primary/10 text-primary border-primary/20 text-xs">ZK Proof</Badge>
        </div>
        <div className="p-5 space-y-4">
          <p className="text-xs text-muted-foreground leading-relaxed">Prove you are 18+ without revealing your birthday, name, or any personal data. Uses zero-knowledge cryptography — the verifier learns only "yes, they're 18+" and nothing else.</p>

          <div className="p-4 rounded-xl bg-white/3 border border-white/8 space-y-3">
            <div className="flex items-start gap-3">
              <div className="text-2xl">🔐</div>
              <div>
                <p className="text-sm font-medium text-foreground">How it works</p>
                <ol className="text-xs text-muted-foreground mt-1 space-y-0.5 list-decimal list-inside">
                  <li>Pi Network confirms your age in your wallet (never shared)</li>
                  <li>A ZK proof is generated: "age ≥ 18"</li>
                  <li>Pi Stream verifies the proof — no birthday revealed</li>
                </ol>
              </div>
            </div>
          </div>

          {ageVerified ? (
            <div className="p-3 rounded-xl bg-green-500/5 border border-green-500/20 flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-green-400">Age Verified ✓</p>
                <p className="text-xs text-muted-foreground">ZK proof stored in your Pi wallet. Birthday never revealed.</p>
              </div>
            </div>
          ) : (
            <Button onClick={verifyAge} disabled={verifyingAge} className="rounded-full bg-primary text-primary-foreground gap-2">
              {verifyingAge ? <><Loader2 className="w-4 h-4 animate-spin" />Generating ZK Proof...</> : <><FileKey className="w-4 h-4" />Verify Age (ZK — No Birthday Shared)</>}
            </Button>
          )}
        </div>
      </section>

      {/* Portable subscription NFT */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <ArrowRightLeft className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">Portable Identity — Export to Any Platform</h2>
        </div>
        <div className="p-5 space-y-4">
          <p className="text-xs text-muted-foreground leading-relaxed">Export your subscriptions, watch history, and creator follows as an NFT file. Import it to any compatible Web3 video platform in 1 click — no lock-in.</p>

          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Subscriptions", value: "1 plan", icon: "📋" },
              { label: "Watch History", value: "Encrypted", icon: "🔒" },
              { label: "Creator Follows", value: "12", icon: "👥" },
              { label: "Liked Videos", value: `${JSON.parse(localStorage.getItem("pi-tube-liked") || "[]").length}`, icon: "❤️" },
            ].map(item => (
              <div key={item.label} className="flex items-center gap-3 p-3 rounded-xl bg-white/3 border border-white/8">
                <span className="text-lg">{item.icon}</span>
                <div>
                  <p className="text-xs text-muted-foreground">{item.label}</p>
                  <p className="text-sm font-semibold text-foreground">{item.value}</p>
                </div>
              </div>
            ))}
          </div>

          <Button onClick={exportAsNFT} disabled={exportLoading} className="w-full rounded-full bg-primary text-primary-foreground gap-2">
            {exportLoading ? <><Loader2 className="w-4 h-4 animate-spin" />Packaging NFT...</> : <><Download className="w-4 h-4" />Export as Portable NFT (1-click import elsewhere)</>}
          </Button>
        </div>
      </section>

      {/* Data rights */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <Eye className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">What Pi Stream Can See</h2>
        </div>
        <div className="divide-y divide-white/5">
          {[
            { label: "Video views", visible: true, reason: "Required for creator payments" },
            { label: "Watch history", visible: false, reason: "Encrypted in your wallet" },
            { label: "Pi wallet address", visible: true, reason: "Required for payments" },
            { label: "Real name / birthday", visible: false, reason: "Never collected" },
            { label: "IP address", visible: false, reason: "Anonymized via Pi Network" },
            { label: "Comments", visible: true, reason: "Public by design" },
          ].map(item => (
            <div key={item.label} className="px-5 py-3 flex items-center gap-3">
              {item.visible ? <Eye className="w-4 h-4 text-yellow-400 shrink-0" /> : <EyeOff className="w-4 h-4 text-green-400 shrink-0" />}
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.reason}</p>
              </div>
              <Badge className={item.visible ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20 text-xs" : "bg-green-500/10 text-green-400 border-green-500/20 text-xs"}>
                {item.visible ? "Can see" : "Hidden"}
              </Badge>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
