import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Upload as UploadIcon, Film, X, CheckCircle2, AlertCircle, Lock, Zap } from "lucide-react";

type UploadStage = "idle" | "uploading" | "processing" | "done" | "error";

const CATEGORIES = ["Technology", "Gaming", "Music", "Science", "Crypto & Web3", "Education", "Sports", "Entertainment"];

export default function Upload() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [stage, setStage] = useState<UploadStage>("idle");
  const [progress, setProgress] = useState(0);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [isPremium, setIsPremium] = useState(false);
  const [isShort, setIsShort] = useState(false);
  const [tags, setTags] = useState("");

  const handleFile = useCallback((f: File) => {
    if (!f.type.startsWith("video/")) {
      toast({ title: "Invalid file", description: "Please select a video file.", variant: "destructive" });
      return;
    }
    setFile(f);
    setTitle(f.name.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " "));
    setStage("idle");
    setProgress(0);
  }, [toast]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped) handleFile(dropped);
  }, [handleFile]);

  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = () => setIsDragging(false);

  const simulateUpload = () => {
    if (!file || !title.trim() || !category) {
      toast({ title: "Missing fields", description: "Please fill in title, category, and select a file.", variant: "destructive" });
      return;
    }

    setStage("uploading");
    setProgress(0);

    const uploadInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(uploadInterval);
          setStage("processing");
          setProcessingProgress(0);

          const processInterval = setInterval(() => {
            setProcessingProgress(p => {
              if (p >= 100) {
                clearInterval(processInterval);
                setStage("done");
                toast({ title: "Upload complete!", description: `"${title}" is now live on Pi Stream.` });
                return 100;
              }
              return p + Math.random() * 8 + 4;
            });
          }, 300);
          return 100;
        }
        return prev + Math.random() * 4 + 2;
      });
    }, 150);
  };

  const resetForm = () => {
    setFile(null); setStage("idle"); setProgress(0); setProcessingProgress(0);
    setTitle(""); setDescription(""); setCategory(""); setTags(""); setIsPremium(false); setIsShort(false);
  };

  return (
    <div className="max-w-3xl mx-auto pb-12">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold text-foreground mb-2">Upload Video</h1>
        <p className="text-muted-foreground">Share your content with the Pi Network community</p>
      </div>

      {/* Drop Zone */}
      {!file ? (
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => fileInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-2xl p-16 flex flex-col items-center justify-center gap-6 cursor-pointer transition-all ${
            isDragging
              ? "border-primary bg-primary/10 scale-[1.01]"
              : "border-white/20 hover:border-primary/50 hover:bg-white/5"
          }`}
        >
          <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
          <div className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${isDragging ? "bg-primary/20" : "bg-white/5"}`}>
            {isDragging
              ? <UploadIcon className="w-10 h-10 text-primary" />
              : <Film className="w-10 h-10 text-muted-foreground" />
            }
          </div>
          <div className="text-center">
            <p className="text-xl font-semibold text-foreground mb-1">
              {isDragging ? "Drop it here" : "Drag & drop your video"}
            </p>
            <p className="text-muted-foreground">or click to browse — MP4, MOV, AVI, WebM supported</p>
          </div>
          <div className="flex gap-3">
            <Badge variant="secondary" className="bg-white/5 text-muted-foreground border-white/10">Any resolution</Badge>
            <Badge variant="secondary" className="bg-white/5 text-muted-foreground border-white/10">Up to 10 GB</Badge>
            <Badge variant="secondary" className="bg-white/5 text-muted-foreground border-white/10">All formats</Badge>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* File Preview */}
          <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
              <Film className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-foreground truncate">{file.name}</p>
              <p className="text-sm text-muted-foreground">{(file.size / (1024 * 1024)).toFixed(1)} MB · {file.type}</p>
            </div>
            {stage === "idle" && (
              <button onClick={resetForm} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-5 h-5" />
              </button>
            )}
            {stage === "done" && <CheckCircle2 className="w-6 h-6 text-green-500 shrink-0" />}
          </div>

          {/* Upload Progress */}
          {stage === "uploading" && (
            <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-semibold text-primary">Uploading...</span>
                <span className="text-sm font-bold text-primary">{Math.round(progress)}%</span>
              </div>
              <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-2">Uploading to Pi Stream servers...</p>
            </div>
          )}

          {/* Processing Progress */}
          {stage === "processing" && (
            <div className="p-4 rounded-xl bg-violet-500/5 border border-violet-500/20">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-violet-400 animate-pulse" />
                  <span className="text-sm font-semibold text-violet-400">Processing video...</span>
                </div>
                <span className="text-sm font-bold text-violet-400">{Math.round(processingProgress)}%</span>
              </div>
              <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary to-violet-400 rounded-full transition-all duration-300"
                  style={{ width: `${processingProgress}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-2">Generating thumbnails · Encoding formats · Indexing content</p>
            </div>
          )}

          {/* Done */}
          {stage === "done" && (
            <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/30 flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-green-400 shrink-0" />
              <div>
                <p className="font-semibold text-green-400">Upload successful!</p>
                <p className="text-sm text-muted-foreground">Your video is live and discoverable by the Pi Network community.</p>
              </div>
              <Button onClick={resetForm} variant="outline" className="ml-auto border-green-500/30 text-green-400 hover:bg-green-500/10">
                Upload another
              </Button>
            </div>
          )}

          {/* Form */}
          {stage === "idle" && (
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Title *</label>
                <Input
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="Give your video a title..."
                  className="bg-white/5 border-white/10 focus-visible:ring-primary"
                  maxLength={100}
                />
                <p className="text-xs text-muted-foreground mt-1 text-right">{title.length}/100</p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Description</label>
                <Textarea
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Tell viewers what your video is about..."
                  className="bg-white/5 border-white/10 focus-visible:ring-primary min-h-[100px] resize-none"
                  maxLength={5000}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Category *</label>
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setCategory(cat)}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all border ${
                        category === cat
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-white/5 text-muted-foreground border-white/10 hover:border-primary/40 hover:text-foreground"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Tags</label>
                <Input
                  value={tags}
                  onChange={e => setTags(e.target.value)}
                  placeholder="pi network, web3, crypto (comma separated)"
                  className="bg-white/5 border-white/10 focus-visible:ring-primary"
                />
              </div>

              <div className="flex flex-wrap gap-4">
                <label className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10 cursor-pointer hover:bg-white/[0.07] transition-colors flex-1">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isPremium ? 'bg-primary/20' : 'bg-white/5'}`}>
                    <Lock className={`w-5 h-5 ${isPremium ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-foreground text-sm">Premium Only</p>
                    <p className="text-xs text-muted-foreground">Require Pi subscription to watch</p>
                  </div>
                  <input type="checkbox" checked={isPremium} onChange={e => setIsPremium(e.target.checked)} className="sr-only" />
                  <div className={`w-10 h-6 rounded-full transition-colors ${isPremium ? 'bg-primary' : 'bg-white/20'} relative`}>
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isPremium ? 'left-5' : 'left-1'}`} />
                  </div>
                </label>

                <label className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10 cursor-pointer hover:bg-white/[0.07] transition-colors flex-1">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isShort ? 'bg-primary/20' : 'bg-white/5'}`}>
                    <Zap className={`w-5 h-5 ${isShort ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-foreground text-sm">Pi Short</p>
                    <p className="text-xs text-muted-foreground">Show in vertical short-form feed</p>
                  </div>
                  <input type="checkbox" checked={isShort} onChange={e => setIsShort(e.target.checked)} className="sr-only" />
                  <div className={`w-10 h-6 rounded-full transition-colors ${isShort ? 'bg-primary' : 'bg-white/20'} relative`}>
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isShort ? 'left-5' : 'left-1'}`} />
                  </div>
                </label>
              </div>

              <Button
                onClick={simulateUpload}
                className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-base"
                disabled={!file || !title.trim() || !category}
              >
                <UploadIcon className="w-5 h-5 mr-2" />
                Upload Video
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
