import { useState } from "react";
import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { Hexagon, ExternalLink, Shield, Zap, Clock, Hash, Check, Upload, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/context/WalletContext";
import { PiLogo } from "@/components/PiLogo";

const NFT_STATS = [
  { label: "Total Video NFTs", value: "—", icon: Layers },
  { label: "IPFS Stored", value: "—", icon: Shield },
  { label: "Total Minted Value", value: "— π", icon: Zap },
  { label: "Provenance Records", value: "—", icon: Hash },
];

function shortHash(s: string) {
  return s.slice(0, 6) + "..." + s.slice(-4);
}

function fakeHash(id: number) {
  return "0x" + ((id * 0xdeadbeef) >>> 0).toString(16).padStart(8, "0") + "a3f9c2b1";
}

function fakeIPFS(id: number) {
  return "Qm" + btoa("pitube-video-" + id).replace(/[^a-zA-Z0-9]/g, "").slice(0, 44);
}

export default function NFTVault() {
  const { data: videos } = useListVideos(undefined, { query: { queryKey: getListVideosQueryKey() } });
  const { isConnected } = useWallet();
  const { toast } = useToast();
  const [minted, setMinted] = useState<Set<number>>(new Set([1, 2, 3, 4, 5]));
  const [minting, setMinting] = useState<number | null>(null);
  const [tab, setTab] = useState<"gallery" | "provenance">("gallery");

  const handleMint = async (id: number) => {
    if (!isConnected) { toast({ title: "Connect Pi Wallet to mint NFTs", variant: "destructive" }); return; }
    setMinting(id);
    await new Promise(r => setTimeout(r, 1800));
    setMinted(s => new Set([...s, id]));
    setMinting(null);
    toast({ title: "🎉 Video NFT Minted!", description: `NFT stored on IPFS/Arweave. TX: ${shortHash(fakeHash(id))}` });
  };

  const provenanceLog = [
    { action: "Video Uploaded", user: "@PiCryptoLabs", time: "2026-05-01 09:14", hash: fakeHash(1) },
    { action: "NFT Minted on IPFS", user: "@PiCryptoLabs", time: "2026-05-01 09:15", hash: fakeHash(2) },
    { action: "Title Edit", user: "@PiCryptoLabs", time: "2026-05-02 14:30", hash: fakeHash(3) },
    { action: "Thumbnail Updated", user: "@PiCryptoLabs", time: "2026-05-03 11:05", hash: fakeHash(4) },
    { action: "AI Watermark Applied", user: "Pi Stream AI", time: "2026-05-03 11:06", hash: fakeHash(5) },
    { action: "Description Updated", user: "@PiCryptoLabs", time: "2026-05-05 16:22", hash: fakeHash(6) },
    { action: "Transferred to New Wallet", user: "@NewOwner", time: "2026-05-10 08:00", hash: fakeHash(7) },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6 py-4">
      <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 px-4 py-3 flex items-start gap-3">
        <Clock className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
        <div>
          <p className="text-sm font-semibold text-amber-400">Coming Soon — Testnet Demo Only</p>
          <p className="text-xs text-muted-foreground mt-0.5">NFT minting and IPFS storage are under development. Hashes shown are simulated and not real blockchain transactions.</p>
        </div>
      </div>
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
          <Hexagon className="w-6 h-6 text-primary" /> NFT Vault & Provenance
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Every video auto-minted as NFT on IPFS/Arweave. Full on-chain edit history.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {NFT_STATS.map(s => (
          <div key={s.label} className="bg-card border border-white/8 rounded-2xl p-4">
            <s.icon className="w-4 h-4 text-primary mb-2" />
            <p className="text-lg font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-white/5 p-1 rounded-xl w-fit">
        {(["gallery", "provenance"] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-1.5 rounded-lg text-sm font-medium capitalize transition-all ${tab === t ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>{t}</button>
        ))}
      </div>

      {tab === "gallery" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {(videos || []).slice(0, 12).map(video => {
            const isMinted = minted.has(video.id);
            const isMinting = minting === video.id;
            const ipfs = fakeIPFS(video.id);
            const hash = fakeHash(video.id);
            return (
              <div key={video.id} className="bg-card border border-white/8 rounded-2xl overflow-hidden group hover:border-primary/30 transition-all">
                {/* Thumbnail */}
                <div className="relative h-32 flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${video.thumbnailColor ?? "#1a1a2e"}, ${video.thumbnailColor2 ?? "#2d1b69"})` }}>
                  <span className="text-4xl font-bold text-white/20">π</span>
                  {isMinted && (
                    <div className="absolute top-2 right-2 flex items-center gap-1 bg-primary/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                      <Check className="w-2.5 h-2.5" /> NFT
                    </div>
                  )}
                  <div className="absolute bottom-2 left-2">
                    <span className="text-xs text-white/60 bg-black/40 px-1.5 py-0.5 rounded">{video.duration}</span>
                  </div>
                </div>
                {/* Info */}
                <div className="p-3 space-y-2">
                  <p className="text-sm font-medium text-foreground line-clamp-1">{video.title}</p>
                  {isMinted ? (
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Shield className="w-3 h-3 text-green-400" />
                        <span className="font-mono">{shortHash(ipfs)}</span>
                        <ExternalLink className="w-2.5 h-2.5 cursor-pointer hover:text-primary" onClick={() => toast({ title: "IPFS Link", description: `ipfs://${ipfs}` })} />
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Hash className="w-3 h-3 text-primary" />
                        <span className="font-mono">{shortHash(hash)}</span>
                      </div>
                    </div>
                  ) : (
                    <Button size="sm" onClick={() => handleMint(video.id)} disabled={isMinting} className="w-full rounded-full bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 text-xs gap-1.5">
                      {isMinting ? <><span className="animate-spin inline-block w-3 h-3 border-2 border-primary border-t-transparent rounded-full" />Minting...</> : <><Upload className="w-3 h-3" />Mint as NFT</>}
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {tab === "provenance" && (
        <div className="space-y-3">
          <div className="bg-card border border-white/8 rounded-2xl p-4">
            <h3 className="font-semibold text-sm text-foreground mb-3 flex items-center gap-2"><Clock className="w-4 h-4 text-primary" />On-Chain Edit History</h3>
            <div className="space-y-0">
              {provenanceLog.map((log, i) => (
                <div key={i} className="flex gap-4 pb-4 relative">
                  <div className="flex flex-col items-center">
                    <div className="w-7 h-7 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center shrink-0 z-10">
                      <Check className="w-3 h-3 text-primary" />
                    </div>
                    {i < provenanceLog.length - 1 && <div className="w-px flex-1 bg-white/10 mt-1" />}
                  </div>
                  <div className="flex-1 pb-2">
                    <p className="text-sm font-medium text-foreground">{log.action}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs text-primary">{log.user}</span>
                      <span className="text-xs text-muted-foreground">·</span>
                      <span className="text-xs text-muted-foreground">{log.time}</span>
                    </div>
                    <p className="text-xs font-mono text-muted-foreground/60 mt-0.5">{shortHash(log.hash)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="p-4 rounded-2xl bg-primary/5 border border-primary/15 text-sm text-muted-foreground">
            <span className="text-primary font-semibold">AI Watermark:</span> All AI-generated content is automatically watermarked and traceable. Tampering with watermarks triggers a DAO moderation review.
          </div>
        </div>
      )}
    </div>
  );
}
