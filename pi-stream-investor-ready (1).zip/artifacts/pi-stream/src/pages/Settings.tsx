import { useState } from "react";
import { Moon, Sun, Globe, Bell, Shield, Info, Palette, Gauge, Download, Trash2, ChevronRight, Check } from "lucide-react";
import { useTheme } from "@/context/ThemeContext";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const LANGUAGES = ["English", "Chinese (中文)", "Hindi (हिन्दी)", "Arabic (العربية)", "Spanish (Español)", "Portuguese (Português)", "Russian (Русский)", "French (Français)"];
const DENSITIES = ["compact", "comfortable", "spacious"] as const;

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const [language, setLanguage] = useState("English");
  const [density, setDensity] = useState<"compact" | "comfortable" | "spacious">("comfortable");
  const [autoplay, setAutoplay] = useState(true);
  const [notifyUploads, setNotifyUploads] = useState(true);
  const [notifyLive, setNotifyLive] = useState(true);
  const [notifyComments, setNotifyComments] = useState(false);
  const [notifyMilestones, setNotifyMilestones] = useState(true);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [autoQuality, setAutoQuality] = useState(true);

  const handleClearHistory = () => {
    localStorage.removeItem("pi-stream-liked");
    localStorage.removeItem("pi-stream-watch-later");
    toast({ title: "Local data cleared", description: "Watch history and liked videos cleared." });
  };

  const handleExportData = () => {
    const data = {
      liked: JSON.parse(localStorage.getItem("pi-stream-liked") || "[]"),
      watchLater: JSON.parse(localStorage.getItem("pi-stream-watch-later") || "[]"),
      wallet: localStorage.getItem("pi-stream-wallet-username"),
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "pi-stream-data.json";
    a.click();
    toast({ title: "Data exported!", description: "pi-stream-data.json downloaded." });
  };

  return (
    <div className="max-w-2xl mx-auto py-6 space-y-6">
      <div>
        <h1 className="text-2xl font-display font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground text-sm mt-1">Customize your Pi Stream experience</p>
      </div>

      {/* Appearance */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <Palette className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">Appearance</h2>
        </div>

        <div className="divide-y divide-white/5">
          {/* Theme */}
          <div className="px-5 py-4">
            <p className="text-sm font-medium text-foreground mb-3">Theme</p>
            <div className="flex gap-3">
              <button
                onClick={() => setTheme("dark")}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border text-sm font-medium transition-all ${theme === "dark" ? "border-primary bg-primary/15 text-primary" : "border-white/10 text-muted-foreground hover:border-white/20"}`}
              >
                <Moon className="w-4 h-4" />
                Dark
                {theme === "dark" && <Check className="w-3 h-3" />}
              </button>
              <button
                onClick={() => setTheme("light")}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border text-sm font-medium transition-all ${theme === "light" ? "border-primary bg-primary/15 text-primary" : "border-white/10 text-muted-foreground hover:border-white/20"}`}
              >
                <Sun className="w-4 h-4" />
                Light
                {theme === "light" && <Check className="w-3 h-3" />}
              </button>
            </div>
          </div>

          {/* Density */}
          <div className="px-5 py-4">
            <p className="text-sm font-medium text-foreground mb-3">Layout Density</p>
            <div className="flex gap-2">
              {DENSITIES.map(d => (
                <button
                  key={d}
                  onClick={() => setDensity(d)}
                  className={`flex-1 py-2 px-3 rounded-xl border text-xs font-medium capitalize transition-all ${density === d ? "border-primary bg-primary/15 text-primary" : "border-white/10 text-muted-foreground hover:border-white/20"}`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          {/* Reduced Motion */}
          <div className="px-5 py-3.5 flex items-center justify-between">
            <div>
              <Label className="text-sm font-medium text-foreground">Reduced Motion</Label>
              <p className="text-xs text-muted-foreground mt-0.5">Minimize animations and transitions</p>
            </div>
            <Switch checked={reducedMotion} onCheckedChange={setReducedMotion} />
          </div>
        </div>
      </section>

      {/* Language */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <Globe className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">Language & Region</h2>
        </div>
        <div className="px-5 py-4">
          <p className="text-sm font-medium text-foreground mb-3">App Language</p>
          <div className="grid grid-cols-2 gap-2">
            {LANGUAGES.map(lang => (
              <button
                key={lang}
                onClick={() => { setLanguage(lang); toast({ title: `Language set to ${lang.split(" ")[0]}` }); }}
                className={`text-left py-2 px-3 rounded-xl border text-xs transition-all ${language === lang ? "border-primary bg-primary/15 text-primary" : "border-white/10 text-muted-foreground hover:border-white/20"}`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Playback */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <Gauge className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">Playback</h2>
        </div>
        <div className="divide-y divide-white/5">
          <div className="px-5 py-3.5 flex items-center justify-between">
            <div>
              <Label className="text-sm font-medium text-foreground">Autoplay next video</Label>
              <p className="text-xs text-muted-foreground mt-0.5">Automatically play the next recommended video</p>
            </div>
            <Switch checked={autoplay} onCheckedChange={setAutoplay} />
          </div>
          <div className="px-5 py-3.5 flex items-center justify-between">
            <div>
              <Label className="text-sm font-medium text-foreground">Auto video quality</Label>
              <p className="text-xs text-muted-foreground mt-0.5">Adjust quality based on your connection</p>
            </div>
            <Switch checked={autoQuality} onCheckedChange={setAutoQuality} />
          </div>
        </div>
      </section>

      {/* Notifications */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <Bell className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">Notifications</h2>
        </div>
        <div className="divide-y divide-white/5">
          {[
            { label: "New uploads from subscriptions", sub: "Get notified when creators you follow upload", val: notifyUploads, set: setNotifyUploads },
            { label: "Live stream alerts", sub: "When a subscribed creator goes live", val: notifyLive, set: setNotifyLive },
            { label: "Comments on your videos", sub: "New comments and replies", val: notifyComments, set: setNotifyComments },
            { label: "Milestone alerts", sub: "View count milestones for your videos", val: notifyMilestones, set: setNotifyMilestones },
          ].map(item => (
            <div key={item.label} className="px-5 py-3.5 flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium text-foreground">{item.label}</Label>
                <p className="text-xs text-muted-foreground mt-0.5">{item.sub}</p>
              </div>
              <Switch checked={item.val} onCheckedChange={item.set} />
            </div>
          ))}
        </div>
      </section>

      {/* Privacy & Data */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <Shield className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">Privacy & Data</h2>
        </div>
        <div className="divide-y divide-white/5">
          <button onClick={handleExportData} className="w-full px-5 py-3.5 flex items-center justify-between hover:bg-white/5 transition-colors">
            <div className="flex items-center gap-3">
              <Download className="w-4 h-4 text-muted-foreground" />
              <div className="text-left">
                <p className="text-sm font-medium text-foreground">Export your data</p>
                <p className="text-xs text-muted-foreground">Download your Pi Stream data as JSON</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={handleClearHistory} className="w-full px-5 py-3.5 flex items-center justify-between hover:bg-white/5 transition-colors">
            <div className="flex items-center gap-3">
              <Trash2 className="w-4 h-4 text-red-400" />
              <div className="text-left">
                <p className="text-sm font-medium text-red-400">Clear local data</p>
                <p className="text-xs text-muted-foreground">Clears liked videos & watch later lists</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      </section>

      {/* About */}
      <section className="rounded-2xl bg-card border border-white/8 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 flex items-center gap-2">
          <Info className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm text-foreground">About Pi Stream</h2>
        </div>
        <div className="px-5 py-4 space-y-3">
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Version</span>
            <Badge variant="outline" className="text-primary border-primary/30 font-mono">v2.0.0</Badge>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Network</span>
            <span className="text-foreground font-medium">Pi Network Mainnet</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Payment</span>
            <span className="text-foreground font-medium">Pi coin only</span>
          </div>
          <Button variant="outline" className="w-full mt-2 rounded-xl border-white/10 hover:bg-white/5" onClick={() => window.open("https://minepi.com", "_blank")}>
            Visit Pi Network
          </Button>
        </div>
      </section>
    </div>
  );
}
