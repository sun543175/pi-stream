import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { useState } from "react";
import { BarChart2, Eye, ThumbsUp, Clock, Edit3, Trash2, Globe, Lock, EyeOff, Upload, CheckSquare, Square, TrendingUp, Users, DollarSign, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { useWallet } from "@/context/WalletContext";
import { useToast } from "@/hooks/use-toast";

type Visibility = "public" | "private" | "unlisted";

export default function Studio() {
  const { isConnected, piUsername } = useWallet();
  const { toast } = useToast();
  const { data: videos } = useListVideos(undefined, { query: { queryKey: getListVideosQueryKey() } });
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [search, setSearch] = useState("");
  const [visibilityMap, setVisibilityMap] = useState<Record<number, Visibility>>({});
  const [tab, setTab] = useState<"videos" | "analytics" | "schedule">("videos");

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
        <div className="w-16 h-16 rounded-2xl bg-primary/15 flex items-center justify-center">
          <BarChart2 className="w-8 h-8 text-primary" />
        </div>
        <h2 className="text-xl font-display font-bold">Creator Studio</h2>
        <p className="text-muted-foreground text-sm text-center max-w-sm">Connect your Pi Wallet to access the Creator Studio and manage your videos.</p>
        <Link href="/"><Button className="rounded-full bg-primary text-primary-foreground">Connect Wallet on Home</Button></Link>
      </div>
    );
  }

  const myVideos = (videos || []).filter(v =>
    v.channelName?.toLowerCase().includes(piUsername?.toLowerCase() || "") ||
    !piUsername ? true : false
  ).slice(0, 12);

  const filteredVideos = myVideos.filter(v =>
    !search || v.title?.toLowerCase().includes(search.toLowerCase())
  );

  const toggleSelect = (id: number) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const selectAll = () => {
    if (selected.size === filteredVideos.length) setSelected(new Set());
    else setSelected(new Set(filteredVideos.map(v => v.id)));
  };

  const bulkDelete = () => {
    toast({ title: `${selected.size} videos deleted`, description: "Videos have been removed from your channel." });
    setSelected(new Set());
  };

  const setVisibility = (id: number, vis: Visibility) => {
    setVisibilityMap(m => ({ ...m, [id]: vis }));
    toast({ title: `Video set to ${vis}` });
  };

  const statsCards = [
    { icon: Eye, label: "Total Views", value: "24.8K", change: "+12%", color: "text-blue-400" },
    { icon: Users, label: "Subscribers", value: "1,240", change: "+8%", color: "text-green-400" },
    { icon: DollarSign, label: "Pi Revenue", value: "14.5 π", change: "+23%", color: "text-primary" },
    { icon: TrendingUp, label: "Watch Time", value: "8,420 min", change: "+5%", color: "text-yellow-400" },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground">Creator Studio</h1>
          <p className="text-muted-foreground text-sm mt-0.5">@{piUsername} · Manage your content</p>
        </div>
        <Link href="/upload">
          <Button className="rounded-full bg-primary text-primary-foreground gap-2">
            <Upload className="w-4 h-4" />
            Upload Video
          </Button>
        </Link>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {statsCards.map(card => (
          <div key={card.label} className="bg-card border border-white/8 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <card.icon className={`w-4 h-4 ${card.color}`} />
              <span className="text-xs text-green-400 font-medium">{card.change}</span>
            </div>
            <p className="text-xl font-bold text-foreground">{card.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{card.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-white/5 p-1 rounded-xl w-fit">
        {(["videos", "analytics", "schedule"] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium capitalize transition-all ${tab === t ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"}`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "videos" && (
        <div className="space-y-3">
          {/* Toolbar */}
          <div className="flex items-center gap-3 flex-wrap">
            <Input
              placeholder="Search your videos..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="max-w-xs bg-white/5 border-white/10 rounded-xl focus-visible:ring-primary text-sm"
            />
            {selected.size > 0 && (
              <div className="flex items-center gap-2">
                <Badge className="bg-primary/20 text-primary border-primary/30">{selected.size} selected</Badge>
                <Button variant="destructive" size="sm" onClick={bulkDelete} className="rounded-full text-xs gap-1">
                  <Trash2 className="w-3 h-3" />
                  Delete
                </Button>
                <Button variant="outline" size="sm" onClick={() => setSelected(new Set())} className="rounded-full text-xs border-white/10">
                  Clear
                </Button>
              </div>
            )}
          </div>

          {/* Table */}
          <div className="rounded-2xl border border-white/8 overflow-hidden">
            {/* Table header */}
            <div className="flex items-center gap-4 px-4 py-2.5 bg-white/3 border-b border-white/8 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              <button onClick={selectAll} className="shrink-0">
                {selected.size === filteredVideos.length && filteredVideos.length > 0
                  ? <CheckSquare className="w-4 h-4 text-primary" />
                  : <Square className="w-4 h-4" />
                }
              </button>
              <span className="flex-1">Video</span>
              <span className="hidden md:block w-20 text-center">Views</span>
              <span className="hidden md:block w-16 text-center">Likes</span>
              <span className="w-24 text-center">Visibility</span>
              <span className="w-16 text-center">Actions</span>
            </div>

            {filteredVideos.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
                <BarChart2 className="w-8 h-8 opacity-20" />
                <p className="text-sm">No videos found</p>
              </div>
            ) : (
              <div className="divide-y divide-white/5">
                {filteredVideos.map(video => {
                  const vis: Visibility = visibilityMap[video.id] || "public";
                  const VisIcon = vis === "public" ? Globe : vis === "private" ? Lock : EyeOff;
                  return (
                    <div key={video.id} className={`flex items-center gap-4 px-4 py-3 hover:bg-white/3 transition-colors ${selected.has(video.id) ? "bg-primary/5" : ""}`}>
                      <button onClick={() => toggleSelect(video.id)} className="shrink-0">
                        {selected.has(video.id)
                          ? <CheckSquare className="w-4 h-4 text-primary" />
                          : <Square className="w-4 h-4 text-muted-foreground" />
                        }
                      </button>

                      {/* Thumbnail + title */}
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div
                          className="w-16 h-9 rounded-lg shrink-0 flex items-center justify-center"
                          style={{ background: `linear-gradient(135deg, ${video.thumbnailColor ?? "#1a1a2e"}, ${video.thumbnailColor2 ?? "#2d1b69"})` }}
                        >
                          <span className="text-white/40 text-xs font-bold">π</span>
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-foreground line-clamp-1">{video.title}</p>
                          <p className="text-xs text-muted-foreground">{video.duration}</p>
                        </div>
                      </div>

                      <span className="hidden md:block w-20 text-center text-sm text-muted-foreground">{video.views}</span>
                      <span className="hidden md:block w-16 text-center text-sm text-muted-foreground">{video.likes?.toLocaleString()}</span>

                      {/* Visibility selector */}
                      <div className="w-24 flex justify-center">
                        <select
                          value={vis}
                          onChange={e => setVisibility(video.id, e.target.value as Visibility)}
                          className="text-xs bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-foreground focus:outline-none focus:border-primary"
                        >
                          <option value="public">Public</option>
                          <option value="unlisted">Unlisted</option>
                          <option value="private">Private</option>
                        </select>
                      </div>

                      <div className="w-16 flex justify-center gap-1">
                        <Link href={`/watch/${video.id}`}>
                          <button className="p-1.5 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-foreground transition-colors">
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {tab === "analytics" && (
        <div className="flex flex-col items-center justify-center py-16 gap-3 text-muted-foreground">
          <BarChart2 className="w-12 h-12 opacity-20" />
          <p>Full analytics available in the <Link href="/analytics"><span className="text-primary hover:underline">Analytics Dashboard</span></Link></p>
        </div>
      )}

      {tab === "schedule" && (
        <div className="space-y-4">
          <div className="flex flex-col items-center justify-center py-12 gap-4 rounded-2xl border border-dashed border-white/15 text-muted-foreground">
            <Calendar className="w-12 h-12 opacity-20" />
            <p className="text-sm font-medium">Scheduled Publishing</p>
            <p className="text-xs text-center max-w-sm">Upload a video and set a future go-live date when uploading. Scheduled videos will appear here.</p>
            <Link href="/upload"><Button variant="outline" size="sm" className="rounded-full border-white/10 gap-2"><Upload className="w-3.5 h-3.5" />Upload & Schedule</Button></Link>
          </div>
        </div>
      )}
    </div>
  );
}
