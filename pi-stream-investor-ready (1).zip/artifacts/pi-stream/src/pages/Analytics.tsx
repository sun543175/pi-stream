import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";
import { useListVideos, getListVideosQueryKey } from "@workspace/api-client-react";
import { useWallet } from "@/context/WalletContext";
import { Link } from "wouter";
import { TrendingUp, Users, Eye, Coins, PlaySquare, ThumbsUp, Clock, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { VideoCard } from "@/components/video/VideoCard";

// Deterministic seeded random for consistent chart data
function seeded(seed: number) {
  let s = seed;
  return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
}

function genViewsData() {
  const rand = seeded(42);
  const labels = ["May 8","May 9","May 10","May 11","May 12","May 13","May 14",
    "May 15","May 16","May 17","May 18","May 19","May 20","May 21"];
  return labels.map(date => ({
    date,
    views: Math.round(8000 + rand() * 22000),
    unique: Math.round(4000 + rand() * 12000),
  }));
}

function genRevenueData() {
  const rand = seeded(99);
  const months = ["Dec","Jan","Feb","Mar","Apr","May"];
  return months.map(month => ({
    month,
    revenue: parseFloat((rand() * 8 + 1).toFixed(2)),
    subs: Math.round(rand() * 40 + 5),
  }));
}

function genSubData() {
  const rand = seeded(77);
  const labels = ["May 8","May 10","May 12","May 14","May 16","May 18","May 20","May 21"];
  let total = 820;
  return labels.map(date => {
    total += Math.round(rand() * 120 + 10);
    return { date, subscribers: total };
  });
}

const viewsData = genViewsData();
const revenueData = genRevenueData();
const subData = genSubData();

const TOOLTIP_STYLE = {
  contentStyle: { background: "#0f0f1a", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "0.75rem", color: "#fff" },
  labelStyle: { color: "rgba(255,255,255,0.6)", fontSize: 11 },
  itemStyle: { color: "#a855f7" },
};

export default function Analytics() {
  const { isConnected, piUsername, walletAddress } = useWallet();
  const { data: allVideos, isLoading } = useListVideos(undefined, {
    query: { queryKey: getListVideosQueryKey() }
  });

  const totalViews = viewsData.reduce((s, d) => s + d.views, 0);
  const totalRevenue = revenueData.reduce((s, d) => s + d.revenue, 0);
  const latestSubs = subData[subData.length - 1]?.subscribers ?? 0;
  const totalLikes = allVideos?.reduce((s, v) => s + (v.likes || 0), 0) ?? 0;

  const topVideos = allVideos
    ? [...allVideos].sort((a, b) => (b.likes || 0) - (a.likes || 0)).slice(0, 5)
    : [];

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center gap-6">
        <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center">
          <TrendingUp className="w-10 h-10 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-display font-bold text-foreground mb-2">Creator Analytics</h2>
          <p className="text-muted-foreground max-w-sm">Connect your Pi Wallet to view your channel's performance, revenue, and audience insights.</p>
        </div>
        <Link href="/">
          <Button className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90 px-8">
            Go to Home & Connect Wallet
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="pb-16 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground">Creator Analytics</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            @{piUsername} · <span className="font-mono text-xs">{walletAddress?.slice(0, 16)}…</span>
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary/10 border border-primary/20 text-primary text-sm font-medium">
          <Award className="w-4 h-4" />
          Verified Creator
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Eye, label: "Views (14d)", value: totalViews.toLocaleString(), delta: "+18.4%", color: "text-primary" },
          { icon: Coins, label: "Revenue (6mo)", value: `${totalRevenue.toFixed(2)} π`, delta: "+23.1%", color: "text-violet-400" },
          { icon: Users, label: "Subscribers", value: latestSubs.toLocaleString(), delta: "+142", color: "text-indigo-400" },
          { icon: ThumbsUp, label: "Total Likes", value: totalLikes.toLocaleString(), delta: "+5.2%", color: "text-pink-400" },
        ].map(({ icon: Icon, label, value, delta, color }) => (
          <div key={label} className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="flex items-center justify-between mb-3">
              <div className={`w-9 h-9 rounded-full bg-white/5 flex items-center justify-center ${color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <span className="text-xs font-semibold text-green-400 bg-green-400/10 px-2 py-0.5 rounded-full">{delta}</span>
            </div>
            <p className={`text-2xl font-bold ${color}`}>{value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Views Over Time */}
      <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
        <div className="flex items-center gap-2 mb-5">
          <Eye className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-foreground">Views Over Time</h3>
          <span className="ml-auto text-xs text-muted-foreground">Last 14 days</span>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={viewsData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="viewsGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="uniqueGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#818cf8" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#818cf8" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="date" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
            <Tooltip {...TOOLTIP_STYLE} formatter={(v: number) => [v.toLocaleString(), ""]} />
            <Legend wrapperStyle={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }} />
            <Area type="monotone" dataKey="views" name="Total Views" stroke="#a855f7" strokeWidth={2} fill="url(#viewsGrad)" dot={false} />
            <Area type="monotone" dataKey="unique" name="Unique Viewers" stroke="#818cf8" strokeWidth={2} fill="url(#uniqueGrad)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Revenue + Subscribers row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Revenue */}
        <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
          <div className="flex items-center gap-2 mb-5">
            <Coins className="w-4 h-4 text-violet-400" />
            <h3 className="font-semibold text-foreground">Revenue in π</h3>
            <span className="ml-auto text-xs text-muted-foreground">Last 6 months</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={revenueData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}π`} />
              <Tooltip {...TOOLTIP_STYLE} formatter={(v: number) => [`${v.toFixed(2)} π`, "Revenue"]} />
              <Bar dataKey="revenue" name="Revenue π" fill="#a855f7" radius={[4, 4, 0, 0]} maxBarSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Subscriber Growth */}
        <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
          <div className="flex items-center gap-2 mb-5">
            <Users className="w-4 h-4 text-indigo-400" />
            <h3 className="font-semibold text-foreground">Subscriber Growth</h3>
            <span className="ml-auto text-xs text-muted-foreground">Last 14 days</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={subData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="date" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip {...TOOLTIP_STYLE} formatter={(v: number) => [v.toLocaleString(), "Subscribers"]} />
              <Line type="monotone" dataKey="subscribers" name="Subscribers" stroke="#818cf8" strokeWidth={2.5} dot={false} activeDot={{ r: 4, fill: "#818cf8" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top Videos Table */}
      <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
        <div className="flex items-center gap-2 mb-5">
          <PlaySquare className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-foreground">Top Performing Videos</h3>
        </div>
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-12 rounded-lg bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left pb-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">#</th>
                  <th className="text-left pb-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Video</th>
                  <th className="text-right pb-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Views</th>
                  <th className="text-right pb-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Likes</th>
                  <th className="text-right pb-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Est. Revenue</th>
                  <th className="text-right pb-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Watch Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {topVideos.map((video, i) => {
                  const estRevenue = ((video.likes || 0) / 100000 * 2.5).toFixed(2);
                  const watchTime = Math.round((video.likes || 0) / 1000);
                  return (
                    <tr key={video.id} className="hover:bg-white/[0.03] transition-colors group">
                      <td className="py-3 pr-3">
                        <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${i === 0 ? "bg-primary/20 text-primary" : "text-muted-foreground"}`}>
                          {i + 1}
                        </span>
                      </td>
                      <td className="py-3 pr-4 max-w-0 w-full">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-7 rounded shrink-0 overflow-hidden"
                            style={{ background: `linear-gradient(135deg, ${video.thumbnailColor}, ${video.thumbnailColor2 || "#1a1a2e"})` }}>
                            <div className="w-full h-full flex items-center justify-center text-base">{video.thumbnailEmoji}</div>
                          </div>
                          <Link href={`/watch/${video.id}`}>
                            <span className="font-medium text-foreground truncate block hover:text-primary transition-colors cursor-pointer">
                              {video.title}
                            </span>
                          </Link>
                        </div>
                      </td>
                      <td className="py-3 text-right text-muted-foreground whitespace-nowrap">{video.views}</td>
                      <td className="py-3 text-right text-muted-foreground whitespace-nowrap">{(video.likes || 0).toLocaleString()}</td>
                      <td className="py-3 text-right whitespace-nowrap">
                        <span className="text-violet-400 font-medium">{estRevenue} π</span>
                      </td>
                      <td className="py-3 text-right text-muted-foreground whitespace-nowrap">
                        <span className="flex items-center justify-end gap-1">
                          <Clock className="w-3 h-3" />{watchTime}k min
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Audience Breakdown */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: "Avg. Watch Time", value: "14m 32s", icon: Clock, sub: "Per video session" },
          { label: "Click-Through Rate", value: "6.8%", icon: TrendingUp, sub: "From impressions" },
          { label: "Pi Earnings Rate", value: "0.0024 π/view", icon: Coins, sub: "Platform share" },
        ].map(({ label, value, icon: Icon, sub }) => (
          <div key={label} className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary shrink-0">
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-lg font-bold text-primary">{value}</p>
              <p className="text-xs font-semibold text-foreground">{label}</p>
              <p className="text-xs text-muted-foreground">{sub}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
