import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useWallet } from "@/context/WalletContext";
import { PiLogo } from "@/components/PiLogo";
import { CheckCircle2, Loader2, ShieldCheck, Zap, User } from "lucide-react";

type Props = {
  open: boolean;
  onClose: () => void;
};

type Step = "input" | "authenticating" | "done";

export function ConnectWalletModal({ open, onClose }: Props) {
  const { connect, isConnecting } = useWallet();
  const [username, setUsername] = useState("");
  const [step, setStep] = useState<Step>("input");
  const [error, setError] = useState("");

  const handleConnect = async () => {
    const clean = username.trim().replace(/^@/, "");
    if (!clean || clean.length < 3) {
      setError("Enter your Pi Network username (min. 3 characters).");
      return;
    }
    setError("");
    setStep("authenticating");
    try {
      await connect(clean);
      setStep("done");
      setTimeout(() => {
        onClose();
        setStep("input");
        setUsername("");
      }, 1400);
    } catch {
      setStep("input");
      setError("Authentication failed. Please try again.");
    }
  };

  const handleClose = () => {
    if (isConnecting) return;
    onClose();
    setTimeout(() => { setStep("input"); setUsername(""); setError(""); }, 300);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-card border-white/10 text-foreground">
        {step === "input" && (
          <>
            <DialogHeader className="text-center items-center gap-2 pb-2">
              <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-1">
                <PiLogo className="w-8 h-8 text-primary" />
              </div>
              <DialogTitle className="text-xl font-display">Connect Pi Wallet</DialogTitle>
              <DialogDescription>
                Sign in with your Pi Network identity to unlock premium features.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-2">
              {/* Benefits */}
              <div className="space-y-2">
                {[
                  { icon: ShieldCheck, text: "Your subscription is tied to your Pi identity" },
                  { icon: Zap, text: "Access premium content across all devices" },
                  { icon: User, text: "Personalized recommendations and history" },
                ].map(({ icon: Icon, text }) => (
                  <div key={text} className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Icon className="w-4 h-4 text-primary shrink-0" />
                    <span>{text}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-white/10 pt-4">
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Pi Network Username
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium text-sm">@</span>
                  <Input
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && handleConnect()}
                    placeholder="your.pi.username"
                    className="pl-7 bg-white/5 border-white/10 focus-visible:ring-primary"
                    autoFocus
                  />
                </div>
                {error && <p className="text-xs text-destructive mt-1.5">{error}</p>}
              </div>
            </div>

            <Button
              onClick={handleConnect}
              className="w-full h-11 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
              disabled={!username.trim()}
            >
              <PiLogo className="w-4 h-4 mr-2" />
              Authenticate with Pi Network
            </Button>

            <p className="text-center text-xs text-muted-foreground">
              Pi Stream uses Pi Network's identity system. No password required.
            </p>
          </>
        )}

        {step === "authenticating" && (
          <div className="flex flex-col items-center justify-center py-10 gap-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center">
                <PiLogo className="w-10 h-10 text-primary" />
              </div>
              <div className="absolute inset-0 rounded-full border-2 border-primary/40 border-t-primary animate-spin" />
            </div>
            <div className="text-center space-y-1">
              <p className="font-semibold text-foreground">Authenticating with Pi Network</p>
              <p className="text-sm text-muted-foreground">Verifying @{username.trim().replace(/^@/, "")}...</p>
            </div>
            <div className="flex gap-2">
              {["Connecting", "Verifying", "Securing"].map((label, i) => (
                <div key={label} className="flex items-center gap-1.5 text-xs text-muted-foreground bg-white/5 rounded-full px-3 py-1">
                  <Loader2 className="w-3 h-3 animate-spin" style={{ animationDelay: `${i * 0.2}s` }} />
                  {label}
                </div>
              ))}
            </div>
          </div>
        )}

        {step === "done" && (
          <div className="flex flex-col items-center justify-center py-10 gap-4">
            <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10 text-green-400" />
            </div>
            <div className="text-center space-y-1">
              <p className="text-xl font-bold text-foreground">Connected!</p>
              <p className="text-sm text-muted-foreground">Welcome to Pi Stream, @{username.trim().replace(/^@/, "")}</p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
