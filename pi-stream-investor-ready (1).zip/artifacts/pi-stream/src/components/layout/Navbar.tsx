import { Link, useLocation } from "wouter";
import { PiLogo } from "../PiLogo";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Bell, Upload, X, LogOut, BarChart2, ChevronDown } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { useGetSubscriptionStatus, getGetSubscriptionStatusQueryKey } from "@workspace/api-client-react";
import { useWallet } from "@/context/WalletContext";
import { ConnectWalletModal } from "@/components/wallet/ConnectWalletModal";
import { PiLogo as PiIcon } from "@/components/PiLogo";

const SUGGESTIONS = [
  "Pi Network blockchain", "Web3 tutorial", "Crypto gaming", "Pi Network testnet",
  "DeFi fundamentals", "Pi wallet setup", "Live crypto", "NFT explained",
  "Blockchain science", "Pi Network exchange", "Play to earn", "Pi music",
];

export function Navbar() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showWalletMenu, setShowWalletMenu] = useState(false);
  const [walletModalOpen, setWalletModalOpen] = useState(false);
  const [dismissedNotifs, setDismissedNotifs] = useState<number[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const walletRef = useRef<HTMLDivElement>(null);

  const { isConnected, piUsername, walletAddress, disconnect } = useWallet();
  const { data: subStatus } = useGetSubscriptionStatus({ query: { queryKey: getGetSubscriptionStatusQueryKey() } });

  const filteredSuggestions = searchQuery.trim().length > 0
    ? SUGGESTIONS.filter(s => s.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 6)
    : SUGGESTIONS.slice(0, 6);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
      setShowSuggestions(false);
    }
  };

  const pickSuggestion = (s: string) => {
    setSearchQuery(s);
    setLocation(`/search?q=${encodeURIComponent(s)}`);
    setShowSuggestions(false);
  };

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setShowSuggestions(false);
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setShowNotifications(false);
      if (walletRef.current && !walletRef.current.contains(e.target as Node)) setShowWalletMenu(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const notifications = [
    { id: 1, title: "New trending video", body: "Pi Network Testnet explained — new deep-dive just posted!", time: "2m ago", dot: "bg-primary" },
    { id: 2, title: "Platform update", body: "Pi Stream testnet demo updated with new features.", time: "15m ago", dot: "bg-destructive" },
    { id: 3, title: "Weekly digest", body: "4 new videos in Crypto & Web3 this week.", time: "1h ago", dot: "bg-secondary" },
  ].filter(n => !dismissedNotifs.includes(n.id));

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-white/5 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-4 flex h-16 items-center justify-between gap-4">
        {/* Logo */}
        <div className="flex items-center gap-6 md:gap-8 shrink-0">
          <Link href="/" className="flex items-center gap-2 group">
            <PiLogo className="w-8 h-8 text-primary group-hover:scale-110 transition-transform" />
            <span className="font-display font-bold text-xl tracking-tight hidden sm:inline-block">Pi Stream</span>
          </Link>
        </div>

        {/* Search */}
        <div className="flex-1 max-w-2xl" ref={searchRef}>
          <form onSubmit={handleSearch} className="relative flex items-center">
            <Input
              type="search"
              placeholder="Search videos, creators..."
              className="w-full bg-black/40 border-white/10 focus-visible:ring-primary h-10 rounded-full pl-4 pr-12"
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setShowSuggestions(true); }}
              onFocus={() => setShowSuggestions(true)}
            />
            <Button type="submit" size="icon" variant="ghost" className="absolute right-0 rounded-full h-10 w-10 text-muted-foreground hover:text-primary hover:bg-transparent">
              <Search className="w-5 h-5" />
            </Button>
            {showSuggestions && filteredSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50">
                {filteredSuggestions.map((s) => (
                  <button key={s} type="button" onMouseDown={() => pickSuggestion(s)}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-white/5 transition-colors text-sm">
                    <Search className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                    <span className="text-foreground">{s}</span>
                  </button>
                ))}
              </div>
            )}
          </form>
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Upload shortcut */}
          <Link href="/upload" className="hidden md:flex">
            <Button variant="ghost" size="icon" className="rounded-full text-muted-foreground hover:text-primary hover:bg-primary/10">
              <Upload className="w-5 h-5" />
            </Button>
          </Link>

          {/* Go Premium (only when not subscribed) */}
          {subStatus?.status !== 'active' && (
            <Link href="/subscribe" className="hidden md:flex">
              <Button variant="outline" className="rounded-full border-primary/50 text-primary hover:bg-primary/10 text-sm font-semibold">
                Go Premium
              </Button>
            </Link>
          )}
          {subStatus?.status === 'active' && (
            <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium">
              <PiIcon className="w-3.5 h-3.5" />
              Premium
            </div>
          )}

          {/* Notification Bell */}
          <div className="relative" ref={notifRef}>
            <Button variant="ghost" size="icon" className="rounded-full text-muted-foreground hover:text-primary hover:bg-primary/10 relative"
              onClick={() => { setShowNotifications(s => !s); setShowWalletMenu(false); }}>
              <Bell className="w-5 h-5" />
              {notifications.length > 0 && <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-primary" />}
            </Button>
            {showNotifications && (
              <div className="absolute right-0 top-full mt-2 w-80 bg-card border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50">
                <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
                  <h3 className="font-semibold text-foreground text-sm">Notifications</h3>
                  {notifications.length > 0 && (
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-primary/20 text-primary">{notifications.length} new</span>
                  )}
                </div>
                {notifications.length === 0 ? (
                  <div className="px-4 py-8 text-center text-muted-foreground text-sm">You're all caught up!</div>
                ) : (
                  notifications.map(n => (
                    <div key={n.id} className="flex items-start gap-3 px-4 py-3 hover:bg-white/5 transition-colors border-b border-white/5 last:border-0 group">
                      <div className={`w-2 h-2 rounded-full mt-2 shrink-0 ${n.dot}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground">{n.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.body}</p>
                        <p className="text-xs text-muted-foreground/60 mt-1">{n.time}</p>
                      </div>
                      <button onClick={() => setDismissedNotifs(d => [...d, n.id])}
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-foreground">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Wallet / Profile */}
          <div className="relative" ref={walletRef}>
            {isConnected ? (
              <button
                onClick={() => { setShowWalletMenu(s => !s); setShowNotifications(false); }}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/15 border border-primary/30 hover:bg-primary/25 transition-colors"
              >
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xs">
                  {piUsername?.charAt(0).toUpperCase()}
                </div>
                <span className="text-sm font-semibold text-primary hidden sm:block max-w-[80px] truncate">@{piUsername}</span>
                <ChevronDown className="w-3 h-3 text-primary hidden sm:block" />
              </button>
            ) : (
              <Button
                onClick={() => setWalletModalOpen(true)}
                className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90 text-sm font-semibold h-9 px-4"
              >
                <PiIcon className="w-4 h-4 mr-1.5" />
                <span className="hidden sm:inline">Connect Wallet</span>
                <span className="sm:hidden">Connect</span>
              </Button>
            )}

            {showWalletMenu && isConnected && (
              <div className="absolute right-0 top-full mt-2 w-64 bg-card border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50">
                {/* Wallet Info */}
                <div className="px-4 py-4 border-b border-white/10 bg-primary/5">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">
                      {piUsername?.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">@{piUsername}</p>
                      <p className="text-xs text-muted-foreground font-mono">{walletAddress?.slice(0, 20)}…</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-green-400 bg-green-400/10 rounded-full px-2.5 py-1 w-fit">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                    Pi Wallet Connected
                  </div>
                </div>

                {/* Menu Items */}
                <div className="py-1">
                  <Link href="/analytics" onClick={() => setShowWalletMenu(false)}>
                    <button className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-foreground hover:bg-white/5 transition-colors text-left">
                      <BarChart2 className="w-4 h-4 text-primary" />
                      Creator Analytics
                    </button>
                  </Link>
                  <Link href="/subscribe" onClick={() => setShowWalletMenu(false)}>
                    <button className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-foreground hover:bg-white/5 transition-colors text-left">
                      <PiIcon className="w-4 h-4 text-primary" />
                      Manage Subscription
                    </button>
                  </Link>
                  <div className="border-t border-white/10 my-1" />
                  <button
                    onClick={() => { disconnect(); setShowWalletMenu(false); }}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-destructive hover:bg-destructive/10 transition-colors text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    Disconnect Wallet
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <ConnectWalletModal open={walletModalOpen} onClose={() => setWalletModalOpen(false)} />
    </>
  );
}
