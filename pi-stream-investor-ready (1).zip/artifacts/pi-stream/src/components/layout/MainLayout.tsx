import { ReactNode } from "react";
import { Navbar } from "./Navbar";
import { Sidebar } from "./Sidebar";
import { FlaskConical } from "lucide-react";

export function MainLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-screen w-full flex-col bg-background text-foreground overflow-hidden">
      <div className="w-full bg-yellow-500/15 border-b border-yellow-500/30 px-4 py-1.5 flex items-center justify-center gap-2 text-xs font-medium text-yellow-400 shrink-0">
        <FlaskConical className="w-3.5 h-3.5 shrink-0" />
        <span><strong>Testnet Demo</strong> — This is a developer preview running on Pi Network Testnet. No real Pi is transferred.</span>
      </div>
      <Navbar />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-y-auto bg-black/40">
          <div className="container mx-auto p-4 md:p-6 lg:p-8 max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
