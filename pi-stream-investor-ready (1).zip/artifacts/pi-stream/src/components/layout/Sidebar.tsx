import { Link, useLocation } from "wouter";
import {
  Home, Radio, Clock, PlaySquare, ArrowLeftRight, Flame, Upload, ThumbsUp,
  BookmarkCheck, Crown, BarChart2, Clapperboard, Bell, Settings, Layers,
  Gavel, Hexagon, Globe, Sparkles, ArrowRightLeft, Glasses, ShoppingBag,
  Shield, Users, Coins, TrendingUp
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useWallet } from "@/context/WalletContext";

const mainNav = [
  { icon: Home, label: "Home", href: "/" },
  { icon: Flame, label: "Trending", href: "/trending" },
  { icon: Layers, label: "Shorts", href: "/shorts" },
  { icon: Radio, label: "Live", href: "/live" },
];

const libraryNav = [
  { icon: PlaySquare, label: "Playlists", href: "/playlists" },
  { icon: Clock, label: "History", href: "/history" },
  { icon: BookmarkCheck, label: "Watch Later", href: "/watch-later" },
  { icon: ThumbsUp, label: "Liked Videos", href: "/liked" },
  { icon: Bell, label: "Notifications", href: "/notifications" },
];

const creatorNav = [
  { icon: Upload, label: "Upload", href: "/upload" },
  { icon: Clapperboard, label: "Studio", href: "/studio" },
  { icon: BarChart2, label: "Analytics", href: "/analytics" },
  { icon: Sparkles, label: "AI Studio", href: "/ai-studio" },
  { icon: ArrowLeftRight, label: "Exchange", href: "/exchange" },
  { icon: Settings, label: "Settings", href: "/settings" },
];

const web3Nav = [
  { icon: Gavel, label: "DAO Governance", href: "/dao" },
  { icon: Coins, label: "Staking", href: "/staking" },
  { icon: Hexagon, label: "NFT Vault", href: "/nft-vault" },
  { icon: Globe, label: "Web3 Identity", href: "/web3-id" },
  { icon: ArrowRightLeft, label: "Cross-Chain", href: "/cross-chain" },
  { icon: Users, label: "Community DAOs", href: "/community-dao" },
];

const xpNav = [
  { icon: Glasses, label: "VR Parties", href: "/vr-party" },
  { icon: ShoppingBag, label: "Marketplace", href: "/marketplace" },
  { icon: Shield, label: "Privacy", href: "/privacy" },
];

type NavItem = { icon: React.ElementType; label: string; href: string };

function NavGroup({ items, label }: { items: NavItem[]; label?: string }) {
  const [location] = useLocation();
  return (
    <div className="mb-1">
      {label && (
        <p className="hidden md:block text-[10px] font-bold uppercase tracking-widest text-muted-foreground/50 px-3 mb-1 mt-4">{label}</p>
      )}
      {items.map((item) => {
        const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
        return (
          <Link key={item.href} href={item.href} className="block">
            <div className={cn(
              "flex items-center md:justify-start justify-center gap-3 px-3 py-2 rounded-lg transition-colors cursor-pointer",
              isActive
                ? "bg-primary/15 text-primary"
                : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
            )}>
              <item.icon className={cn("w-4 h-4 shrink-0", isActive && "text-primary")} />
              <span className="hidden md:block font-medium truncate text-sm">{item.label}</span>
            </div>
          </Link>
        );
      })}
    </div>
  );
}

export function Sidebar() {
  const { isConnected, piUsername } = useWallet();

  return (
    <aside className="w-14 md:w-56 border-r border-white/5 bg-background flex-shrink-0 flex flex-col py-3 overflow-hidden">
      <nav className="flex-1 px-2 overflow-y-auto scrollbar-none">
        <NavGroup items={mainNav} />
        <div className="my-2 border-t border-white/5" />
        <NavGroup items={libraryNav} label="Library" />
        <div className="my-2 border-t border-white/5" />
        <NavGroup items={creatorNav} label="Creator" />
        <div className="my-2 border-t border-white/5" />
        <NavGroup items={web3Nav} label="Web3" />
        <div className="my-2 border-t border-white/5" />
        <NavGroup items={xpNav} label="Experience" />
      </nav>

      <div className="px-3 mt-auto pt-3 border-t border-white/5 space-y-2">
        {isConnected && (
          <div className="hidden md:flex items-center gap-2 px-3 py-2 rounded-xl bg-primary/10 border border-primary/20">
            <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-[10px] shrink-0">
              {piUsername?.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-primary truncate">@{piUsername}</p>
              <p className="text-[10px] text-muted-foreground">Pi Wallet Connected</p>
            </div>
          </div>
        )}

        <div className="hidden md:block p-3 rounded-xl bg-gradient-to-br from-yellow-500/10 to-secondary/10 border border-yellow-500/20">
          <h3 className="font-display font-semibold text-[10px] mb-1 text-yellow-400/80 uppercase tracking-wider">Network</h3>
          <p className="text-sm font-bold text-yellow-400">Pi Testnet</p>
          <p className="text-[10px] text-muted-foreground">Developer demo mode</p>
        </div>

        <Link href="/subscribe" className="block">
          <div className="flex items-center md:justify-start justify-center gap-2 px-3 py-2 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors cursor-pointer border border-primary/20">
            <Crown className="w-4 h-4 text-primary shrink-0" />
            <span className="hidden md:block text-xs font-semibold text-primary">Go Premium</span>
          </div>
        </Link>
      </div>
    </aside>
  );
}
