import { Link } from "wouter";
import { Video } from "@workspace/api-client-react";
import { CheckCircle2, Radio } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export function VideoCard({ video, layout = "grid" }: { video: Video, layout?: "grid" | "list" }) {
  const isGrid = layout === "grid";

  return (
    <Link href={`/watch/${video.id}`} className="block group">
      <div className={`flex ${isGrid ? "flex-col gap-3" : "flex-row gap-4"} cursor-pointer`}>
        <div className={`relative shrink-0 ${isGrid ? "w-full aspect-video rounded-xl" : "w-40 sm:w-64 aspect-video rounded-lg"} overflow-hidden bg-gradient-to-br border border-white/5 group-hover:border-white/20 transition-colors`}
          style={{ 
            backgroundImage: `linear-gradient(to bottom right, ${video.thumbnailColor}, ${video.thumbnailColor2 || '#1a1a1a'})`
          }}
        >
          <div className="absolute inset-0 flex items-center justify-center text-4xl sm:text-6xl drop-shadow-xl group-hover:scale-110 transition-transform duration-300">
            {video.thumbnailEmoji}
          </div>
          
          <div className="absolute bottom-2 right-2 flex gap-1">
            {video.isLive ? (
              <Badge variant="destructive" className="animate-pulse flex gap-1 items-center font-bold px-1.5 py-0 h-5">
                <Radio className="w-3 h-3" /> LIVE
              </Badge>
            ) : (
              <Badge variant="secondary" className="bg-black/80 text-white hover:bg-black/80 font-medium px-1.5 py-0 h-5 text-xs">
                {video.duration}
              </Badge>
            )}
          </div>
          {video.isHD && (
            <Badge variant="secondary" className="absolute top-2 right-2 bg-black/60 text-white/90 backdrop-blur px-1.5 py-0 h-5 text-[10px] font-bold">
              HD
            </Badge>
          )}
        </div>

        <div className="flex gap-3 flex-1 min-w-0">
          {isGrid && (
            <div className="w-9 h-9 rounded-full bg-white/10 shrink-0 flex items-center justify-center text-white/50 font-bold border border-white/5">
              {video.channelName.charAt(0).toUpperCase()}
            </div>
          )}
          <div className="flex flex-col min-w-0 overflow-hidden">
            <h3 className={`font-semibold text-foreground leading-tight line-clamp-2 group-hover:text-primary transition-colors ${isGrid ? "text-base" : "text-lg sm:text-xl mb-1"}`}>
              {video.title}
            </h3>
            
            <div className={`flex items-center gap-1 text-sm text-muted-foreground mt-1 ${isGrid ? "" : "mb-1"}`}>
              <span className="truncate hover:text-white transition-colors">{video.channelName}</span>
              {video.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />}
            </div>
            
            <div className="flex items-center gap-1.5 text-xs sm:text-sm text-muted-foreground">
              <span>{video.views} views</span>
              <span className="w-1 h-1 rounded-full bg-white/20"></span>
              <span>{video.createdAt}</span>
            </div>
            
            {!isGrid && video.description && (
              <p className="mt-2 text-sm text-muted-foreground line-clamp-2 hidden sm:block">
                {video.description}
              </p>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
