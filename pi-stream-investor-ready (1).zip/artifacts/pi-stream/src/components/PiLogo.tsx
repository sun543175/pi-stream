export function PiLogo({ className = "w-8 h-8", glow = true }: { className?: string, glow?: boolean }) {
  return (
    <img
      src="/pi-stream-logo.jpg"
      alt="Pi Stream"
      className={className}
      style={glow ? { filter: "drop-shadow(0 0 8px rgba(139,92,246,0.7))", borderRadius: "50%", objectFit: "cover" } : { borderRadius: "50%", objectFit: "cover" as const }}
    />
  );
}
