import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { MainLayout } from "@/components/layout/MainLayout";
import NotFound from "@/pages/not-found";
import { WalletProvider } from "@/context/WalletContext";
import { ThemeProvider } from "@/context/ThemeContext";

import Home from "@/pages/Home";
import Watch from "@/pages/Watch";
import Search from "@/pages/Search";
import Subscribe from "@/pages/Subscribe";
import History from "@/pages/History";
import Playlists from "@/pages/Playlists";
import Exchange from "@/pages/Exchange";
import Live from "@/pages/Live";
import Upload from "@/pages/Upload";
import Trending from "@/pages/Trending";
import WatchLater from "@/pages/WatchLater";
import Liked from "@/pages/Liked";
import Channel from "@/pages/Channel";
import Analytics from "@/pages/Analytics";
import Shorts from "@/pages/Shorts";
import Settings from "@/pages/Settings";
import Notifications from "@/pages/Notifications";
import Studio from "@/pages/Studio";
import DAO from "@/pages/DAO";
import NFTVault from "@/pages/NFTVault";
import Web3Id from "@/pages/Web3Id";
import AiStudio from "@/pages/AiStudio";
import CrossChain from "@/pages/CrossChain";
import VrParty from "@/pages/VrParty";
import Marketplace from "@/pages/Marketplace";
import Privacy from "@/pages/Privacy";
import CommunityDao from "@/pages/CommunityDao";
import Staking from "@/pages/Staking";

const queryClient = new QueryClient();

function Router() {
  return (
    <MainLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/watch/:id" component={Watch} />
        <Route path="/search" component={Search} />
        <Route path="/subscribe" component={Subscribe} />
        <Route path="/history" component={History} />
        <Route path="/playlists" component={Playlists} />
        <Route path="/exchange" component={Exchange} />
        <Route path="/live" component={Live} />
        <Route path="/upload" component={Upload} />
        <Route path="/trending" component={Trending} />
        <Route path="/watch-later" component={WatchLater} />
        <Route path="/liked" component={Liked} />
        <Route path="/channel/:name" component={Channel} />
        <Route path="/analytics" component={Analytics} />
        <Route path="/shorts" component={Shorts} />
        <Route path="/settings" component={Settings} />
        <Route path="/notifications" component={Notifications} />
        <Route path="/studio" component={Studio} />
        <Route path="/dao" component={DAO} />
        <Route path="/nft-vault" component={NFTVault} />
        <Route path="/web3-id" component={Web3Id} />
        <Route path="/ai-studio" component={AiStudio} />
        <Route path="/cross-chain" component={CrossChain} />
        <Route path="/vr-party" component={VrParty} />
        <Route path="/marketplace" component={Marketplace} />
        <Route path="/privacy" component={Privacy} />
        <Route path="/community-dao" component={CommunityDao} />
        <Route path="/staking" component={Staking} />
        <Route component={NotFound} />
      </Switch>
    </MainLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <WalletProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Router />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </WalletProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
