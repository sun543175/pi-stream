import { pgTable, serial, text, real, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const subscriptionsTable = pgTable("subscriptions", {
  id:            serial("id").primaryKey(),
  planId:        text("plan_id").notNull(),
  status:        text("status").notNull().default("active"),
  piTxId:        text("pi_tx_id").notNull(),
  piAmount:      real("pi_amount").notNull(),
  gcvUsd:        real("gcv_usd").notNull(),
  walletAddress: text("wallet_address"),
  startDate:     timestamp("start_date").notNull().defaultNow(),
  endDate:       timestamp("end_date").notNull().defaultNow(),
  createdAt:     timestamp("created_at").notNull().defaultNow(),
});

export const insertSubscriptionSchema = createInsertSchema(subscriptionsTable).omit({ id: true, createdAt: true });
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptionsTable.$inferSelect;
