import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const watchHistoryTable = pgTable("watch_history", {
  id:             serial("id").primaryKey(),
  videoId:        integer("video_id").notNull(),
  title:          text("title").notNull(),
  thumbnailEmoji: text("thumbnail_emoji").notNull().default("🎬"),
  progress:       integer("progress").notNull().default(0),
  watchedAt:      timestamp("watched_at").notNull().defaultNow(),
});

export const insertWatchHistorySchema = createInsertSchema(watchHistoryTable).omit({ id: true, watchedAt: true });
export type InsertWatchHistory = z.infer<typeof insertWatchHistorySchema>;
export type WatchHistory = typeof watchHistoryTable.$inferSelect;
