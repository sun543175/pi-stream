import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const videosTable = pgTable("videos", {
  id:             serial("id").primaryKey(),
  title:          text("title").notNull(),
  channelName:    text("channel_name").notNull(),
  channelAvatar:  text("channel_avatar"),
  description:    text("description"),
  thumbnailEmoji: text("thumbnail_emoji").notNull().default("🎬"),
  category:       text("category").notNull().default("Technology"),
  views:          integer("views").notNull().default(0),
  likes:          integer("likes").notNull().default(0),
  duration:       text("duration").notNull().default("0:00"),
  isLive:         boolean("is_live").notNull().default(false),
  isShorts:       boolean("is_shorts").notNull().default(false),
  createdAt:      timestamp("created_at").notNull().defaultNow(),
});

export const insertVideoSchema = createInsertSchema(videosTable).omit({ id: true, createdAt: true });
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type Video = typeof videosTable.$inferSelect;
