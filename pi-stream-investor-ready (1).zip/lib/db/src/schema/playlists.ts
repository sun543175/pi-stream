import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { videosTable } from "./videos";

export const playlistsTable = pgTable("playlists", {
  id:          serial("id").primaryKey(),
  name:        text("name").notNull(),
  description: text("description"),
  createdAt:   timestamp("created_at").notNull().defaultNow(),
});

export const playlistVideosTable = pgTable("playlist_videos", {
  playlistId: integer("playlist_id").notNull().references(() => playlistsTable.id, { onDelete: "cascade" }),
  videoId:    integer("video_id").notNull().references(() => videosTable.id, { onDelete: "cascade" }),
});

export const insertPlaylistSchema = createInsertSchema(playlistsTable).omit({ id: true, createdAt: true });
export type InsertPlaylist = z.infer<typeof insertPlaylistSchema>;
export type PlaylistRow = typeof playlistsTable.$inferSelect;
